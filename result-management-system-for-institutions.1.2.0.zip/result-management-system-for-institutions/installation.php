<?php

/**
 * Result Management System for Institutions
 *
 * Copyright (C) 2025 ASTGD
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

/**
 * This file is part of the Result Management System for Institutions plugin.
 *
 * @package ASTGDRMSYS\ResultManagement
 * @namespace ASTGDRMSYS\ResultManagement
 */

namespace ASTGDRMSYS\ResultManagement;

/**
 * Ensures the file is being run within the WordPress environment.
 * If accessed directly, the script will exit.
 *
 * @package ResultManagementSystem
 * @subpackage Installation
 */

// Exit if accessed directly
if (! defined('ABSPATH')) {
	exit;
}

/**
 * Class ASTGDRMSYS_DatabaseInstaller
 *
 * This class handles the installation of the database for the Result Management System for Institutions plugin.
 * It includes methods to create necessary tables and populate initial data.
 *
 * @package ResultManagementSystem
 */
class ASTGDRMSYS_DatabaseInstaller
{

	private $wpdb;
	private $prefix;
	private $tables;

	/**
	 * Constructor for the class.
	 *
	 * This method is called when an instance of the class is created.
	 */
	public function __construct()
	{
		global $wpdb;
		$this->wpdb   = $wpdb;
		$this->prefix = $wpdb->prefix;
		$this->setup_tables();
	}

	/**
	 * Sets up the necessary database tables for the plugin.
	 *
	 * This method is responsible for creating and configuring the required
	 * database tables that the plugin will use to store its data.
	 *
	 * @return void
	 */
	private function setup_tables(): void
	{
		$this->tables = array(
			'student_result' => array(
				'name' => 'astgdrmsys_student_result',
				'sql'  => "CREATE TABLE IF NOT EXISTS `{$this->prefix}astgdrmsys_student_result` (
                    `sid` INT(10) NOT NULL AUTO_INCREMENT,
                    `sno` VARCHAR(10) NOT NULL,
                    `regno` VARCHAR(30) NOT NULL,
                    `name` VARCHAR(100) NOT NULL,
                    `gender` VARCHAR(10) NOT NULL,
                    `fname` VARCHAR(100) NOT NULL,
                    `mname` VARCHAR(100) NOT NULL,
                    `remark` VARCHAR(50) NOT NULL,
                    `class` VARCHAR(50) NOT NULL,
                    `section` VARCHAR(30) NOT NULL,
                    `department` VARCHAR(30) NOT NULL,
                    `exam_name` VARCHAR(30) NOT NULL,
                    `exam_year` VARCHAR(30) NOT NULL,
                    PRIMARY KEY (`sid`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
			),
			'school_info'    => array(
				'name' => 'astgdrmsys_school_info',
				'sql'  => "CREATE TABLE IF NOT EXISTS `{$this->prefix}astgdrmsys_school_info` (
                    `sc_id` INT(10) NOT NULL AUTO_INCREMENT,
                    `sc_name` VARCHAR(100) NOT NULL,
                    `vill` VARCHAR(30) NOT NULL,
                    `pin` VARCHAR(10) NOT NULL,
                    `ps` VARCHAR(30) NOT NULL,
                    `dist` VARCHAR(30) NOT NULL,
                    `state` VARCHAR(30) NOT NULL,
                    `phone` VARCHAR(30) NOT NULL,
                    `email` VARCHAR(100) NOT NULL,
                    `website` VARCHAR(100) NOT NULL,
                    `logo` VARCHAR(255) NOT NULL,
                    PRIMARY KEY (`sc_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
			),
			'view_settings'  => array(
				'name'         => 'astgdrmsys_view_settings',
				'sql'          => "CREATE TABLE IF NOT EXISTS `{$this->prefix}astgdrmsys_view_settings` (
            `vid` INT(10) NOT NULL AUTO_INCREMENT,
            `methodfield` VARCHAR(30) NOT NULL,
            `titlefield` VARCHAR(30) NOT NULL,
            `namefield` VARCHAR(50) NOT NULL,
            `genderfield` VARCHAR(30) NOT NULL,
            `fnamefield` VARCHAR(30) NOT NULL,
            `mnamefield` VARCHAR(30) NOT NULL,
            `subjectfield` VARCHAR(50) NOT NULL,
            `classfield` VARCHAR(30) NOT NULL,
            `regnofield` VARCHAR(30) NOT NULL,
            `rollfield` VARCHAR(30) NOT NULL,
            `totalfield` VARCHAR(30) NOT NULL,
            `minimumfield` VARCHAR(30) NOT NULL,
            `obtainedfield` VARCHAR(30) NOT NULL,
            `remarkfield` VARCHAR(30) NOT NULL,
            `percentage` VARCHAR(30) NOT NULL,
            `minimumpercentage` VARCHAR(30) NOT NULL,
            `finalresult` VARCHAR(30) NOT NULL,
            `principalfield` VARCHAR(30) NOT NULL,
            PRIMARY KEY (`vid`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
				'initial_data' => array(
					array(
						'vid'               => 1,
						'methodfield'       => 'Roll Number',
						'titlefield'        => 'PROGRESS REPORT',
						'namefield'         => 'Name of the Student :',
						'genderfield'       => 'Gender :',
						'fnamefield'        => 'Father\'s Name :',
						'mnamefield'        => 'Mother\'s Name :',
						'classfield'        => 'Class :',
						'regnofield'        => 'Registration Number :',
						'subjectfield'      => 'Subject :',
						'rollfield'         => 'Roll No :',
						'totalfield'        => 'Total Marks:',
						'minimumfield'      => 'Min Passing Marks:',
						'obtainedfield'     => 'Obtained Marks:',
						'remarkfield'       => 'Grade :',
						'percentage'        => 'Percentage :',
						'minimumpercentage' => 'Minimum Passing Percentage :',
						'finalresult'       => 'Remark :',
						'principalfield'    => 'Principal :',
					),
					array(
						'vid'               => 2,
						'methodfield'       => 'true',
						'titlefield'        => 'true',
						'namefield'         => 'true',
						'genderfield'       => 'true',
						'fnamefield'        => 'true',
						'mnamefield'        => 'true',
						'classfield'        => 'true',
						'regnofield'        => 'true',
						'subjectfield'      => 'true',
						'rollfield'         => 'true',
						'totalfield'        => 'true',
						'minimumfield'      => 'true',
						'obtainedfield'     => 'true',
						'remarkfield'       => 'true',
						'percentage'        => 'true',
						'minimumpercentage' => 'true',
						'finalresult'       => 'true',
						'principalfield'    => 'true',
					),
					array(
						'vid'               => 3,
						'methodfield'       => 'marksheet',
						'titlefield'        => 'watermark',
						'namefield'         => 'false',
						'genderfield'       => 'false',
						'fnamefield'        => 'false',
						'mnamefield'        => 'false',
						'classfield'        => 'false',
						'regnofield'        => 'false',
						'subjectfield'      => 'false',
						'rollfield'         => 'false',
						'totalfield'        => 'false',
						'minimumfield'      => 'false',
						'obtainedfield'     => 'false',
						'remarkfield'       => 'false',
						'percentage'        => 'false',
						'minimumpercentage' => 'false',
						'finalresult'       => 'false',
						'principalfield'    => 'false',
					),
				),
			),
			'grade_system' => array(
				'name' => 'astgdrmsys_grade_system',
				'sql'  => "CREATE TABLE IF NOT EXISTS `{$this->prefix}astgdrmsys_grade_system` (
					`id` INT(10) NOT NULL AUTO_INCREMENT,
					`min_mark` INT NOT NULL,
					`max_mark` INT NOT NULL,
					`grade` VARCHAR(10) NOT NULL,
					`grade_point` FLOAT NOT NULL,
					`remarks` VARCHAR(255) NOT NULL,
					PRIMARY KEY (`id`)
				) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
			),
			'mark' => array(
				'name' => 'astgdrmsys_mark',
				'sql'  => "CREATE TABLE IF NOT EXISTS `{$this->prefix}astgdrmsys_mark` (
					`id` INT NOT NULL AUTO_INCREMENT,
            		`sid` INT NOT NULL,
		            `marks` LONGTEXT NOT NULL,
		            `remark` VARCHAR(255) NULL,
		            PRIMARY KEY (`id`)
	     		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
			),
			'subject'        => array(
				'name' => 'astgdrmsys_subject',
				'sql'  => "CREATE TABLE IF NOT EXISTS `{$this->prefix}astgdrmsys_subject` (
                    `id` INT(10) NOT NULL AUTO_INCREMENT,
                    `subid` INT(10) NOT NULL,
                    `class` VARCHAR(50) NOT NULL,
                    `department` VARCHAR(30) NOT NULL,
                    `subname` VARCHAR(100) NOT NULL,
                    `subcode` INT(10) NOT NULL,
                    `minmark` INT(10) NOT NULL,
                    `total` INT(10) NOT NULL,
                    PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
			),
			'class'          => array(
				'name' => 'astgdrmsys_class',
				'sql'  => "CREATE TABLE IF NOT EXISTS `{$this->prefix}astgdrmsys_class` (
                    `id` INT(10) NOT NULL AUTO_INCREMENT,
                    `class` VARCHAR(30) NOT NULL,
                    PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
			),
			'department'     => array(
				'name' => 'astgdrmsys_department',
				'sql'  => "CREATE TABLE IF NOT EXISTS `{$this->prefix}astgdrmsys_department` (
                    `id` INT(10) NOT NULL AUTO_INCREMENT,
                    `department` VARCHAR(30) NOT NULL,
                    `class` VARCHAR(30) NOT NULL,
                    PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
			),
			'section'        => array(
				'name' => 'astgdrmsys_section',
				'sql'  => "CREATE TABLE IF NOT EXISTS `{$this->prefix}astgdrmsys_section` (
                    `id` INT(10) NOT NULL AUTO_INCREMENT,
                    `section` VARCHAR(30) NOT NULL,
                    `department` VARCHAR(30) NOT NULL,
                    `classname` VARCHAR(30) NOT NULL,
                    PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
			),
			'exam_name'      => array(
				'name' => 'astgdrmsys_exam_name',
				'sql'  => "CREATE TABLE IF NOT EXISTS `{$this->prefix}astgdrmsys_exam_name` (
                    `id` INT(10) NOT NULL AUTO_INCREMENT,
                    `exam_name` VARCHAR(30) NOT NULL,
					`exam_type` VARCHAR(50) NOT NULL DEFAULT 'single',
                    `department` VARCHAR(30) NOT NULL,
                    `class` VARCHAR(30) NOT NULL,
                    `class_id` INT(10) NOT NULL,
                    `exam_year` VARCHAR(30) NOT NULL,
                    `exam_year_id` INT(10) NOT NULL,
                    `result_title` VARCHAR(30) NOT NULL,
                    `result_subtitle` VARCHAR(30) NOT NULL,
                    `result_footer_text` VARCHAR(30) NOT NULL,
                    `result_publish_status` TINYINT(1) NOT NULL DEFAULT 0,
                    PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
			),
			'exam_year'      => array(
				'name' => 'astgdrmsys_exam_year',
				'sql'  => "CREATE TABLE IF NOT EXISTS `{$this->prefix}astgdrmsys_exam_year` (
                    `id` INT(10) NOT NULL AUTO_INCREMENT,
                    `exam_year` VARCHAR(30) NOT NULL,
                    PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
			),
		);
	}

	/**
	 * Handles the installation process for the plugin.
	 *
	 * @return array An array containing the results of the installation process.
	 */
	public function install(): array
	{
		$results = array();
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		foreach ($this->tables as $table => $definition) {
			try {
				dbDelta($definition['sql']);
				$results[$table] = true;
			} catch (\Exception $e) {
				$results[$table] = false;
				do_action('astgdrmsys_log_error', "ASTDGRMSYS Error creating table {$table}: " . $e->getMessage());
			}
		}

		$this->seed_default_data();
		return $results;
	}

	/**
	 * Seeds the default data into the database.
	 *
	 * This function is responsible for populating the database with initial
	 * default data required for the plugin to function correctly.
	 *
	 * @return void
	 */
	private function seed_default_data(): void
	{
		// Seed view settings if empty
		try {
			$sanitized_grade_system_table = esc_sql($this->prefix . 'astgdrmsys_grade_system');
			$existing_grades = $this->wpdb->get_results("SELECT * FROM `{$sanitized_grade_system_table}`");

			// If no grades exist, insert default grades
			if (empty($existing_grades)) {
				$default_grades = array(
					array('min_mark' => 0, 'max_mark' => 32, 'grade' => 'F', 'grade_point' => 0, 'remarks' => 'Fail'),
					array('min_mark' => 33, 'max_mark' => 39, 'grade' => 'D', 'grade_point' => 1, 'remarks' => 'Pass'),
					array('min_mark' => 40, 'max_mark' => 49, 'grade' => 'C', 'grade_point' => 2, 'remarks' => 'Average'),
					array('min_mark' => 50, 'max_mark' => 59, 'grade' => 'B', 'grade_point' => 3, 'remarks' => 'Good'),
					array('min_mark' => 60, 'max_mark' => 69, 'grade' => 'A-', 'grade_point' => 3.5, 'remarks' => 'Very Good'),
					array('min_mark' => 70, 'max_mark' => 79, 'grade' => 'A', 'grade_point' => 4, 'remarks' => 'Excellent'),
					array('min_mark' => 80, 'max_mark' => 100, 'grade' => 'A+', 'grade_point' => 5, 'remarks' => 'Outstanding'),
				);

				foreach ($default_grades as $grade) {
					$this->wpdb->insert(
						"{$this->prefix}astgdrmsys_grade_system",
						$grade
					);
				}
			}

			// Sanitize table name
			$sanitized_view_settings_table = esc_sql($this->prefix . 'astgdrmsys_view_settings');

			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$existing_views = $this->wpdb->get_results("SELECT * FROM `{$sanitized_view_settings_table}`");

			if (empty($existing_views)) {
				$default_view_settings = array(
					array(
						'vid'               => 1,
						'methodfield'       => 'Roll Number',
						'titlefield'        => 'PROGRESS REPORT',
						'namefield'         => 'Name of the Student :',
						'genderfield'       => 'Gender :',
						'fnamefield'        => 'Father\'s Name :',
						'mnamefield'        => 'Mother\'s Name :',
						'classfield'        => 'Class :',
						'regnofield'        => 'Registration Number :',
						'subjectfield'      => 'Subject :',
						'rollfield'         => 'Roll No :',
						'totalfield'        => 'Total Marks:',
						'minimumfield'      => 'Min Passing Marks:',
						'obtainedfield'     => 'Obtained Marks:',
						'remarkfield'       => 'Grade :',
						'percentage'        => 'Percentage :',
						'minimumpercentage' => 'Minimum Passing Percentage :',
						'finalresult'       => 'Remark :',
						'principalfield'    => 'Principal :',
					),
					array(
						'vid'               => 2,
						'methodfield'       => 'true',
						'titlefield'        => 'true',
						'namefield'         => 'true',
						'genderfield'       => 'true',
						'fnamefield'        => 'true',
						'mnamefield'        => 'true',
						'classfield'        => 'true',
						'regnofield'        => 'true',
						'subjectfield'      => 'true',
						'rollfield'         => 'true',
						'totalfield'        => 'true',
						'minimumfield'      => 'true',
						'obtainedfield'     => 'true',
						'remarkfield'       => 'true',
						'percentage'        => 'true',
						'minimumpercentage' => 'true',
						'finalresult'       => 'true',
						'principalfield'    => 'true',
					),
					array(
						'vid'               => 3,
						'methodfield'       => 'marksheet',
						'titlefield'        => 'watermark',
						'namefield'         => 'false',
						'genderfield'       => 'false',
						'fnamefield'        => 'false',
						'mnamefield'        => 'false',
						'classfield'        => 'false',
						'regnofield'        => 'false',
						'subjectfield'      => 'false',
						'rollfield'         => 'false',
						'totalfield'        => 'false',
						'minimumfield'      => 'false',
						'obtainedfield'     => 'false',
						'remarkfield'       => 'false',
						'percentage'        => 'false',
						'minimumpercentage' => 'false',
						'finalresult'       => 'false',
						'principalfield'    => 'false',
					),
				);

				foreach ($default_view_settings as $setting) {
					$inserted = $this->wpdb->insert(
						"{$this->prefix}astgdrmsys_view_settings",
						$setting
					);

					if ($inserted === false) {
						throw new \Exception($this->wpdb->last_error);
					}
				}
			}
		} catch (\Exception $e) {
			do_action('astgdrmsys_log_error', 'ASTGDRMSYS Error seeding default data: ' . $e->getMessage());
		}
	}
}

/**
 * Creates the upload directory for the plugin.
 *
 * This function is responsible for creating the necessary upload directory
 * within the WordPress content directory for storing plugin-related files.
 *
 * @return void
 */
function create_upload_directory(): void
{
	try {
		$upload_dir = wp_upload_dir();
		$result_dir = $upload_dir['basedir'] . '/astgdrmsys-results';

		if (! file_exists($result_dir)) {
			if (! wp_mkdir_p($result_dir)) {
				throw new \Exception('Failed to create result directory');
			}

			// Create security files
			$files = array(
				'index.php' => "<?php\n// Silence is golden.",
				'.htaccess' => "Options -Indexes\nDeny from all",
			);

			if (! function_exists('WP_Filesystem')) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
			}

			WP_Filesystem();
			global $wp_filesystem;

			foreach ($files as $file => $content) {
				$file_path = trailingslashit($result_dir) . $file;

				if (! $wp_filesystem->put_contents($file_path, $content, FS_CHMOD_FILE)) {
					throw new \Exception("Failed to create {$file}");
				}
			}
		}
	} catch (\Exception $e) {
		do_action('astgdrmsys_log_error', 'RMS Directory Creation Error: ' . $e->getMessage());
		throw $e;
	}
}

/**
 * Installs the plugin.
 *
 * This function is responsible for setting up the necessary environment
 * and configurations required for the plugin to function correctly.
 *
 * @return void
 */
function astgdrmsys_run_installation_routine(): void
{
	try {
		// Create upload directory
		create_upload_directory();

		// Install database
		$installer = new ASTGDRMSYS_DatabaseInstaller();
		$results   = $installer->install();

		// Trigger custom logging for debugging
		if (WP_DEBUG && WP_DEBUG_LOG) {
			do_action('astgdrmsys_debug_log', 'RMS Plugin Installation Results: ' . wp_json_encode($results));
		}

		// Store installation version
		update_option('astgdrmsys_db_version', ASTGDRMSYS_VERSION);
	} catch (\Exception $e) {
		if (WP_DEBUG && WP_DEBUG_LOG) {
			do_action('astgdrmsys_debug_log', 'RMS Plugin Installation Error: ' . $e->getMessage());
		}
		wp_die('Error during plugin installation. Please check error logs.');
	}
}
