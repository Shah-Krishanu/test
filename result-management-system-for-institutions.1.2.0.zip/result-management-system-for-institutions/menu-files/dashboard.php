<?php

/**
 * Result Management System for Institutions
 *
 * Copyright (C) 2025 ASTGD
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */
declare(strict_types=1);

/**
 * This file is part of the Result Management System for Institutions plugin.
 *
 * It ensures that the file is being accessed through WordPress by checking if the ABSPATH constant is defined.
 * If ABSPATH is not defined, the script will exit to prevent unauthorized access.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Dashboard
 *
 * Handles the display and functionality of the plugin dashboard
 */
class ASTGDRMSYS_Dashboard {
	/**
	 * @var wpdb WordPress database object
	 */
	private $wpdb;

	/**
	 * @var string Database table prefix
	 */
	private $prefix;

	/**
	 * @var array School information
	 */
	private $schoolInfo = array();

	/**
	 * @var array Classes information
	 */
	private $classes = array();

	/**
	 * @var array Subjects information
	 */
	private $subjects = array();

	/**
	 * Dashboard constructor.
	 */
	public function __construct() {
		global $wpdb;
		$this->wpdb   = $wpdb;
		$this->prefix = $wpdb->prefix;

		$this->fetchData();
	}

	/**
	 * Fetch all necessary data for the dashboard
	 */
	private function fetchData() {
		$this->fetchSchoolInfo();
		$this->fetchClasses();
		$this->fetchSubjects();
	}

	/**
	 * Fetch school information
	 */
	private function fetchSchoolInfo() {
		$sanitized_school_table = esc_sql( $this->prefix . 'astgdrmsys_school_info' );
		$sql_school             = "SELECT * FROM `$sanitized_school_table` LIMIT 1";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery
		$this->schoolInfo = $this->wpdb->get_row( $sql_school, ARRAY_A );
	}

	/**
	 * Fetch classes information
	 */
	private function fetchClasses() {
		$sanitized_class_table = esc_sql( $this->prefix . 'astgdrmsys_class' );
		$sql_classes           = "SELECT * FROM `$sanitized_class_table`";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery
		$this->classes = $this->wpdb->get_results( $sql_classes, ARRAY_A );
	}

	/**
	 * Fetch subjects information
	 */
	private function fetchSubjects() {
		$sanitized_subject_table = esc_sql( $this->prefix . 'astgdrmsys_subject' );
		$sql_subjects            = "SELECT * FROM `$sanitized_subject_table`";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery
		$this->subjects = $this->wpdb->get_results( $sql_subjects, ARRAY_A );
	}

	/**
	 * Get the count of subjects for a specific class
	 *
	 * @param int $classId The class ID
	 * @return int Number of subjects
	 */
	private function getSubjectCount( $classId, $wpdb ) {
		$sanitized_subject_table = esc_sql( $this->prefix . 'astgdrmsys_subject' );
		$cache_key               = 'subject_count_class_' . $classId;
		$subjectCount            = wp_cache_get( $cache_key, 'rms' );

		if ( $subjectCount === false ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
			$subjectCount = $wpdb->get_var(
				$wpdb->prepare(
                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					"SELECT COUNT(*) FROM `$sanitized_subject_table` WHERE `class` = %d",
					$classId
				)
			);

			// Store in cache (5 minutes)
			wp_cache_set( $cache_key, $subjectCount, 'rms', 300 );
		}

		return $subjectCount;
	}

	/**
	 * Get the count of students for a specific class
	 *
	 * @param int $classId The class ID
	 * @return int Number of students
	 */
	private function getStudentCount( $classId, $wpdb ) {
		$sanitized_result_table = esc_sql( $this->prefix . 'astgdrmsys_student_result' );
		$cache_key              = 'student_count_class_' . $classId;
		$studentCount           = wp_cache_get( $cache_key, 'rms' );

		if ( $studentCount === false ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
			$studentCount = $wpdb->get_var(
				$wpdb->prepare(
                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					"SELECT COUNT(*) FROM `$sanitized_result_table` WHERE `class` = %d",
					$classId
				)
			);

			// Store in cache (5 minutes)
			wp_cache_set( $cache_key, $studentCount, 'rms', 300 );
		}

		return $studentCount;
	}

	/**
	 * Get class information by ID
	 *
	 * @param int $classId The class ID
	 * @return array|null Class information
	 */
	private function getClassInfo( $classId, $wpdb ) {
		$sanitized_table = esc_sql( $this->prefix . 'astgdrmsys_class' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
		return $wpdb->get_row(
			$wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT * FROM `{$sanitized_table}` WHERE `id` = %d",
				$classId
			),
			ARRAY_A
		);
	}

	/**
	 * astgdrmsys_render the dashboard header
	 */
	private function astgdrmsys_renderHeader() {
		?>
		<div class="header-section">
			<div class="dashboard">
				<?php
				if ( ! empty( $this->schoolInfo ) ) :
					// If the logo path is stored as a relative path from uploads directory
					$upload_dir      = wp_upload_dir();
					$base_upload_dir = $upload_dir['basedir'];

					// Get the relative path from the uploads directory
					$relative_path = str_replace( $base_upload_dir . '/', '', $this->schoolInfo['logo'] );

					// Construct the proper URL
					$logo_url = esc_url( $upload_dir['baseurl'] . '/' . $relative_path );
					?>
					<center>
						<img class="school-logo"
							onerror="this.onerror=null; this.remove();"
							src="<?php echo esc_url( $logo_url ); ?>">
					</center>
					<center>
						<h3><?php echo esc_html( $this->schoolInfo['sc_name'] ); ?></h3>
					</center>
				<?php endif; ?>
				<h1>Dashboard</h1>
			</div>
		</div>
		<?php
	}

	/**
	 * astgdrmsys_render institute information section
	 */
	private function astgdrmsys_renderInstituteInfo() {
		?>
		<div class="info-section">
			<div class="section-header">
				<span>Institute Information</span>
				<a class="btn dash-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=astgdrmsys-settings&option=school' ) ); ?>">Edit Institute</a>
			</div>
			<table class="styled-table">
				<thead>
					<tr>
						<th>Institute Name</th>
						<th>Address</th>
						<th>Contact No</th>
						<th>Website</th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! empty( $this->schoolInfo ) ) : ?>
						<tr>
							<td><?php echo esc_html( $this->schoolInfo['sc_name'] ); ?></td>
							<td>
								<?php
								echo esc_html(
									"{$this->schoolInfo['vill']}, {$this->schoolInfo['ps']}, " .
									"{$this->schoolInfo['dist']}, {$this->schoolInfo['pin']} " .
									"({$this->schoolInfo['state']})"
								);
								?>
							</td>
							<td><?php echo esc_html( $this->schoolInfo['phone'] ); ?></td>
							<td><?php echo esc_html( $this->schoolInfo['website'] ); ?></td>
						</tr>
					<?php else : ?>
						<tr>
							<td colspan="5" class="empty-text">No information added!</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * astgdrmsys_render class information section
	 */
	private function astgdrmsys_renderClassInfo( $wpdb ) {
		?>
		<div class="info-section">
			<div class="section-header">
				<span>Class Information</span>
				<a class="btn dash-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=astgdrmsys-class' ) ); ?>">Add Class</a>
			</div>
			<table class="styled-table">
				<thead>
					<tr>
						<th>Class ID</th>
						<th>Class Name</th>
						<th>No. of Subjects</th>
						<th>No. of Students</th>
					</tr>
				</thead>
				<tbody>
					<?php
					if ( ! empty( $this->classes ) ) :
						foreach ( $this->classes as $class ) :
							$subjectCount = $this->getSubjectCount( $class['id'], $wpdb );
							$studentCount = $this->getStudentCount( $class['id'], $wpdb );
							?>
							<tr>
								<td><?php echo esc_html( $class['id'] ); ?></td>
								<td><?php echo esc_html( $class['class'] ); ?></td>
								<td><?php echo esc_html( $subjectCount ); ?></td>
								<td><?php echo esc_html( $studentCount ); ?></td>
							</tr>
							<?php
						endforeach;
					else :
						?>
						<tr>
							<td colspan="4" class="empty-text">No class information available!</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * astgdrmsys_render subject information section
	 */
	private function astgdrmsys_renderSubjectInfo( $wpdb ) {
		?>
		<div class="info-section">
			<div class="section-header">
				<span>Subject Information</span>
				<a class="btn dash-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=astgdrmsys-subject' ) ); ?>">Add Subject</a>
			</div>
			<table class="styled-table">
				<thead>
					<tr>
						<th>Subject ID</th>
						<th>Subject Name</th>
						<th>Subject Code</th>
						<th>Min Mark</th>
						<th>Total Mark</th>
						<th>Class ID</th>
						<th>Class Name</th>
					</tr>
				</thead>
				<tbody>
					<?php
					if ( ! empty( $this->subjects ) ) :
						foreach ( $this->subjects as $subject ) :
							$classInfo = $this->getClassInfo( $subject['class'], $wpdb );
							?>
							<tr>
								<td><?php echo esc_html( $subject['id'] ); ?></td>
								<td><?php echo esc_html( $subject['subname'] ); ?></td>
								<td><?php echo esc_html( $subject['subcode'] ); ?></td>
								<td><?php echo esc_html( $subject['minmark'] ); ?></td>
								<td><?php echo esc_html( $subject['total'] ); ?></td>
								<td><?php echo esc_html( $classInfo['id'] ?? 'N/A' ); ?></td>
								<td><?php echo esc_html( $classInfo['class'] ?? 'N/A' ); ?></td>
							</tr>
							<?php
						endforeach;
					else :
						?>
						<tr>
							<td colspan="7" class="empty-text">No subject information available!</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * astgdrmsys_render the complete dashboard
	 */
	public function astgdrmsys_render() {
		?>
		<div class="container">
			<?php
			$this->astgdrmsys_renderHeader();
			$this->astgdrmsys_renderInstituteInfo();
			$this->astgdrmsys_renderClassInfo( $this->wpdb );
			$this->astgdrmsys_renderSubjectInfo( $this->wpdb );
			?>
		</div>
		<?php
	}
}

// Initialize and astgdrmsys_render the dashboard
$dashboard = new ASTGDRMSYS_Dashboard();
$dashboard->astgdrmsys_render();