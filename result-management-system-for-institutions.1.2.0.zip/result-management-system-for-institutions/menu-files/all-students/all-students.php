<?php

/**
 * Result Management System for Institutions
 *
 * Copyright (C) 2025 ASTGD
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

/**
 * This file is part of the Result Management System for Institutions plugin.
 *
 * It ensures that the file is being accessed through WordPress by checking if the ABSPATH constant is defined.
 * If ABSPATH is not defined, it exits the script to prevent direct access.
 *
 * @package ResultManagementSystem
 * @subpackage Menu_Files/All_Students
 */
if (! defined('ABSPATH')) {
	exit;
}

// Include WordPress database access
global $wpdb;

/**
 * Class ASTGDRMSYS_All_Students
 *
 * This class handles the functionality related to displaying and managing all students.
 *
 * @package ResultManagementSystem
 * @subpackage MenuFiles
 * @since 1.0.0
 */
class ASTGDRMSYS_All_Students
{

	private $wpdb;
	private $prefix;
	private $limit = 15;

	/**
	 * Constructor for the class.
	 *
	 * @param wpdb $wpdb WordPress database access abstraction object.
	 */
	public function __construct($wpdb)
	{
		$this->wpdb   = $wpdb;
		$this->prefix = $wpdb->prefix;

		$this->handleMessages();
		$this->handleExport($wpdb);

		// Display the students table
		$this->displayStudents();
	}

	/**
	 * Handles the messages for the all-students page.
	 *
	 * This function processes and manages the messages that are displayed or handled
	 * on the all-students page within the Result Management System for Institutions plugin.
	 *
	 * @return void
	 */
	private function handleMessages()
	{
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if (isset($_GET['del']) && $_GET['del'] == 'true') {
			$this->displayMessage('Student Record Deleted Successfully');
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if (isset($_GET['edit']) && $_GET['edit'] == 'true') {
			$this->displayMessage('Student Record Updated Successfully');
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if (isset($_GET['csv']) && $_GET['csv'] == 'imported') {
			$this->displayMessage('CSV File Imported Successfully');
		}
	}

	/**
	 * Displays a message.
	 *
	 * @param string $message The message to be displayed.
	 */
	private function displayMessage($message)
	{
		echo "
        <div id='message_div' class='alert alert-success'>
        <center>" . esc_html($message) . "</center>
        <button class='close-message' onclick='this.parentElement.style.display=\"none\";'>&times;</button>
        </div>";
	}

	/**
	 * Handles the export functionality for the all-students page.
	 *
	 * This function is responsible for managing the export process of student data.
	 *
	 * @return void
	 */
	private function handleExport($wpdb)
	{
		// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		if (isset($_POST['export'])) {
			// Verify nonce for security
			check_admin_referer('export_action', 'export_nonce');

			header('Content-Type: text/csv; charset=utf-8');
			header('Content-Disposition: attachment; filename=astgdrmsys-all-students.csv');
			$output = fopen('php://output', 'w');
			ob_end_clean();

			$studentcolumns = $this->getStudentColumns();
			fputcsv($output, $studentcolumns);

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
			// Safe table name sanitization
			$table_name = esc_sql($this->prefix . 'astgdrmsys_student_result');
			$sql        = "SELECT * FROM `$table_name`";

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
			$students = $wpdb->get_results($sql, ARRAY_A);

			foreach ($students as $student) {
				$row = $this->prepareStudentRow($student, $this->wpdb);
				fputcsv($output, $row);
			}
			fclose($output);
			exit();
		}
	}

	/**
	 * Retrieves the columns for the student list.
	 *
	 * This function returns an array of columns to be displayed in the student list.
	 *
	 * @return array An associative array where the keys are column identifiers and the values are column titles.
	 */
	private function getStudentColumns()
	{
		// Get base student columns
		$query = $this->wpdb->prepare(
			'SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_NAME = %s AND TABLE_SCHEMA = %s',
			$this->prefix . 'astgdrmsys_student_result',
			$this->wpdb->dbname
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$columns        = $this->wpdb->get_results($query, ARRAY_A);
		$studentcolumns = array_column($columns, 'COLUMN_NAME');

		// Remove 'sid' column
		$key = array_search('sid', $studentcolumns);
		if ($key !== false) {
			unset($studentcolumns[$key]);
		}

		$subject_table = esc_sql($this->wpdb->prefix . 'astgdrmsys_subject');
		$sql           = "SELECT subname FROM `$subject_table`";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery
		$subjects = $this->wpdb->get_results($sql, ARRAY_A);

		// Add subject columns
		foreach ($subjects as $subject) {
			$studentcolumns[] = $subject['subname'];
		}

		return $studentcolumns;
	}

	/**
	 * Prepares a row of student data for display.
	 *
	 * @param array $student An associative array containing student data.
	 *
	 * @return array The prepared student row data.
	 */
	private function prepareStudentRow($student, $wpdb)
	{
		// Remove 'sid' from the student array
		if (isset($student['sid'])) {
			unset($student['sid']);
		}

		// Fetch detailed information for various fields
		$class_table      = esc_sql($wpdb->prefix . 'astgdrmsys_class');
		$department_table = esc_sql($wpdb->prefix . 'astgdrmsys_department');
		$section_table    = esc_sql($wpdb->prefix . 'astgdrmsys_section');
		$exam_name_table  = esc_sql($wpdb->prefix . 'astgdrmsys_exam_name');
		$exam_year_table  = esc_sql($wpdb->prefix . 'astgdrmsys_exam_year');
		$subject_table    = esc_sql($wpdb->prefix . 'astgdrmsys_subject');

		// // Fetch detailed names
		//phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$class = $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT class FROM $class_table WHERE id = %d",
				intval($student['class'])
			)
		);

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$department = $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT department FROM $department_table WHERE id = %d",
				intval($student['department'])
			)
		);

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$section = $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT section FROM $section_table WHERE id = %d",
				intval($student['section'])
			)
		);

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$exam_name = $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT exam_name FROM $exam_name_table WHERE id = %d",
				intval($student['exam_name'])
			)
		);

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$exam_year = $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT exam_year FROM $exam_year_table WHERE id = %d",
				intval($student['exam_year'])
			)
		);

		// Replace IDs with actual names in the student array
		$student['class']      = $class;
		$student['section']    = $section;
		$student['department'] = $department;
		$student['exam_name']  = $exam_name;
		$student['exam_year']  = $exam_year;

		// Get student marks
		$marks = $this->getStudentMarks($student['sno'], $this->wpdb);

		// If marks is a nested array, use the first element
		$processedMarks = is_array($marks) && isset($marks[0]) && is_array($marks[0])
			? $marks[0]
			: $marks;

		// Fetch all subjects
		//phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$subjects = $wpdb->get_results(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT subcode, subname FROM $subject_table",
			ARRAY_A
		);

		// Add subject marks to the row
		foreach ($subjects as $subject) {
			$subcode = $subject['subcode'];
			$subname = $subject['subname'];

			// Check if this subject's code exists in marks
			$mark = isset($processedMarks[$subcode]) ? $processedMarks[$subcode] : 'N/A';

			// Add subject name and its mark to the row
			$student[$subname] = is_array($mark) ? implode(', ', $mark) : $mark;
		}

		return $student;
	}

	/**
	 * Retrieves the marks for a specific student.
	 *
	 * @param int $sid The ID of the student whose marks are to be retrieved.
	 * @return array An array containing the student's marks.
	 */
	private function getStudentMarks($sid, $wpdb)
	{
		$mark_table = esc_sql($wpdb->prefix . 'astgdrmsys_mark');
		//phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$markData = $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT marks FROM $mark_table WHERE sid = %d",
				intval($sid)
			)
		);
		return $markData ? unserialize($markData) : array();
	}

	/**
	 * Displays the list of all students.
	 *
	 * This function retrieves and displays the information of all students.
	 * It is used in the context of the 'all-students' menu in the RMS Result Management plugin.
	 *
	 * @return void
	 */
	private function displayStudents()
	{
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page   = isset($_GET['paginate']) ? (int) $_GET['paginate'] : 1;
		$offset = ($page - 1) * $this->limit;

		$students       = $this->getStudents($offset);
		$total_students = $this->getTotalStudents();

		$this->renderPage($students, $total_students, $page);
	}

	/**
	 * Retrieves a list of students with pagination.
	 *
	 * @param int $offset The offset for pagination.
	 * @return array The list of students.
	 */
	private function getStudents($offset)
	{
		global $wpdb;

		$offset = (int) $offset;
		$limit  = (int) $this->limit;

		// Check if a search was submitted
		if (isset($_POST['searchsubmit'])) {
			if (! isset($_POST['astgdrmsys_search_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['astgdrmsys_search_nonce'])), 'astgdrmsys_search_action')) {
				wp_die(esc_html__('Security check failed. Please refresh the page and try again.', 'result-management-system-for-institutions'));
			}

			// sanitize input
			$searchvar  = isset($_POST['search']) ? sanitize_text_field(wp_unslash($_POST['search'])) : '';
			$table_name = esc_sql($this->prefix . 'astgdrmsys_student_result');

			$sql = "SELECT * FROM `{$table_name}` WHERE `sno` = %d OR `name` LIKE %s LIMIT %d, %d";

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$query = $wpdb->prepare(
				$sql,
				(int) $searchvar,
				'%' . $wpdb->esc_like($searchvar) . '%',
				$offset,
				$limit
			);

			$cache_key = 'students_search_' . md5(maybe_serialize(array($searchvar, $offset, $limit)));
		} else {
			$table_name = esc_sql($this->prefix . 'astgdrmsys_student_result');

			$sql = "SELECT * FROM `{$table_name}` ORDER BY CAST(`sno` AS UNSIGNED) LIMIT %d, %d";

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$query = $wpdb->prepare($sql, $offset, $limit);

			$cache_key = 'students_all_' . md5(maybe_serialize(array($offset, $limit)));
		}

		$students = wp_cache_get($cache_key, 'rms');

		if (false === $students) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
			$students = $wpdb->get_results($query, ARRAY_A);
			wp_cache_set($cache_key, $students, 'rms', 300); // Cache for 5 minutes
		}

		return $students;
	}

	/**
	 * Retrieves the total number of students.
	 *
	 * @return int The total number of students.
	 */
	private function getTotalStudents()
	{
		$table_name = esc_sql($this->prefix . 'astgdrmsys_student_result');
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$query = $this->wpdb->prepare("SELECT COUNT(*) FROM `$table_name`");
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $this->wpdb->get_var($query);
	}

	/**
	 * Renders the page displaying all students.
	 *
	 * @param array $students Array of student data.
	 * @param int   $total_students Total number of students.
	 * @param int   $page Current page number.
	 */
	private function renderPage($students, $total_students, $page)
	{
		$total_pages = ceil($total_students / $this->limit); ?>
		<div id='print'>
			<h1 id='heading'>
				<center><a id='a' href='<?php echo esc_url(admin_url('admin.php?page=astgdrmsys-all-students')); ?>'>All Students</a></center>
			</h1>
			<center>
				<div class="student-actions-container">
					<div class="action-row">
						<form action="" method="post" class="export-form">
							<?php wp_nonce_field('export_action', 'export_nonce'); ?>
							<button type="submit" class="btn btn-export" name="export">
								<i class="dashicons dashicons-download"></i> Export CSV
							</button>
						</form>

						<div class="search-form-container">
							<form action='' method='post' class="search-form">
								<?php wp_nonce_field('astgdrmsys_search_action', 'astgdrmsys_search_nonce'); ?>
								<div class="search-input-group">
									<input type='text'
										class="search-input"
										name='search'
										placeholder='Search by Name or Roll Number'
										aria-label="Search"
										required>
									<button type="submit" class="btn btn-search" name='searchsubmit'>
										<i class="dashicons dashicons-search"></i> Search
									</button>
								</div>
							</form>
						</div>
					</div>

					<div class="student-count-banner">
						<span class="student-count-icon">
							<i class="dashicons dashicons-groups"></i>
						</span>
						<span class="student-count-text">
							<?php echo esc_html($total_students . ' Students in Database'); ?>
						</span>
					</div>
				</div>


				<table class="table" id="student-table">
					<tr>
						<th class="student-id">ID</th>
						<th>Roll Number</th>
						<th>Registration Number</th>
						<th>
							<center>Student Name</center>
						</th>
						<th>
							<center>Class</center>
						</th>
						<th>
							<center>Department</center>
						</th>
						<th>
							<center>Section</center>
						</th>
						<th>
							<center>Exam Name</center>
						</th>
						<th>
							<center>Exam Year</center>
						</th>
						<th>
							<center>Total Marks</center>
						</th>
						<th id='paddingaction'>Action</th>
					</tr>
					<?php
					if (count($students) > 0) {
						foreach ($students as $index => $student) {
							$this->renderStudentRow($student, $index + 1 + ($page - 1) * $this->limit, $this->wpdb);
						}
					} else {
						echo '<h2>No Record Found</h2>';
						echo '<center><a class="btn btn-primary" href="' . esc_url(admin_url('admin.php?page=astgdrmsys-all-students')) . '">See All Students</a></center>';
					}
					?>
				</table>
			</center>
		</div>
		<div id="pagination">
			<?php $this->renderPagination($total_pages, $page); ?>
		</div> <?php
	}

	/**
	 * Renders a row for a student in the table.
	 *
	 * @param array $student An associative array containing student data.
	 * @param int   $id The ID of the student.
	 */
	private function renderStudentRow($student, $id, $wpdb)
	{
		// Convert $student to array if it's an object
		if (is_object($student)) {
			$student = (array) $student;
		}

		$class = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare("SELECT `class` FROM `{$wpdb->prefix}astgdrmsys_class` WHERE `id` = %d", intval($student['class']))
		);

		$department = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare("SELECT `department` FROM `{$wpdb->prefix}astgdrmsys_department` WHERE `id` = %d", intval($student['department']))
		);

		$section = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare("SELECT `section` FROM `{$wpdb->prefix}astgdrmsys_section` WHERE `id` = %d", intval($student['section']))
		);

		$exam_name = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare("SELECT `exam_name` FROM `{$wpdb->prefix}astgdrmsys_exam_name` WHERE `id` = %d", intval($student['exam_name']))
		);

		$exam_year = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare("SELECT `exam_year` FROM `{$wpdb->prefix}astgdrmsys_exam_year` WHERE `id` = %d", intval($student['exam_year']))
		);

		// Determine the exam_type
		$exam_type = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT exam_type FROM {$wpdb->prefix}astgdrmsys_exam_name WHERE id = %d",
				intval($student['exam_name'])
			)
		);

		// Fetch Marks
		$marks = $this->getStudentMarks($student['sid'], $this->wpdb);

		// initialize $total_marks
		$total_marks = 0;
		if ($exam_type === 'single') {
			// Some single marks are wrapped inside $marks[0]
			if (isset($marks[0]) && is_array($marks[0])) {
				foreach ($marks[0] as $subject_code => $mark) {
					if (is_numeric($mark)) {
						$total_marks += $mark;
					}
				}
			} elseif (is_array($marks)) {
				// fallback: marks might be flat
				foreach ($marks as $subject_code => $mark) {
					if (is_numeric($mark)) {
						$total_marks += $mark;
					}
				}
			}
		} elseif ($exam_type === 'composite') {
			foreach ($marks as $subject_code => $components) {
				if (is_array($components) && isset($components['total'])) {
					$total_marks += floatval($components['total']);
				}
			}
		}

		$nonce_key = wp_create_nonce('get_id_nonce'); 
		// Create a specific nonce for the delete action
		$delete_nonce = wp_create_nonce('astgdrmsys_delete_record');
		?>
		<tr>
			<td class='padding student-id'>
				<center><?php echo esc_html($id); ?></center>
			</td>
			<td class='padding'>
				<center><?php echo esc_html($student['sno']); ?></center>
			</td>
			<td class='padding'>
				<center><?php echo esc_html($student['regno']); ?></center>
			</td>
			<td class='padding'>
				<center><?php echo esc_html($student['name']); ?></center>
			</td>
			<td class='padding'>
				<center><?php echo esc_html($class ?: "Class doesn't exist"); ?></center>
			</td>
			<td class='padding'>
				<center><?php echo esc_html($department ?: "Department doesn't exist"); ?></center>
			</td>
			<td class='padding'>
				<center><?php echo esc_html($section ?: "Section doesn't exist"); ?></center>
			</td>
			<td class='padding'>
				<center><?php echo esc_html($exam_name ?: "Exam Name doesn't exist"); ?></center>
			</td>
			<td class='padding'>
				<center><?php echo esc_html($exam_year ?: "Exam Year doesn't exist"); ?></center>
			</td>
			<td class='padding'>
				<center><?php echo esc_html($total_marks); ?></center>
			</td>
			<td>
				<a href="<?php echo esc_url(admin_url('admin.php?page=astgdrmsys-edit-record&id=' . intval($student['sid']) . '&_wpnonce=' . $nonce_key)); ?>"
					class="button button-small">
					<span class="dashicons dashicons-edit"></span>
				</a>
				<a href='<?php echo esc_url(admin_url('admin.php?page=astgdrmsys-delrec&id=' . intval($student['sid']) . '&_wpnonce=' . $delete_nonce)); ?>'
					onclick="return confirm('<?php esc_attr_e('Do You Really Want to Delete the Record?', 'result-management-system-for-institutions'); ?>');"
					class="button button-small button-link-delete">
					<span class="dashicons dashicons-trash"></span>
				</a>
			</td>
		</tr> <?php
	}

	/**
	 * Renders the pagination for a list of students.
	 *
	 * @param int $total_pages The total number of pages.
	 * @param int $current_page The current page number.
	 */
	private function renderPagination($total_pages, $current_page)
	{
		$prev_disabled = $current_page < 2 ? 'disabled' : '';
		$next_disabled = $current_page >= $total_pages ? 'disabled' : '';

		$prev_page = max(1, $current_page - 1);
		$next_page = min($total_pages, $current_page + 1);

		$base_url = admin_url('admin.php?page=astgdrmsys-all-students&paginate='); ?>
		<nav>
			<ul class="pagination justify-content-center">
				<!-- First Page -->
				<li class="page-item <?php echo esc_attr($prev_disabled); ?>">
					<a class="page-link" href="<?php echo esc_url($base_url . '1'); ?>" aria-label="First">«</a>
				</li>

				<!-- Previous Page -->
				<li class="page-item <?php echo esc_attr($prev_disabled); ?>">
					<a class="page-link" href="<?php echo esc_url($base_url . $prev_page); ?>" aria-label="Previous">‹</a>
				</li>

				<!-- Current Page -->
				<li class="page-item active">
					<a class="page-link" href=""><?php echo esc_html($current_page); ?></a>
				</li>

				<li class="page-item disabled">
					<span class="page-link">of</span>
				</li>

				<!-- Total Pages -->
				<li class="page-item">
					<a class="page-link" href="<?php echo esc_url($base_url . $total_pages); ?>">
						<?php echo esc_html($total_pages); ?>
					</a>
				</li>

				<!-- Next Page -->
				<li class="page-item <?php echo esc_attr($next_disabled); ?>">
					<a class="page-link" href="<?php echo esc_url($base_url . $next_page); ?>" aria-label="Next">›</a>
				</li>

				<!-- Last Page -->
				<li class="page-item <?php echo esc_attr($next_disabled); ?>">
					<a class="page-link" href="<?php echo esc_url($base_url . $total_pages); ?>" aria-label="Last">»</a>
				</li>
				</ul>
			</nav><?php
    }
}

/**
 * Creates a new instance of the ASTGDRMSYS_All_Students class.
 *
 * @param wpdb $wpdb The WordPress database object.
 */
new ASTGDRMSYS_All_Students($wpdb);
?>