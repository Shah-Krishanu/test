<?php

/**
 * Result Management System for Institutions
 *
 * Copyright (C) 2025 ASTGD
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

/**
 * This file is part of the Result Management System for Institutions plugin.
 *
 * It handles the addition of exam names in the plugin's menu.
 *
 * @package ResultManagementSystem
 * @subpackage Menu_Files
 * @since 1.0.0
 *
 * @file add-exam-name.php
 *
 * This file should not be accessed directly. If accessed directly, the script will exit.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ASTGDRMSYS_ExamName_Manager
 *
 * This class is responsible for managing exam names within the plugin.
 * It provides functionalities to add, edit, and delete exam names.
 *
 * @package ResultManagementSystem
 * @subpackage MenuFiles
 * @since 1.0.0
 */
class ASTGDRMSYS_ExamName_Manager {

	private $wpdb;
	private $prefix;

	/**
	 * Constructor method for the class.
	 *
	 * This method is automatically called when an instance of the class is created.
	 * It is typically used to initialize properties or set up any necessary configurations.
	 */
	public function __construct() {
		global $wpdb;
		$this->wpdb   = $wpdb;
		$this->prefix = $wpdb->prefix;
	}

	/**
	 * Initialize the exam name addition functionality.
	 *
	 * This method sets up the necessary components and configurations
	 * required for adding a new exam name within the plugin.
	 *
	 * @return void
	 */
	public function astgdrmsys_initialize() {
		$this->handle_actions();
		$this->astgdrmsys_render_examname_page();
	}

	/**
	 * Handles various actions related to exam names.
	 *
	 * This function processes different actions that can be performed
	 * on exam names within the plugin. It ensures that the appropriate
	 * action is taken based on the user's input or request.
	 *
	 * @return void
	 */
	private function handle_actions() {
		// Check if this is a POST request
		if ( isset( $_SERVER['REQUEST_METHOD'] ) && $_SERVER['REQUEST_METHOD'] === 'POST' ) {
			// Nonce check and sanitization
			if ( ! isset( $_POST['astgdrmsys_exam_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['astgdrmsys_exam_nonce'] ) ), 'astgdrmsys_exam_action' ) ) {
				wp_die( esc_html__( 'Invalid request. Please refresh and try again.', 'result-management-system-for-institutions' ) );
			}
		}

		// Handle delete action
		if ( isset( $_GET['delid'] ) && isset( $_GET['astgdrmsys_exam_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['astgdrmsys_exam_nonce'] ) ), 'astgdrmsys_exam_action' ) ) {
			$this->handle_delete();
		}

		// Handle update action
		if ( isset( $_POST['updatesubmit'] ) && isset( $_POST['astgdrmsys_exam_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['astgdrmsys_exam_nonce'] ) ), 'astgdrmsys_exam_action' ) ) {
			$this->handle_update();
		}

		// Handle add action
		if ( isset( $_POST['addsubmit'] ) && isset( $_POST['astgdrmsys_exam_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['astgdrmsys_exam_nonce'] ) ), 'astgdrmsys_exam_action' ) ) {
			$this->handle_add();
		}

		// handle publish action
		$this->handle_publish();
	}

	/**
	 * Handles the deletion of an exam name.
	 *
	 * This private function is responsible for managing the deletion process
	 * of an exam name within the plugin. It ensures that the necessary
	 * operations are performed to remove the exam name from the system.
	 *
	 * @return void
	 */
	private function handle_delete() {
		// Check if the delete ID is set and nonce is valid
		if ( isset( $_GET['delid'], $_GET['astgdrmsys_exam_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['astgdrmsys_exam_nonce'] ) ), 'astgdrmsys_exam_action' ) ) {
			$delid = absint( wp_unslash( $_GET['delid'] ) );
		}
		// Sanitize and validate the delete ID
		$deleted = $this->wpdb->delete(
			$this->prefix . 'astgdrmsys_exam_name',
			array( 'id' => $delid )
		);

		// Check if the deletion was successful
		if ( $deleted ) {
			wp_safe_redirect( add_query_arg( 'del', 'true', admin_url( 'admin.php?page=astgdrmsys-exam-name' ) ) );
			exit;
		}
	}

	/**
	 * Handles the update process for the exam name.
	 *
	 * This function is responsible for managing the update logic
	 * related to exam names within the plugin.
	 *
	 * @return void
	 */
	private function handle_update() {
		// Check if the form is submitted and nonce is valid
		if ( ! isset( $_POST['astgdrmsys_exam_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['astgdrmsys_exam_nonce'] ) ), 'astgdrmsys_exam_action' ) ) {
			wp_die( esc_html__( 'Security check failed', 'result-management-system-for-institutions' ) );
		}

		// Check if the edit ID is set
		if ( ! isset( $_GET['editid'] ) ) {
			return;
		}
		// Sanitize and validate the input data
		$exam_year_raw   = isset( $_POST['updateexam_year'] ) ? sanitize_text_field( wp_unslash( $_POST['updateexam_year'] ) ) : '';
		$exam_year_array = explode( ',', $exam_year_raw );
		$publish_status  = isset( $_POST['update_result_publish_status'] ) ? 1 : 0;
		$editid          = isset( $_GET['editid'] ) ? absint( wp_unslash( $_GET['editid'] ) ) : 0;

		$data = array(
			'exam_name'             => isset( $_POST['updateexam_name'] ) ? sanitize_text_field( wp_unslash( $_POST['updateexam_name'] ) ) : '',
			'department'            => isset( $_POST['updatedepartment'] ) ? sanitize_text_field( wp_unslash( $_POST['updatedepartment'] ) ) : '',
			'class'                 => isset( $_POST['updateHiddenClassname'] ) ? sanitize_text_field( wp_unslash( $_POST['updateHiddenClassname'] ) ) : '',
			'exam_year'             => isset( $exam_year_array[0] ) ? trim( $exam_year_array[0] ) : '',
			'exam_year_id'          => isset( $exam_year_array[1] ) ? trim( $exam_year_array[1] ) : '',
			'exam_type'             => isset( $_POST['update_exam_type'] ) ? sanitize_text_field( wp_unslash( $_POST['update_exam_type'] ) ) : 'single',
			'result_title'          => isset( $_POST['update_result_title'] ) ? sanitize_text_field( wp_unslash( $_POST['update_result_title'] ) ) : '',
			'result_subtitle'       => isset( $_POST['update_result_subtitle'] ) ? sanitize_text_field( wp_unslash( $_POST['update_result_subtitle'] ) ) : '',
			'result_footer_text'    => isset( $_POST['update_result_footer_text'] ) ? sanitize_text_field( wp_unslash( $_POST['update_result_footer_text'] ) ) : '',
			'result_publish_status' => $publish_status,
		);

		// sql query to update
		$updated = $this->wpdb->update(
			$this->prefix . 'astgdrmsys_exam_name',
			$data,
			array( 'id' => $editid )
		);

		// redirecting url to show message
		if ( $updated ) {
			wp_safe_redirect( add_query_arg( 'edit', 'true', admin_url( 'admin.php?page=astgdrmsys-exam-name' ) ) );
			exit;
		}
	}

	/**
	 * Handles the publishing of an exam name.
	 *
	 * This function is responsible for managing the publishing process
	 * of an exam name within the plugin. It ensures that the necessary
	 * operations are performed to publish the exam name.
	 *
	 * @return void
	 */
	private function handle_publish() {
		if ( isset( $_SERVER['REQUEST_METHOD'] ) && $_SERVER['REQUEST_METHOD'] === 'POST' ) {
			// Nonce check and sanitization
			if ( ! isset( $_POST['astgdrmsys_exam_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['astgdrmsys_exam_nonce'] ) ), 'astgdrmsys_exam_action' ) ) {
				wp_die( esc_html__( 'Invalid request. Please refresh and try again.', 'result-management-system-for-institutions' ) );
			}
		}

		// Check if the publish ID is set
		$pubid = isset( $_GET['pubid'] ) ? absint( wp_unslash( $_GET['pubid'] ) ) : 0;

		$data = array(
			'result_publish_status' => 1,
		);

		$updated = $this->wpdb->update(
			$this->prefix . 'astgdrmsys_exam_name',
			$data,
			array( 'id' => $pubid )
		);

		if ( $updated ) {
			wp_safe_redirect( add_query_arg( 'publish', 'true', admin_url( 'admin.php?page=astgdrmsys-exam-name' ) ) );
			exit;
		}
	}

	/**
	 * Handles the addition of a new exam name.
	 *
	 * This function processes the form submission for adding a new exam name.
	 * It validates the input data, saves the new exam name to the database,
	 * and provides feedback to the user.
	 *
	 * @return void
	 */
	private function handle_add() {
		if ( ! isset( $_POST['astgdrmsys_exam_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['astgdrmsys_exam_nonce'] ) ), 'astgdrmsys_exam_action' ) ) {
			wp_die( esc_html__( 'Security check failed', 'result-management-system-for-institutions' ) );
		}

		$exam_array     = isset( $_POST['exam_year'] ) ? explode( '-', sanitize_text_field( wp_unslash( $_POST['exam_year'] ) ) ) : array( '', 0 );
		$dept_array     = isset( $_POST['departmentadd'] ) ? explode( '-', sanitize_text_field( wp_unslash( $_POST['departmentadd'] ) ) ) : array( '', 0 );
		$publish_status = isset( $_POST['result_publish_status'] ) ? 1 : 0;

		$data = array(
			'exam_name'             => isset( $_POST['exam_name'] ) ? sanitize_text_field( wp_unslash( $_POST['exam_name'] ) ) : '',
			'department'            => trim( $dept_array[0] ),
			'class'                 => isset( $_POST['hiddenclassname'] ) ? sanitize_text_field( wp_unslash( $_POST['hiddenclassname'] ) ) : '',
			'class_id'              => isset( $_POST['hiddenclassid'] ) ? intval( wp_unslash( $_POST['hiddenclassid'] ) ) : 0,
			'exam_year'             => trim( $exam_array[0] ),
			'exam_year_id'          => isset( $_POST['hiddenExamYearId'] ) ? intval( wp_unslash( $_POST['hiddenExamYearId'] ) ) : 0,
			'exam_type'             => isset( $_POST['exam_type'] ) ? sanitize_text_field( wp_unslash( $_POST['exam_type'] ) ) : 'single',
			'result_title'          => isset( $_POST['result_title'] ) ? sanitize_text_field( wp_unslash( $_POST['result_title'] ) ) : '',
			'result_subtitle'       => isset( $_POST['result_subtitle'] ) ? sanitize_text_field( wp_unslash( $_POST['result_subtitle'] ) ) : '',
			'result_footer_text'    => isset( $_POST['result_footer_text'] ) ? sanitize_text_field( wp_unslash( $_POST['result_footer_text'] ) ) : '',
			'result_publish_status' => $publish_status,
		);

		$inserted = $this->wpdb->insert(
			$this->prefix . 'astgdrmsys_exam_name',
			$data
		);

		if ( $inserted ) {
			wp_safe_redirect( add_query_arg( 'add', 'true', admin_url( 'admin.php?page=astgdrmsys-exam-name' ) ) );
			exit;
		}
	}

	/**
	 * Retrieves the list of departments.
	 *
	 * @return array An array of departments.
	 */
	private function get_departments( $wpdb ) {
		$cache_key   = 'astgdrmsys_departments';
		$departments = wp_cache_get( $cache_key );

		if ( $departments === false ) {
			$class_table      = esc_sql( $wpdb->prefix . 'astgdrmsys_class' );
			$department_table = esc_sql( $wpdb->prefix . 'astgdrmsys_department' );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
			$departments = $wpdb->get_results(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT d.id, d.department, d.class AS class_id, c.class AS class_name FROM `$department_table` d JOIN `$class_table` c ON d.class = c.id",
				ARRAY_A
			);

			if ( $departments ) {
				wp_cache_set( $cache_key, $departments );
			}
		}

		return $departments;
	}

	/**
	 * Retrieves the list of exam years.
	 *
	 * This function fetches and returns an array of years for which exams are available.
	 *
	 * @return array An array of exam years.
	 */
	private function get_exam_years( $wpdb ) {
		$cache_key  = 'astgdrmsys_exam_years';
		$exam_years = wp_cache_get( $cache_key );

		if ( $exam_years === false ) {
			$examyear_table = esc_sql( $this->prefix . 'astgdrmsys_exam_year' );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
			$exam_years = $wpdb->get_results(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT DISTINCT ey.id AS exam_year_id, ey.exam_year FROM `$examyear_table` ey",
				ARRAY_A
			);

			if ( $exam_years ) {
				wp_cache_set( $cache_key, $exam_years );
			}
		}

		return $exam_years;
	}


	/**
	 * Retrieves the list of exam names.
	 *
	 * @return array An array of exam names.
	 */
	private function get_exam_names( $wpdb ) {
		$cache_key  = 'astgdrmsys_exam_names';
		$exam_names = wp_cache_get( $cache_key );

		if ( $exam_names === false ) {
			$examname_table   = esc_sql( $this->prefix . 'astgdrmsys_exam_name' );
			$department_table = esc_sql( $this->prefix . 'astgdrmsys_department' );
			$examyear_table   = esc_sql( $this->prefix . 'astgdrmsys_exam_year' );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
			$exam_names = $wpdb->get_results(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT e.id, e.exam_name, e.class, d.department, ey.exam_year, e.result_title, e.result_subtitle, e.result_footer_text, e.result_publish_status FROM `$examname_table` e JOIN `$department_table` d ON e.department = d.id JOIN `$examyear_table` ey ON e.exam_year_id = ey.id",
				ARRAY_A
			);

			if ( $exam_names ) {
				wp_cache_set( $cache_key, $exam_names );
			}
		}

		return $exam_names;
	}


	/**
	 * Renders messages to be displayed in the admin interface.
	 *
	 * This function is responsible for outputting any messages that need to be
	 * shown to the user, such as success or error notifications.
	 *
	 * @return void
	 */
	private function astgdrmsys_render_messages() {

		$messages = array(
			'edit'    => __( 'Exam Name Updated Successfully', 'result-management-system-for-institutions' ),
			'del'     => __( 'Exam Name Deleted Successfully', 'result-management-system-for-institutions' ),
			'add'     => __( 'Exam Name Added Successfully', 'result-management-system-for-institutions' ),
			'publish' => __( 'Selected exam has been published successfully', 'result-management-system-for-institutions' ),
		);

		foreach ( $messages as $key => $message ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( isset( $_GET[ $key ] ) && $_GET[ $key ] === 'true' ) {
				echo wp_kses_post( $this->get_alert_html( $message ) );
			}
		}
	}

	/**
	 * Generates the HTML for an alert message.
	 *
	 * @param string $message The message to be displayed in the alert.
	 * @return string The HTML string for the alert message.
	 */
	private function get_alert_html( $message ) {
		return sprintf(
			'<div id="message_div" class="alert alert-success">
                <center>%s</center>
                <button class="close-message" aria-label="Close">&times;</button>
            </div>',
			esc_html( $message )
		);
	}

	/**
	 * Renders the page for adding a new exam name.
	 *
	 * This function is responsible for generating the HTML and handling any
	 * necessary logic to display the form for adding a new exam name in the
	 * admin panel.
	 *
	 * @return void
	 */
	private function astgdrmsys_render_examname_page() {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['editid'] ) ) {
			$this->astgdrmsys_render_edit_form( $this->wpdb );
		} else {
			$this->astgdrmsys_render_main_page();
		}
	}

	/**
	 * Renders the form for editing an exam name.
	 *
	 * This function generates and displays the HTML form used for editing
	 * an existing exam name within the plugin.
	 *
	 * @return void
	 */
	private function astgdrmsys_render_edit_form( $wpdb ) {
		if ( isset( $_GET['editid'], $_GET['astgdrmsys_exam_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['astgdrmsys_exam_nonce'] ) ), 'astgdrmsys_exam_action' ) ) {
			// Get the exam ID
			$editid = isset( $_GET['editid'] ) ? absint( wp_unslash( $_GET['editid'] ) ) : 0;

			// Get the exam details
			$cache_key = 'exam_name_' . $editid;
			$exam      = wp_cache_get( $cache_key );

			if ( $exam === false ) {
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery
				$exam = $wpdb->get_row(
					$wpdb->prepare(
                        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						"SELECT * FROM {$this->prefix}astgdrmsys_exam_name WHERE `id` = %d",
						$editid
					),
					ARRAY_A
				);

				wp_cache_set( $cache_key, $exam );
			}

			if ( ! $exam ) {
				wp_die( esc_html_e( 'Exam not found', 'result-management-system-for-institutions' ) );
			}
		} else {
			wp_die( esc_html_e( 'Invalid request.', 'result-management-system-for-institutions' ) );

		}

		$departments = $this->get_departments( $wpdb );
		$exam_years  = $this->get_exam_years( $wpdb );
		?>
		<div class='container'>
			<h3 class='heading text-center mb-4'><?php esc_html_e( 'Edit Exam Name', 'result-management-system-for-institutions' ); ?></h3>
			<form method='post' action='' class="edit-form">
				<?php wp_nonce_field( 'astgdrmsys_exam_action', 'astgdrmsys_exam_nonce' ); ?>
				<div class="form-group row mb-3">
					<label class="col-sm-3 col-form-label"><strong><?php esc_html_e( 'Enter Exam Name:', 'result-management-system-for-institutions' ); ?></strong></label>
					<div class="col-sm-9">
						<input type='text'
							class="form-control"
							name='updateexam_name'
							value='<?php echo esc_attr( $exam['exam_name'] ); ?>'
							required>
						<input type='hidden'
							name='updateHiddenClassname'
							id="updateHiddenClassname"
							value='<?php echo esc_attr( $exam['class'] ); ?>'>
					</div>
				</div>

				<div class="form-group row mb-3">
					<label class="col-sm-3 col-form-label"><strong><?php esc_html_e( 'Select Department:', 'result-management-system-for-institutions' ); ?></strong></label>
					<div class="col-sm-9">
						<select name="updatedepartment"
							id="updateSelectId"
							class="form-control"
							required>
							<?php foreach ( $departments as $department ) : ?>
								<option value="<?php echo esc_attr( $department['id'] ); ?>"
									<?php selected( $exam['department'], $department['id'] ); ?>>
									<?php echo esc_html( $department['department'] . ' - ' . $department['class_name'] ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>

				<div class="form-group row mb-3">
					<label class="col-sm-3 col-form-label"><strong><?php esc_html_e( 'Select Exam Year:', 'result-management-system-for-institutions' ); ?></strong></label>
					<div class="col-sm-9">
						<select name='updateexam_year'
							id="updateExamYear"
							class="form-control"
							required>
							<option value="" disabled <?php selected( empty( $exam['exam_year'] ) ); ?>>
								<?php esc_html_e( 'Select an Exam Year', 'result-management-system-for-institutions' ); ?>
							</option>
							<?php foreach ( $exam_years as $exam_year ) : ?>
								<option value="<?php echo esc_attr( $exam_year['exam_year'] . ',' . $exam_year['exam_year_id'] ); ?>"
									<?php
									selected(
										$exam_year['exam_year'] . ',' . $exam_year['exam_year_id'],
										$exam['exam_year'] . ',' . $exam['exam_year_id']
									);
									?>
									>
									<?php echo esc_html( $exam_year['exam_year'] ); ?>
								</option>
							<?php endforeach; ?>
						</select>

					</div>
				</div>

				<!-- Exam Type -->
				<div class="form-group row mb-3">
					<label class="col-sm-3 col-form-label">
						<strong><?php esc_html_e( 'Exam Type:', 'result-management-system-for-institutions' ); ?></strong>
					</label>
					<div class="col-sm-9">
						<select class="form-control" name="update_exam_type" required>
							<option value="single" <?php selected( $exam['exam_type'], 'single' ); ?>>
								<?php esc_html_e( 'Single Assessment', 'result-management-system-for-institutions' ); ?>
							</option>
							<option value="composite" <?php selected( $exam['exam_type'], 'composite' ); ?>>
								<?php esc_html_e( 'Composite Assessment', 'result-management-system-for-institutions' ); ?>
							</option>
						</select>
					</div>
				</div>

				<h4 class='heading text-center mb-4'><?php esc_html_e( 'To be Shown on the Result Marksheet', 'result-management-system-for-institutions' ); ?></h4>
				<div class="form-group row mb-3">
					<!-- Update Result Title -->
					<label class="col-sm-3 col-form-label"><strong><?php esc_html_e( 'Result Title:', 'result-management-system-for-institutions' ); ?></strong></label>
					<div class="col-sm-9">
						<input type='text'
							class="form-control"
							name='update_result_title'
							value='<?php echo esc_attr( $exam['result_title'] ); ?>'
							required>
					</div>
					<!-- Update Result Subtitle -->
					<label class="col-sm-3 col-form-label"><strong><?php esc_html_e( 'Result Subtitle:', 'result-management-system-for-institutions' ); ?></strong></label>
					<div class="col-sm-9">
						<input type='text'
							class="form-control"
							name='update_result_subtitle'
							value='<?php echo esc_attr( $exam['result_subtitle'] ); ?>'
							required>
					</div>
					<!-- Update Result Footer Text -->
					<label class="col-sm-3 col-form-label"><strong><?php esc_html_e( 'Result Footer Text:', 'result-management-system-for-institutions' ); ?></strong></label>
					<div class="col-sm-9">
						<input type='text'
							class="form-control"
							name='update_result_footer_text'
							value='<?php echo esc_attr( $exam['result_footer_text'] ); ?>'
							required>
					</div>
					<!-- Update Result Publish Status -->
					<div class="form-group">
						<div class="custom-control custom-switch">
							<input type="checkbox"
								class="custom-control-input"
								id="update-result-publish-status"
								name="update_result_publish_status"
								value="0"
								<?php echo ( $exam['result_publish_status'] == 1 ) ? 'checked' : ''; ?>>
							<label class="custom-control-label" for="update-result-publish-status">
								<?php esc_html_e( 'Publish Exam', 'result-management-system-for-institutions' ); ?>
							</label>
						</div>
					</div>
					<!-- Button for Update and Cancel  -->
					<div class="form-group row align-center mt-4">
						<input type='submit'
							value='<?php esc_html_e( 'Update', 'result-management-system-for-institutions' ); ?>'
							class='btn btn-primary'
							name='updatesubmit'>
						<button type="button"
							class="btn btn-danger ml-2"
							onclick="window.history.back();"><?php esc_html_e( 'Cancel', 'result-management-system-for-institutions' ); ?>
						</button>
					</div>
			</form>
		</div>
		<?php
	}

	/**
	 * Renders the main page for the exam name management.
	 *
	 * This function is responsible for displaying the main interface
	 * where users can add or manage exam names within the plugin.
	 *
	 * @return void
	 */
	private function astgdrmsys_render_main_page() {
		global $wpdb;
		$exam_names  = $this->get_exam_names( $wpdb );
		$departments = $this->get_departments( $wpdb );
		$exam_years  = $this->get_exam_years( $wpdb );
		?>
		<div class='wrap'>
			<h1 class='wp-heading-inline'><?php esc_html_e( 'Exam Names', 'result-management-system-for-institutions' ); ?></h1>
			<button id="openModalBtn" class='page-title-action'>
				<?php esc_html_e( 'Add New', 'result-management-system-for-institutions' ); ?>
			</button>

			<?php $this->astgdrmsys_render_messages(); ?>

			<div class="table-responsive mt-4">
				<table class="table table-striped table-bordered">
					<thead class="thead-dark">
						<tr>
							<th scope="col"><?php esc_html_e( 'ID', 'result-management-system-for-institutions' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Exam Name', 'result-management-system-for-institutions' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Department', 'result-management-system-for-institutions' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Class', 'result-management-system-for-institutions' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Exam Year', 'result-management-system-for-institutions' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Result Title', 'result-management-system-for-institutions' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Result Subtitle', 'result-management-system-for-institutions' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Result Footer Text', 'result-management-system-for-institutions' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Publish Status', 'result-management-system-for-institutions' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Actions', 'result-management-system-for-institutions' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( ! empty( $exam_names ) ) : ?>
							<?php foreach ( $exam_names as $exam ) : ?>
								<tr>
									<td><?php echo esc_html( $exam['id'] ); ?></td>
									<td><?php echo esc_html( $exam['exam_name'] ); ?></td>
									<td><?php echo esc_html( $exam['department'] ); ?></td>
									<td><?php echo esc_html( $exam['class'] ); ?></td>
									<td><?php echo esc_html( $exam['exam_year'] ); ?></td>
									<td><?php echo esc_html( $exam['result_title'] ); ?></td>
									<td><?php echo esc_html( $exam['result_subtitle'] ); ?></td>
									<td><?php echo esc_html( $exam['result_footer_text'] ); ?></td>
									<td>
										<?php
										$status       = $exam['result_publish_status'];
										$status_class = $status == 1 ? 'text-success' : 'text-danger';
										$status_text  = $status == 1 ? __( 'Published', 'result-management-system-for-institutions' ) : __( 'Not Published', 'result-management-system-for-institutions' );
										?>
										<span class="badge <?php echo esc_attr( $status_class ); ?>">
											<?php echo esc_html( $status_text ); ?>
										</span>
									</td>

									<td>
										<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'editid' => $exam['id'] ) ), 'astgdrmsys_exam_action', 'astgdrmsys_exam_nonce' ) ); ?>"
											class="button button-small" title="Edit">
											<span class="dashicons dashicons-edit"></span>
										</a>
										<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'pubid' => $exam['id'] ) ), 'astgdrmsys_exam_action' ) ); ?>"
											class="button button-small" title="Approve">
											<span class="dashicons dashicons-yes"></span>
										</a>
										<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'delid' => $exam['id'] ) ), 'astgdrmsys_exam_action', 'astgdrmsys_exam_nonce' ) ); ?>"
											class="button button-small button-link-delete"
											onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to delete this exam?', 'result-management-system-for-institutions' ); ?>');" title="Delete">
											<span class="dashicons dashicons-trash"></span>
										</a>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php else : ?>
							<tr>
								<td colspan="6" class="text-center">
									<?php esc_html_e( 'No exam names found.', 'result-management-system-for-institutions' ); ?>
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>

			<!-- Add Modal -->
			<div id="addmodal" class="modal">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title"><?php esc_html_e( 'Add New Exam Name', 'result-management-system-for-institutions' ); ?></h5>
							<button type="button" class="close" id="closeModalBtn">
								<span>&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<form method="post" action="">
								<?php wp_nonce_field( 'astgdrmsys_exam_action', 'astgdrmsys_exam_nonce' ); ?>
								<div class="form-group">
									<label for="exam_name"><?php esc_html_e( 'Exam Name', 'result-management-system-for-institutions' ); ?></label>
									<input type="text" class="form-control"
										name="exam_name" required>
								</div>

								<div class="form-group">
									<label for="departmentadd"><?php esc_html_e( 'Department & Class', 'result-management-system-for-institutions' ); ?></label>
									<select name="departmentadd" id="selectDepartmentId"
										class="form-control" required>
										<option value="" disabled selected>
											<?php esc_html_e( 'Select a Department with Class', 'result-management-system-for-institutions' ); ?>
										</option>
										<?php foreach ( $departments as $department ) : ?>
											<option value="<?php echo esc_attr( $department['id'] . '-' . $department['class_id'] ); ?>">
												<?php echo esc_html( $department['department'] . ' - ' . $department['class_name'] ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>

								<div class="form-group">
									<label for="exam_year"><?php esc_html_e( 'Exam Year', 'result-management-system-for-institutions' ); ?></label>
									<select name="exam_year" id="ExamYearId"
										class="form-control">
										<option value="" disabled selected>
											<?php esc_html_e( 'Select Exam Year', 'result-management-system-for-institutions' ); ?>
										</option>
										<?php foreach ( $exam_years as $exam_year ) : ?>
											<option value="<?php echo esc_attr( $exam_year['exam_year'] . '-' . $exam_year['exam_year_id'] ); ?>">
												<?php echo esc_html( $exam_year['exam_year'] ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>

								<!-- Exam Type -->
									<div class="form-group mt-3">
										<label for="exam_type"><?php esc_html_e( 'Exam Type', 'result-management-system-for-institutions' ); ?></label>
										<select class="form-control" name="exam_type" id="exam_type">
											<option value="single"><?php esc_html_e( 'Single Assessment', 'result-management-system-for-institutions' ); ?></option>
											<option value="composite"><?php esc_html_e( 'Composite Assessment', 'result-management-system-for-institutions' ); ?></option>
										</select>
									</div>

								<div class="form-group">
									<!-- Result Title -->
									<label for="result-title"><?php esc_html_e( 'Result Title', 'result-management-system-for-institutions' ); ?></label>
									<input type="text" class="form-control" name="result_title" required>
									<!-- Result Subtitle -->
									<label for="result-subtitle"><?php esc_html_e( 'Result Subtitle', 'result-management-system-for-institutions' ); ?></label>
									<input type="text" class="form-control" name="result_subtitle" required>
									<!-- Result footer text -->
									<label for="result-footer-text"><?php esc_html_e( 'Result Footer Text', 'result-management-system-for-institutions' ); ?></label>
									<input type="text" class="form-control" name="result_footer_text" required>
									<!-- Publish Toggle -->
									<div class="form-group mt-3">
										<div class="custom-control custom-switch">
											<input type="checkbox"
												class="custom-control-input"
												id="result-publish-status"
												name="result_publish_status"
												value="0">
											<label class="custom-control-label" for="result-publish-status">
												<?php esc_html_e( 'Publish Exam', 'result-management-system-for-institutions' ); ?>
											</label>
											
										</div>
									</div>
								</div>
								<!-- Hidden Input Fields  -->
								<input type="hidden" name="hiddenclassname" id="hiddenclassname">
								<input type="hidden" name="hiddenclassid" id="hiddenclassid">
								<input type="hidden" name="hiddenExamYearId" id="hiddenExamYearId">

								<!-- Buttons for Submit and Cancel -->
								<div class="modal-footer">
									<button type="submit" name="addsubmit" class="btn btn-primary">
										<?php esc_html_e( 'Add Exam Name', 'result-management-system-for-institutions' ); ?>
									</button>
									<button type="button" class="btn btn-danger"
										onclick="document.getElementById('addmodal').style.display='none'">
										<?php esc_html_e( 'Cancel', 'result-management-system-for-institutions' ); ?>
									</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}

/**
 * Initializes the ASTGDRMSYS_ExamName_Manager and sets it up for use.
 *
 * Usage:
 * $exam_manager = new ASTGDRMSYS_ExamName_Manager();
 * $exam_manager->astgdrmsys_initialize();
 */
$exam_manager = new ASTGDRMSYS_ExamName_Manager();
$exam_manager->astgdrmsys_initialize();
?>