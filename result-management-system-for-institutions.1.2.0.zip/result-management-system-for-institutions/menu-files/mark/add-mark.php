<?php
/**
 * Result Management System for Institutions
 *
 * Copyright (C) 2025 ASTGD
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */
/**
 * Prevents direct access to the file.
 *
 * This code checks if the file is being accessed directly by verifying if the
 * ABSPATH constant is defined. If ABSPATH is not defined, it means the file
 * is being accessed directly, and the script will exit to prevent unauthorized access.
 *
 * @package ResultManagementSystem
 * @subpackage MenuFiles/Mark
 */
if (! defined('ABSPATH')) {
	exit;
}

/**
 * Class ASTGDRMSYS_Marks_Manager
 *
 * Handles mark operations for the Result Management System for Institutions
 */
class ASTGDRMSYS_Marks_Manager
{
	/**
	 * @var wpdb WordPress database object
	 */
	private $wpdb;

	/**
	 * @var string Database table prefix
	 */
	private $prefix;

	/**
	 * Constructor
	 */
	public function __construct()
	{
		global $wpdb;
		$this->wpdb   = $wpdb;
		$this->prefix = $wpdb->prefix;

		$this->init();
	}

	/**
	 * Initialize the class
	 */
	private function init()
	{
		$this->displayMessage();

		// First, check if we're trying to add marks for a specific student
		if (isset($_GET['addid'])) {
			// Verify nonce when accessing student-specific actions
			if (! isset($_GET['astgdrmsys_mark_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['astgdrmsys_mark_nonce'])), 'astgdrmsys_mark_action')) {
				wp_die(esc_html__('Invalid or expired request.', 'result-management-system-for-institutions'));
			}

			$stuid = absint(wp_unslash($_GET['addid']));
			$this->renderAddMarksForm($stuid);
		} else {
			// Render the main view (no nonce needed for initial view)
			$this->renderView();

			// If class and exam are selected, show students
			if (isset($_GET['classsearch'], $_GET['examname'])) {
				$this->handleClassExamSearch();
			}
		}
	}

	/**
	 * Display success message
	 */
	public function displayMessage()
	{
		// phpcs:ignore WordPress.Security.NonceVerification
		if (isset($_GET['insert']) && $_GET['insert'] === 'true') {
			echo "
            <div id='message_div' class='alert alert-success custom-message'>
               <div class='message-content'>
                  <center>Marks have been added Successfully.</center>
                  <button class='close-message' aria-label='Close'>&times;</button>
                  </div>
            </div>";
		}
	}

	/**
	 * Fetch classes
	 *
	 * @return array List of classes
	 */
	public function fetchClasses()
	{
		$class_table = esc_sql($this->prefix . 'astgdrmsys_class');
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return $this->wpdb->get_results(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT * FROM $class_table",
			ARRAY_A
		);
	}

	/**
	 * Fetch students
	 *
	 * @param int $classsearch Class ID
	 * @param int $examNameSearch Exam ID
	 * @param string $searchvalue Search term
	 * @return array List of students
	 */
	public function fetchStudents($classsearch, $examNameSearch, $searchvalue = '')
	{
		global $wpdb;

		$classsearch    = (int) $classsearch;
		$examNameSearch = (int) $examNameSearch;
		$searchvalue    = sanitize_text_field($searchvalue);

		$result_table = esc_sql($this->prefix . 'astgdrmsys_student_result');

		$args        = array($classsearch, $examNameSearch);
		$searchQuery = '';

		if (! empty($searchvalue)) {
			$searchQuery = ' AND (CAST(`sno` AS UNSIGNED) LIKE %s OR `name` LIKE %s)';
			$like_search = '%' . $wpdb->esc_like($searchvalue) . '%';
			$args[]      = $like_search;
			$args[]      = $like_search;
		}

		$sql = "SELECT * FROM {$result_table} WHERE `class` = %d AND `exam_name` = %d {$searchQuery} ORDER BY CAST(`sno` AS UNSIGNED) ASC";

		// Generate a unique cache key based on query arguments.
		$cache_key = 'students_' . md5(maybe_serialize($args));
		$students  = wp_cache_get($cache_key, 'rms');

		if (false === $students) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$students = $wpdb->get_results(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				$wpdb->prepare($sql, $args),
				ARRAY_A
			);

			wp_cache_set($cache_key, $students, 'rms', 300); // Cache for 5 minutes.
		}

		return $students;
	}

	/**
	 * Fetch exam name
	 *
	 * @param int $examId Exam ID
	 * @return string Exam name
	 */
	public function fetchExamName($examId)
	{
		global $wpdb;
		// sanitize sql
		$examname_table = esc_sql($this->prefix . 'astgdrmsys_exam_name');
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT exam_name FROM $examname_table WHERE id = %d",
				$examId
			)
		);
	}

	/**
	 * Fetch class name
	 *
	 * @param int $classId Class ID
	 * @return string Class name
	 */
	public function fetchClassName($classId)
	{
		global $wpdb;
		// sanitize sql
		$class_table = esc_sql($this->prefix . 'astgdrmsys_class');
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT class FROM $class_table WHERE id = %d",
				$classId
			)
		);
	}

	/**
	 * Render main view
	 */
	public function renderView()
	{ ?>
		<div class='container'>
			<div>
				<center>
					<h3 class='main-heading'><strong>View Marks</strong></h3>
				</center>
			</div>
			<form method='get' action='' id="submitForm">
				<input type="hidden" name="page" value="astgdrmsys-add-mark">
				<table class='table'>
					<tr class="title-tr">
						<td><strong>Select Class :</strong></td>
						<td>
							<select class="selectClass" name="classsearch" required>
								<option value="" selected disabled>Select a Class</option>
								<?php
								$classes = $this->fetchClasses();
								foreach ($classes as $class) {
									echo "<option value='" . esc_html($class['id']) . "'>" . esc_html($class['class']) . '</option>';
								}
								?>
							</select>
						</td>
					</tr>
					<tr class="title-tr">
						<td><strong>Select Exam Name:</strong></td>
						<td>
							<select id="selectExam" name="examname" required>
								<option value="">Select Class First</option>
							</select>
						</td>
					</tr>
					<tr class="title-tr">
						<td></td>
						<td><input type='submit' value='See Students' class='btn btn-primary submit-btn'></td>
					</tr>
				</table>
			</form>
		</div> <?php
	}

	/**
	 * Handle class and exam search
	 */
	public function handleClassExamSearch()
	{
		// Check if the form was submitted
		if (isset($_POST['searchsubmit'])) {
			// Verify nonce for security
			if (! isset($_POST['astgdrmsys_search_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['astgdrmsys_search_nonce'])), 'astgdrmsys_search_action')) {
				wp_die(esc_html__('Invalid search request.', 'result-management-system-for-institutions'));
			}
		}
		// sanitize and validate inputs
		$classsearch    = isset($_GET['classsearch']) ? absint(wp_unslash($_GET['classsearch'])) : 0;
		$examnameFull   = isset($_GET['examname']) ? sanitize_text_field(wp_unslash($_GET['examname'])) : '';
		$examnameParts  = explode(',', $examnameFull);
		$examNameSearch = isset($examnameParts[0]) ? absint($examnameParts[0]) : 0;
		// fetch class and exam names
		$classname = $this->fetchClassName($classsearch);
		$examname  = $this->fetchExamName($examNameSearch);

		$searchvalue = isset($_POST['searchsubmit'], $_POST['search']) ? sanitize_text_field(wp_unslash($_POST['search'])) : '';
		// fetch students based on class, exam, and search value
		$students = $this->fetchStudents($classsearch, $examNameSearch, $searchvalue);
		$this->renderStudentTable($students, $classname, $examname);
	}

	/**
	 * Render student table
	 *
	 * @param array  $students List of students
	 * @param string $classname Class name
	 * @param string $examname Exam name
	 */
	public function renderStudentTable($students, $classname, $examname)
	{  ?>
		<div class='students-container m-4 px-1'>
			<center>
				<h3 class='heading'>Students in <span class="span-text"><?php echo esc_html($classname); ?></span> for Exam <span class="span-text"><?php echo esc_html($examname); ?></span></h3>
			</center>
			<div class='formcontrol'>
				<form action='' method='post'>
					<?php wp_nonce_field('astgdrmsys_search_action', 'astgdrmsys_search_nonce'); ?>
					<input type='text' class="field searchfield" name='search' placeholder='Search By Name or Roll Number' aria-label="Search" required>
					<input type='submit' class="btn btn-primary field" value="Search" name='searchsubmit'>
				</form>
			</div>
			<table class="table">
				<?php if (empty($students)) { ?>
					<div class="no-records-found alert alert-warning">
						<p>No students found matching your search criteria.</p>
						<ul>
							<li>Check the class and exam name selection</li>
							<li>Verify the search term (name or roll number)</li>
							<li>Ensure students exist in the selected class and exam</li>
						</ul>
					</div>
				<?php } else { ?>
					<thead class="thead-dark">
						<tr>
							<th scope="col">Id</th>
							<th scope="col">Roll No</th>
							<th scope="col">Student Name</th>
							<th scope="col">Class</th>
							<th scope="col">Exam Name</th>
							<th scope="col">Action</th>
						</tr>
					</thead>

					<tbody>
						<?php
						foreach ($students as $index => $student) {
							$className = $this->fetchClassName($student['class']);
							$examName  = $this->fetchExamName($student['exam_name']);
						?>
							<tr>
								<th><?php echo esc_html($index + 1); ?></th>
								<td><strong><?php echo esc_html($student['sno']); ?></strong></td>
								<td><?php echo esc_html($student['name']); ?></td>
								<td><?php echo esc_html($className); ?></td>
								<td><?php echo esc_html($examName); ?></td>
								<td>
									<a class="btn btn-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=astgdrmsys-add-mark&addid=' . esc_html($student['sid']) . '&classsearch=' . esc_html($student['class']) . '&examname=' . esc_html($student['exam_name'])), 'astgdrmsys_mark_action', 'astgdrmsys_mark_nonce')); ?>">Add Marks</a>
								</td>
							</tr>
					<?php
						}
					}
					?>
					</tbody>
			</table>
		</div> <?php
	}

	/**
	 * Render add marks form
	 *
	 * @param int $stuid Student ID
	 */
	public function renderAddMarksForm($stuid)
	{
		global $wpdb;

		// Sanitize student id
		$stuid = filter_var($stuid, FILTER_SANITIZE_NUMBER_INT);

		// Tables with prefix
		$result_table = esc_sql($this->prefix . 'astgdrmsys_student_result');
		$exam_table   = esc_sql($this->prefix . 'astgdrmsys_exam_name');
		$subject_table = esc_sql($this->prefix . 'astgdrmsys_subject');
		$marks_table = esc_sql($this->prefix . 'astgdrmsys_mark');

		// Get student result row
		$addstudent = $wpdb->get_row(
			$wpdb->prepare("SELECT * FROM $result_table WHERE `sid` = %d", $stuid),
			ARRAY_A
		);

		if (! $addstudent) {
			echo "<div class='error'>Student not found!</div>";
			return;
		}

		// Fetch exam_type by matching exam_name (which is id in exam_name table)
		$exam_name_id = $addstudent['exam_name'];

		$exam_type = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT exam_type FROM $exam_table WHERE id = %d",
				$exam_name_id
			)
		);

		// Fallback exam_type to 'single' if not found or empty
		if (empty($exam_type)) {
			$exam_type = 'single';
		}

		// Get subjects for student's class and department
		$subjects = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $subject_table WHERE `class` = %d AND `department` = %d",
				$addstudent['class'],
				$addstudent['department']
			),
			ARRAY_A
		);

		// Get marks for student
		$marks = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $marks_table WHERE `sid` = %d",
				$stuid
			),
			ARRAY_A
		);

		// Unserialize marks if exist
		if ($marks && isset($marks['marks'])) {
			$mark = unserialize($marks['marks']);
		} else {
			$mark = array(); // Default empty
		}

		// Extract fourth subject code if exists and remove from main marks array
		$current_fourth = $mark['fourth_subject'] ?? '';
		unset($mark['fourth_subject']);

		$btnLabel = empty($mark) ? 'Add Mark' : 'Update Mark'; ?>
		<div class='container'>
			<center>
				<h3 class='heading'>Add Marks for <?php echo esc_html($addstudent['name']); ?></h3>
			</center>
			<form method='post' action=''>
				<?php wp_nonce_field('astgdrmsys_mark_action', 'astgdrmsys_mark_nonce'); ?>
				<table class='table'>
					<thead class="thead-dark">
						<tr>
							<th>Subjects</th>
							<th>Total Mark</th>
							<?php if ($exam_type === 'composite') : ?>
								<th>Class Exam Marks</th>
							<?php endif; ?>
							<th>Final Exam Marks</th>
							<th>Total Obtained</th>
							<th>Fourth Subject</th>
						</tr>
					</thead>
					<?php
					// Determine column count based on exam type
					$column_count = ($exam_type === 'composite') ? 6 : 5;
					// Loop through subjects and display input fields
					foreach ($subjects as $subject) {
						$id = $subject['subcode'];

						$class_exam_mark = '';
						$final_exam_mark = '';
						$total_obtained  = '';
						// Check if marks exist for this subject
						if (isset($mark[$id])) {
							if (is_array($mark[$id])) {
								$class_exam_mark = $mark[$id]['class'] ?? '';
								$final_exam_mark = $mark[$id]['final'] ?? '';
								// Calculate total obtained based on exam type
								if ($exam_type === 'composite') {
									$total_obtained = is_numeric($class_exam_mark) && is_numeric($final_exam_mark)
										? ($class_exam_mark + $final_exam_mark)
										: '';
								} else {
									// For single exam type, total obtained is just the final exam mark
									$total_obtained = is_numeric($final_exam_mark) ? $final_exam_mark : '';
								}
							} elseif ($exam_type === 'single' && is_numeric($mark[$id])) {
								// Single exam type: mark is a plain number
								$final_exam_mark = $mark[$id];
								$total_obtained  = $final_exam_mark;
							}
						}
					?>
						<tr>
							<td><strong><?php echo esc_html($subject['subname']); ?></strong></td>
							<td><strong><?php echo esc_html($subject['total']); ?></strong></td>
							<?php if ($exam_type === 'composite') : ?>
								<td>
									<input class='class-mark' type='number' min="0" name='<?php echo esc_attr($id); ?>[class]' value='<?php echo esc_attr($class_exam_mark); ?>' placeholder='Class Exam Mark'>
								</td>
							<?php endif; ?>
							<td>
								<input class='final-mark' type='number' min="0" name='<?php echo esc_attr($id); ?>[final]' value='<?php echo esc_attr($final_exam_mark); ?>' placeholder='Final Exam Mark'>
							</td>
							<td>
								<input class='total-mark form-control bg-light' type='number' value='<?php echo esc_attr($total_obtained); ?>' readonly />
							</td>
							<td>
								<input type="radio" name="fourth_subject" value="<?php echo esc_attr($id); ?>" <?php checked($current_fourth === $id); ?>>
							</td>
						</tr>
					<?php
					}
					?>
					<tr>
						<td><strong>Remark</strong></td>
						<td colspan="<?php echo $column_count - 1; ?>">
							<input type='text' name='remark' placeholder="Enter Remark" value="<?php echo isset($addstudent['remark']) ? esc_html($addstudent['remark']) : ''; ?>">
						</td>
					</tr>
					<tr>
						<td></td>
						<td><input type="submit" name="input_submit" value="<?php echo esc_attr($btnLabel); ?>" class="btn btn-primary"></td>
						<td><button class="btn btn-danger" type="button" onclick="window.history.back();">Cancel</button></td>
					</tr>
				</table>
			</form>
		</div><?php
		$this->processMarkSubmission($stuid, $subjects, $marks);
	}

	/**
	 * Process mark submission
	 *
	 * @param int   $stuid Student ID
	 * @param array $subjects List of subjects
	 * @param array $marks Existing marks
	 */
	public function processMarkSubmission($stuid, $subjects, $marks)
	{
		if (isset($_POST['input_submit'], $_POST['astgdrmsys_mark_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['astgdrmsys_mark_nonce'])), 'astgdrmsys_mark_action')) {
			$marksData = array();

			foreach ($subjects as $subject) {
				$subcode = $subject['subcode'];
				$input   = $_POST[$subcode] ?? [];

				$class_mark = isset($input['class']) ? intval(wp_unslash($input['class'])) : 0;
				$final_mark = isset($input['final']) ? intval(wp_unslash($input['final'])) : 0;
				$total_mark = $class_mark + $final_mark;

				$marksData[$subcode] = array(
					'class' => $class_mark,
					'final' => $final_mark,
					'total' => $total_mark,
				);
			}

			$remark          = isset($_POST['remark']) ? sanitize_text_field(wp_unslash($_POST['remark'])) : '';
			$fourth_subject  = isset($_POST['fourth_subject']) ? sanitize_text_field(wp_unslash($_POST['fourth_subject'])) : '';

			if ($fourth_subject !== '') {
				$marksData['fourth_subject'] = $fourth_subject;
			}

			$serializedMarks = serialize($marksData);

			try {
				$table_name = $this->wpdb->prefix . 'astgdrmsys_mark';

				if (empty($marks)) {
					$this->wpdb->insert(
						$table_name,
						array(
							'sid'    => $stuid,
							'marks'  => $serializedMarks,
							'remark' => $remark,
						),
						array('%d', '%s', '%s')
					);
				} else {
					$this->wpdb->update(
						$table_name,
						array(
							'marks'  => $serializedMarks,
							'remark' => $remark,
						),
						array('sid' => $stuid),
						array('%s', '%s'),
						array('%d')
					);
				}

				wp_safe_redirect(admin_url('admin.php?page=astgdrmsys-add-mark&insert=true'));
				exit;
			} catch (Exception $e) {
				do_action('astgdrmsys_log_error', 'Exception in mark insertion: ' . $e->getMessage());
				wp_die('An error occurred while saving marks.');
			}
		}
	}
}

// Initialize the class
$ASTGDRMSYS_Marks_Manager = new ASTGDRMSYS_Marks_Manager();
