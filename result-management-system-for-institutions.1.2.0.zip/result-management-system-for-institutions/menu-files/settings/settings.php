<?php

/**
 * Result Management System for Institutions
 *
 * Copyright (C) 2025 ASTGD
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

/**
 * This file is part of the Result Management System for Institutions plugin.
 *
 * This file contains the settings configuration for the Result Management System for Institutions plugin.
 *
 * @package ResultManagementSystem
 * @subpackage Settings
 * @since 1.0.0
 */

declare(strict_types=1);

/**
 * Prevents direct access to the file.
 *
 * This code checks if the constant 'ABSPATH' is defined. If it is not defined,
 * it means the file is being accessed directly, and the script will exit with
 * the message 'Direct access not allowed.'.
 *
 * @package ResultManagementSystem
 * @subpackage Settings
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct access not allowed.' );
}

/**
 * Class ASTGDRMSYS_Settings
 *
 * This class handles the settings for the RMS (Result Management System) plugin.
 *
 * @package ResultManagementSystem
 * @subpackage Settings
 * @since 1.0.0
 */
class ASTGDRMSYS_Settings {

	private string $upload_dir;
	private string $prefix;
	private object $wpdb;
	private array $active_tabs = array(
		'general' => '',
		'grade'   => '',
		'school'  => '',
		'delete'  => '',
	);

	/**
	 * Constructor for the class.
	 *
	 * This method is automatically called when an instance of the class is created.
	 * It is used to initialize any properties or methods that the class needs.
	 */
	public function __construct() {
		global $wpdb;
		$this->wpdb       = $wpdb;
		$this->prefix     = $wpdb->prefix;
		$upload_dir       = wp_upload_dir();
		$this->upload_dir = $upload_dir['basedir'] . '/rms/';
	}

	/**
	 * Renders the settings page for the plugin.
	 *
	 * This method outputs the HTML and handles the logic for displaying
	 * the settings page within the WordPress admin dashboard.
	 *
	 * @return void
	 */
	public function astgdrmsys_render_settings_page(): void {
		// Set active tab
		$this->set_active_tab();

		// Render navigation
		$this->astgdrmsys_render_navigation();

		// Handle messages
		$this->handle_messages();

		// Handle logo deletion
		$this->handle_logo_deletion();

		// Handle students records deletion
		$this->handle_student_deleteall();

		// Handle students records deletion for selected class
		$this->handle_classwise_student_deletion();

		// Handle different sections based on the active tab
        // phpcs:ignore WordPress.Security.NonceVerification
		$option = isset( $_GET['option'] ) ? sanitize_text_field( wp_unslash( $_GET['option'] ) ) : 'general';
		switch ( $option ) {
			case 'grade':
				$this->astgdrmsys_grade_settings();
				break;
			case 'school':
				$this->handle_school_info();
				break;
			case 'delete':
				$this->astgdrmsys_render_delete_settings_form();
				break;
			default:
				$this->handle_general_settings();
		}
	}

	public function astgdrmsys_grade_settings(): void
	{
		// phpcs:ignore WordPress.Security.NonceVerification
		if (isset($_GET['option']) && $_GET['option'] !== 'grade') {
			return;
		}

		$this->astgdrmsys_render_grade_settings_form();
	}

	/**
	 * Renders the form for grade settings.
	 *
	 * This function outputs the HTML form that allows users to configure
	 * the grade settings for the Result Management System.
	 *
	 * @return void
	 */
	private function astgdrmsys_render_grade_settings_form(): void
	{
		global $wpdb;
		$table_name = $wpdb->prefix . 'astgdrmsys_grade_system';

		// Handle grade deletion
		if (isset($_GET['delete_grade']) && is_numeric($_GET['delete_grade'])) {
			$del_grade_id = intval($_GET['delete_grade']);
			
			if (check_admin_referer('astgdrmsys_delete_grade_' . $del_grade_id)) {
				$total_grades = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
				
				if ($total_grades > 1) {
					$wpdb->delete($table_name, ['id' => $del_grade_id], ['%d']);
					wp_safe_redirect(admin_url('admin.php?page=astgdrmsys-settings&option=grade&type=delete_grade'));
				} else {
					wp_safe_redirect(admin_url('admin.php?page=astgdrmsys-settings&option=grade&type=delete_failed_last'));
				}
				exit;
			}
		}

		// Handle form submission
		if (isset($_POST['submit-grade']) && check_admin_referer('astgdrmsys_grade_settings_action', 'astgdrmsys_grade_settings_nonce')) {
			if (!empty($_POST['grades']) && is_array($_POST['grades'])) {
				foreach ($_POST['grades'] as $id => $row) {
					$min_mark = intval($row['min_mark']);
					$max_mark = intval($row['max_mark']);
					$grade = sanitize_text_field($row['grade']);
					$grade_point = floatval($row['grade_point']);
					$remarks = sanitize_text_field($row['remarks']);

					$wpdb->update(
						$table_name,
						[
							'min_mark' => $min_mark,
							'max_mark' => $max_mark,
							'grade' => $grade,
							'grade_point' => $grade_point,
							'remarks' => $remarks
						],
						['id' => intval($id)],
						['%d', '%d', '%s', '%f', '%s'],
						['%d']
					);
				}
			}
			if (isset($_POST['new_grade']) && is_array($_POST['new_grade'])) {
				$new_grade = array_map('sanitize_text_field', $_POST['new_grade']);

				// Validate new grade data
				if (
					is_numeric($new_grade['min_mark']) &&
					is_numeric($new_grade['max_mark']) &&
					$new_grade['grade'] !== '' &&
					is_numeric($new_grade['grade_point'])
				) {
					$wpdb->insert($table_name, [
						'min_mark'    => (int) $new_grade['min_mark'],
						'max_mark'    => (int) $new_grade['max_mark'],
						'grade' => strtoupper(trim($new_grade['grade'])),
						'grade_point' => (float) $new_grade['grade_point'],
						'remarks'     => $new_grade['remarks'],
					]);
				}
			}
			// Redirect to the same page with a success message
			wp_safe_redirect(admin_url('admin.php?page=astgdrmsys-settings&option=grade&type=changed'));
			exit;
		}

		// Fetch grade data
		$grades = $wpdb->get_results("SELECT * FROM $table_name ORDER BY min_mark ASC", ARRAY_A);
		?>
		<div class="wrap">
			<h1>Grade Settings</h1>
			<form method="post">
				<?php wp_nonce_field('astgdrmsys_grade_settings_action', 'astgdrmsys_grade_settings_nonce'); ?>
				<!-- Add New Button -->
				<div class="text-right mb-3">
					<button type="button" id="astgdrmsys-show-new-grade" class="button">
						➕ Add New Grade Range
					</button>
				</div>
				<table class="form-table widefat striped">
					<thead>
						<tr>
							<th>Minimum Percentage</th>
							<th>Maximum Percentage</th>
							<th>Grade</th>
							<th>Grade Point</th>
							<th>Remarks</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($grades as $grade): ?>
							<tr>
								<td>
									<input type="number" name="grades[<?php echo $grade['id']; ?>][min_mark]" value="<?php echo esc_attr($grade['min_mark']); ?>" class="form-control" required min="0">
								</td>
								<td>
									<input type="number" name="grades[<?php echo $grade['id']; ?>][max_mark]" value="<?php echo esc_attr($grade['max_mark']); ?>" class="form-control" required min="0">
								</td>
								<td>
									<input type="text" name="grades[<?php echo $grade['id']; ?>][grade]" value="<?php echo esc_attr($grade['grade']); ?>" class="form-control" required>
								</td>
								<td>
									<input type="number" step="0.1" name="grades[<?php echo $grade['id']; ?>][grade_point]" value="<?php echo esc_attr($grade['grade_point']); ?>" class="form-control" required min="0">
								</td>
								<td>
									<input type="text" name="grades[<?php echo $grade['id']; ?>][remarks]" value="<?php echo esc_attr($grade['remarks']); ?>" class="form-control">
								</td>
								<td>
									<?php
									  $delete_url = wp_nonce_url(
										admin_url('admin.php?page=astgdrmsys-settings&option=grade&delete_grade=' . $grade['id']),
										'astgdrmsys_delete_grade_' . $grade['id']
										);
									?>
									<a href="<?php echo esc_url($delete_url); ?>" class="btn btn-outline-danger btn-block" onclick="return confirm('Are you sure you want to delete this grade?');">Delete</a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
					<tfoot id="astgdrmsys-new-grade-row" style="display: none;">
						<tr>
							<td colspan="5" style="text-align:center;">
								<span style="font-size: 14px; color: #333;">Fill this row to add a new grade range</span>
							</td>
						</tr>
						<tr>
							<td>
								<input type="number" name="new_grade[min_mark]" placeholder="Min" class="form-control">
							</td>
							<td>
								<input type="number" name="new_grade[max_mark]" placeholder="Max" class="form-control">
							</td>
							<td>
								<input type="text" name="new_grade[grade]" placeholder="Grade" class="form-control">
							</td>
							<td>
								<input type="number" step="0.1" name="new_grade[grade_point]" class="form-control" placeholder="GPA">
							</td>
							<td>
								<input type="text" name="new_grade[remarks]" placeholder="Remarks" class="form-control">
							</td>
						</tr>
					</tfoot>
				</table>
				<p class="submit">
					<input type="submit" name="submit-grade" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Changes', 'result-management-system-for-institutions'); ?>">
				</p>
			</form>
		</div> <?php
	}

	/**
	 * Renders the navigation menu for the settings page.
	 *
	 * This function is responsible for generating and displaying
	 * the navigation menu within the settings page of the plugin.
	 *
	 * @return void
	 */
	private function astgdrmsys_render_navigation(): void
	{ ?>
		<div class="wrap">
			<h1>Result Management Settings</h1>
			<h2 class="nav-tab-wrapper">
				<a href="<?php echo esc_url(admin_url('admin.php?page=astgdrmsys-settings')); ?>"
					class="nav-tab <?php echo esc_attr($this->active_tabs['general']); ?>">
					General Settings
				</a>
				<a href="<?php echo esc_url(admin_url('admin.php?page=astgdrmsys-settings&option=grade')); ?>"
					class="nav-tab <?php echo esc_attr($this->active_tabs['grade']); ?>">
					Grade Settings
				</a>
				<a href="<?php echo esc_url(admin_url('admin.php?page=astgdrmsys-settings&option=school')); ?>"
					class="nav-tab <?php echo esc_attr($this->active_tabs['school']); ?>">
					Institute Information
				</a>
				<a href="<?php echo esc_url(admin_url('admin.php?page=astgdrmsys-settings&option=delete')); ?>"
					class="nav-tab  <?php echo esc_attr($this->active_tabs['delete']); ?>">
					Delete Records
				</a>
			</h2>
		</div>
		<?php
	}

	/**
	 * Handles the messages for the settings page.
	 *
	 * This function processes and manages any messages that need to be displayed
	 * to the user on the settings page. It ensures that messages are properly
	 * handled and displayed in a user-friendly manner.
	 *
	 * @return void
	 */
	private function handle_messages(): void {
        // phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( $_GET['type'] ) && $_GET['type'] === 'changed' ) {
			?>
			<div class="notice notice-success is-dismissible">
				<p>Settings saved successfully.</p>
			</div>
			<?php
		}

        // phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( $_GET['delete'] ) && $_GET['delete'] === 'delete_all' ) {
			?>
			<div class="notice notice-success is-dismissible">
				<p>All records have been deleted successfully.</p>
			</div>
			<?php
		}

        // phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( $_GET['delete'] ) && $_GET['delete'] === 'delete_class' ) {
			?>
			<div class="notice notice-success is-dismissible">
				<p>All records have been deleted successfully from the selected class.</p>
			</div>
			<?php
		}

		// phpcs:ignore WordPress.Security.NonceVerification
		if (isset($_GET['type']) && $_GET['type'] === 'delete_grade') {
			echo '<div class="notice notice-success is-dismissible"><p>Grade deleted successfully.</p></div>';
		}
		if (isset($_GET['type']) && $_GET['type'] === 'delete_failed_last') {
			echo '<div class="notice notice-error is-dismissible"><p>Failed to delete grade. You cannot empty grade list.</p></div>';
		}
	}

	/**
	 * Handles the school information settings.
	 *
	 * This method is responsible for managing the school information settings
	 * within the plugin.
	 *
	 * @return void
	 */
	public function handle_school_info(): void {
		if ( ! isset( $_GET['option'] ) || $_GET['option'] !== 'school' ) {
			return;
		}

		if ( isset( $_SERVER['REQUEST_METHOD'] ) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset( $_POST['submit'] ) ) {
			check_admin_referer( 'astgdrmsys_school_info_action', 'astgdrmsys_school_info_nonce' );

			$data = array(
				'sc_name' => isset( $_POST['sc_name'] ) ? sanitize_text_field( wp_unslash( $_POST['sc_name'] ) ) : '',
				'vill'    => isset( $_POST['vill'] ) ? sanitize_text_field( wp_unslash( $_POST['vill'] ) ) : '',
				'pin'     => isset( $_POST['pin'] ) ? sanitize_text_field( wp_unslash( $_POST['pin'] ) ) : '',
				'ps'      => isset( $_POST['ps'] ) ? sanitize_text_field( wp_unslash( $_POST['ps'] ) ) : '',
				'dist'    => isset( $_POST['dist'] ) ? sanitize_text_field( wp_unslash( $_POST['dist'] ) ) : '',
				'state'   => isset( $_POST['state'] ) ? sanitize_text_field( wp_unslash( $_POST['state'] ) ) : '',
				'phone'   => isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '',
				'website' => isset( $_POST['website'] ) ? sanitize_text_field( wp_unslash( $_POST['website'] ) ) : '',
				'email'   => isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '',
			);

			if (
				isset( $_FILES['logo'] ) &&
				isset( $_FILES['logo']['error'] ) &&
				$_FILES['logo']['error'] === UPLOAD_ERR_OK
			) {
				$upload_result = $this->handle_logo_upload();
				if ( ! is_wp_error( $upload_result ) ) {
					$data['logo'] = $upload_result;
				}
			}

			// $this->update_school_info($data);
			if ( $this->update_school_info( $data ) ) {
				// Success logic
				add_settings_error( 'astgdrmsys_school_info', 'success', 'School information updated successfully.', 'success' );
				wp_safe_redirect( admin_url( 'admin.php?page=astgdrmsys-settings&option=school&type=changed' ) );
				exit;
			} else {
				// Error logic
				add_settings_error( 'astgdrmsys_school_info', 'error', $this->get_last_error() );
				echo esc_html( $this->get_last_error() );
			}
		}

		$school_info = $this->get_school_info();
		$this->astgdrmsys_render_school_info_form( $school_info );
	}

	/**
	 * Handles the deletion of the logo.
	 *
	 * This function is responsible for managing the process of deleting the logo
	 * from the settings. It ensures that all necessary steps are taken to remove
	 * the logo and update the relevant settings accordingly.
	 *
	 * @return void
	 */
	private function handle_logo_deletion(): void {
		if ( ! isset( $_GET['delete_logo'] ) ) {
			return;
		}

		check_admin_referer( 'delete_logo' );
		$school_info = $this->get_school_info();

		if ( $school_info && ! empty( $school_info->logo ) && file_exists( $school_info->logo ) ) {
			wp_delete_file( $school_info->logo );
			$this->update_school_info( array( 'logo' => '' ) );
		}

		// Redirect to the same page with a message
		wp_safe_redirect( admin_url( 'admin.php?page=astgdrmsys-settings&option=school&type=changed' ) );
		exit;
	}

	/**
	 * Handles the deletion of all student records.
	 *
	 * This function is responsible for deleting all student records from the database.
	 * It performs necessary checks and operations to ensure that all student data is
	 * removed safely and efficiently.
	 *
	 * @return void
	 */
	private function handle_student_deleteall(): void {
		global $wpdb;

		if ( ! isset( $_GET['delete_all'] ) ) {
			return;
		}
		check_admin_referer( 'delete_all' );

		$result_table = esc_sql( $this->prefix . 'astgdrmsys_student_result' );
		$mark_table   = esc_sql( $this->prefix . 'astgdrmsys_mark' );

		// delete all student records
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->query(
			$wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"DELETE FROM $result_table"
			)
		);
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->query(
			$wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"DELETE FROM $mark_table"
			)
		);

		// redirect to the same page with a message
		wp_safe_redirect( admin_url( 'admin.php?page=astgdrmsys-settings&option=delete&delete=delete_all' ) );
		exit;

	}

	/**
	 * Handles the deletion of students based on their class.
	 *
	 * This function is responsible for managing the deletion process of students
	 * who belong to a specific class. It ensures that all necessary steps are
	 * taken to remove the students' records from the system.
	 *
	 * @return void
	 */
	private function handle_classwise_student_deletion(): void {
		global $wpdb;
		// Check if the delete_class parameter is set
		if ( ! isset( $_GET['delete_class'] ) ) {
			return;
		}
		// Check if the form is submitted
		check_admin_referer( 'delete_class', 'astgdrmsys_view_settings_nonce' );
		// get the selected class id
		$selected_class_id = isset( $_POST['selectClass'] ) ? sanitize_text_field( wp_unslash( $_POST['selectClass'] ) ) : 0;

		$result_table = esc_sql( $this->prefix . 'astgdrmsys_student_result' );
		// Delete all students from the selected class
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->query(
			$wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"DELETE FROM $result_table WHERE class = %d",
				$selected_class_id
			)
		);
		// redirect to the same page with a success message
		wp_safe_redirect( admin_url( 'admin.php?page=astgdrmsys-settings&option=delete&delete=delete_class' ) );
		exit;
	}

	/**
	 * Handles the logo upload process.
	 *
	 * @return string|WP_Error Returns the URL of the uploaded logo on success, or a WP_Error object on failure.
	 */
	private function handle_logo_upload(): string|WP_Error {
		// Verify nonce for security
		if (
			! isset( $_POST['_wpnonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'astgdrmsys_logo_upload' )
		) {
			return new WP_Error( 'invalid_nonce', 'Security check failed.' );
		}

		// Ensure upload directory exists
		if ( ! file_exists( $this->upload_dir ) ) {
			wp_mkdir_p( $this->upload_dir );
		}

		// Validate uploaded file
		if ( ! isset( $_FILES['logo'] ) || empty( $_FILES['logo']['name'] ) ) {
			return new WP_Error( 'no_file', 'No file was uploaded.' );
		}

		// Validate file type
		$allowed_types = array( 'image/jpeg', 'image/png', 'image/gif' );
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$file = $_FILES['logo'];

		// Check the actual file type and extension
		$file_check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
		if ( empty( $file_check['type'] ) || ! in_array( $file_check['type'], $allowed_types, true ) ) {
			return new WP_Error( 'invalid_file_type', 'Invalid file type. Please upload a JPEG, PNG, or GIF image.' );
		}

		// Sanitize the file name
		$sanitized_filename = sanitize_file_name( wp_unslash( $file['name'] ) );

		// Set up upload overrides
		$upload_overrides = array(
			'test_form'                => false,
			'test_type'                => true,
			'unique_filename_callback' => function () use ( $sanitized_filename ) {
				return $sanitized_filename;
			},
		);

		// Handle the file upload using original $_FILES array
		$uploaded_file = wp_handle_upload( $file, $upload_overrides );

		if ( isset( $uploaded_file['file'] ) ) {
			return $uploaded_file['file']; // Return full file path
		} else {
			return new WP_Error( 'upload_error', 'Failed to upload file.', $uploaded_file );
		}
	}

	/**
	 * Updates the school information with the provided data.
	 *
	 * @param array $data An associative array containing the school information to be updated.
	 *
	 * @return bool Returns true on success, false on failure.
	 */
	private function update_school_info( array $data ): bool {
		global $wpdb;
		try {
			// Validate input data
			if ( empty( $data ) ) {
				throw new Exception( 'No data provided for update.' );
			}

			// Remove empty values to prevent overwriting with empty strings
			$filtered_data = array_filter(
				$data,
				function ( $value ) {
					return $value !== '' && $value !== null;
				}
			);

			$school_table = esc_sql( $this->prefix . 'astgdrmsys_school_info' );
			// Check if data exists
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$existing = $wpdb->get_row(
				$wpdb->prepare(
                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					"SELECT * FROM $school_table WHERE sc_id = %d",
					1
				)
			);

			// Prepare format array dynamically
			$format = array_fill( 0, count( $filtered_data ), '%s' );

			if ( $existing ) {
				// Data exists, so update
				// Only update non-empty fields
				$result = $this->wpdb->update(
					"{$this->prefix}astgdrmsys_school_info",
					$filtered_data,
					array( 'sc_id' => 1 ),
					$format,
					array( '%d' )
				);

				// Check if update was successful
				if ( $result === false ) {
					throw new Exception( 'Database update failed: ' . $this->wpdb->last_error );
				}
			} else {
				// Data does not exist, so insert
				// Add sc_id to the data if it's not already there
				$filtered_data['sc_id'] = 1;

				$result = $this->wpdb->insert(
					"{$this->prefix}astgdrmsys_school_info",
					$filtered_data,
					$format
				);

				// Check if insert was successful
				if ( $result === false ) {
					throw new Exception( 'Database insert failed: ' . $this->wpdb->last_error );
				}
			}

			return true;
		} catch ( Exception $e ) {
			// Store the error message
			$this->last_error = $e->getMessage();
			return false;
		}
	}

	private $last_error = '';

	/**
	 * Retrieves the last error message.
	 *
	 * @return string The last error message.
	 */
	public function get_last_error(): string {
		return $this->last_error;
	}


	/**
	 * Retrieves the school information.
	 *
	 * @return object|null Returns an object containing the school information, or null if no information is available.
	 */
	public function get_school_info(): ?object {
		$school_table = esc_sql( $this->prefix . 'astgdrmsys_school_info' );

		// Check if the table exists
		$sql = $this->wpdb->prepare(
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT * FROM $school_table WHERE sc_id = %d",
			1
		);
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $this->wpdb->get_row( $sql );
	}

	/**
	 * Renders the school information form.
	 *
	 * @param object|null $school_info The school information object. If null, a new form will be rendered.
	 *
	 * @return void
	 */
	private function astgdrmsys_render_school_info_form( ?object $school_info ): void {
		?>
		<div class="wrap">
			<?php if ( ! $school_info ) : ?>
				<div class="error">
					<p>No school information found. Please enter the details below to update the information.</p>
				</div>
			<?php endif; ?>

			<form method="post" enctype="multipart/form-data">
				<?php wp_nonce_field( 'astgdrmsys_school_info_action', 'astgdrmsys_school_info_nonce' ); ?>
				<?php wp_nonce_field( 'astgdrmsys_logo_upload' ); ?>
				<!-- Form Table  -->
				<table class="form-table">
					<tr>
						<th scope="row"><label for="sc_name">Institute Name</label></th>
						<td>
							<input type="text" name="sc_name" id="sc_name"
								value="<?php echo $school_info ? esc_attr( $school_info->sc_name ) : ''; ?>"
								class="regular-text">
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="vill">Village/City</label></th>
						<td>
							<input type="text" name="vill" id="vill"
								value="<?php echo $school_info ? esc_attr( $school_info->vill ) : ''; ?>"
								class="regular-text">
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="pin">PIN Code</label></th>
						<td>
							<input type="text" name="pin" id="pin"
								value="<?php echo $school_info ? esc_attr( $school_info->pin ) : ''; ?>"
								class="regular-text">
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="ps">Police Station</label></th>
						<td>
							<input type="text" name="ps" id="ps"
								value="<?php echo $school_info ? esc_attr( $school_info->ps ) : ''; ?>"
								class="regular-text">
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="dist">District</label></th>
						<td>
							<input type="text" name="dist" id="dist"
								value="<?php echo $school_info ? esc_attr( $school_info->dist ) : ''; ?>"
								class="regular-text">
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="state">State</label></th>
						<td>
							<input type="text" name="state" id="state"
								value="<?php echo $school_info ? esc_attr( $school_info->state ) : ''; ?>"
								class="regular-text">
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="phone">Phone</label></th>
						<td>
							<input type="text" name="phone" id="phone"
								value="<?php echo $school_info ? esc_attr( $school_info->phone ) : ''; ?>"
								class="regular-text">
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="website">Website</label></th>
						<td>
							<input type="text" name="website" id="website"
								value="<?php echo $school_info ? esc_attr( $school_info->website ) : ''; ?>"
								class="regular-text">
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="email">Email</label></th>
						<td>
							<input type="email" name="email" id="email"
								value="<?php echo $school_info ? esc_attr( $school_info->email ) : ''; ?>"
								class="regular-text">
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="logo">Institute Logo</label></th>
						<td>
							<?php if ( $school_info && ! empty( $school_info->logo ) && file_exists( $school_info->logo ) ) : ?>
								<?php
								$logo_url  = '';
								$logo_path = $school_info->logo; // Could be full path or just filename

								// Check if it's a valid Media Library image
								$attachment_id = attachment_url_to_postid( $logo_path );
								if ( $attachment_id ) {
									// Safely get image from Media Library
									echo wp_get_attachment_image(
										$attachment_id,
										'medium',
										false,
										array(
											'class' => 'logo-img',
											'alt'   => esc_attr__( 'School Logo', 'result-management-system-for-institutions' ),
										)
									);
								} else {
									// Fallback: Try treating it as an upload directory image path
									$upload_dir = wp_upload_dir();

									// Check if full path was saved
									if ( strpos( $logo_path, $upload_dir['basedir'] ) !== false ) {
										$relative_path = str_replace( $upload_dir['basedir'], '', $logo_path );
									} else {
										// If only the filename is saved
										$relative_path = '/' . ltrim( $logo_path, '/\\' );
									}
									// Construct the URL
									$logo_url = esc_url( $upload_dir['baseurl'] . $relative_path );
									// Output the image
                                    // phpcs:ignore PluginCheck.CodeAnalysis.ImageFunctions.NonEnqueuedImage
									echo '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr__( 'School Logo', 'result-management-system-for-institutions' ) . '" class="logo-img">';
								}
								?>
								<br>
								<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=astgdrmsys-settings&option=school&delete_logo=1' ), 'delete_logo' ) ); ?>"
									class="button"
									onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to delete the logo?', 'result-management-system-for-institutions' ); ?>');">
									<?php esc_html_e( 'Delete Logo', 'result-management-system-for-institutions' ); ?>
								</a>
							<?php endif; ?>
							<br><br>
							<input type="file" name="logo" id="logo">
							<p class="description">Upload school logo (JPEG, PNG, JPG)</p>
						</td>
					</tr>
				</table>
				<!-- Submit Button  -->
				<p class="submit">
					<input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes">
				</p>
			</form>
		</div>
		<?php
	}

	/**
	 * Sets the active tab for the settings menu.
	 *
	 * This method determines which tab should be active based on the current request
	 * and sets it accordingly. It does not take any parameters and does not return any value.
	 *
	 * @return void
	 */
	private function set_active_tab(): void {
        // phpcs:ignore WordPress.Security.NonceVerification
		$current_option    = isset( $_GET['option'] ) ? sanitize_text_field( wp_unslash( $_GET['option'] ) ) : 'general';
		$this->active_tabs = array(
			'general' => $current_option === 'general' ? 'nav-tab-active' : '',
			'grade'   => $current_option === 'grade' ? 'nav-tab-active' : '',
			'school'  => $current_option === 'school' ? 'nav-tab-active' : '',
			'delete'  => $current_option === 'delete' ? 'nav-tab-active' : '',
		);
	}

	/**
	 * Retrieves the classes.
	 *
	 * This private function is responsible for fetching and returning the classes.
	 *
	 * @return array The array of classes.
	 */
	private function get_classes() {
		$class_table = esc_sql( $this->prefix . 'astgdrmsys_class' );
		return $this->wpdb->get_results(
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT * FROM $class_table ORDER BY class ASC",
			ARRAY_A
		);
	}

	/**
	 * Renders the form for deleting settings.
	 *
	 * This function outputs the HTML form that allows users to delete settings.
	 *
	 * @return void
	 */
	private function astgdrmsys_render_delete_settings_form(): void {
		// Fetch all classes from the database
		$classes = $this->get_classes();

		?>
		<div class="wrap">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=astgdrmsys-settings&option=delete&delete_class=1' ) ); ?>" 
			  	onsubmit="return confirm('Are you sure you want to delete all student records for the selected class? This action cannot be undone.');" >
				<?php wp_nonce_field( 'delete_class', 'astgdrmsys_view_settings_nonce' ); ?>
				<table class="form-table">
					<tr>
						<th scope="row">Delete Settings</th>
						<td>
							<fieldset>
								<span>
									Want to Delete All Students Records?
								</span><br>
								<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=astgdrmsys-settings&option=delete&delete_all' ), 'delete_all' ) ); ?>"
									class="button delete-button" onclick="return confirm('Are you sure you want to delete all students?');">
									Delete Students Records
								</a>
								<hr>
								<label for="selectClass"><?php esc_html_e( 'Class:', 'result-management-system-for-institutions' ); ?></label>
								<select name="selectClass" id="selectClass" required>
									<option value="" selected disabled><?php esc_html_e( 'Select a Class', 'result-management-system-for-institutions' ); ?></option>
									<?php foreach ( $classes as $class ) : ?>
										<option value="<?php echo esc_attr( $class['id'] ); ?>">
											<?php echo esc_html( $class['class'] ); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<br>
								<input type="submit" name="delete_class_submit" value="Delete Students">
							</fieldset>
						</td>
					</tr>
				</table>
			</form>
		</div>
		<?php
	}

	/**
	 * Handles the general settings for the plugin.
	 *
	 * This method is responsible for managing and processing the general settings
	 * of the plugin. It ensures that the settings are properly handled and saved.
	 *
	 * @return void
	 */
	public function handle_general_settings(): void {
		// Check if the form is submitted
		$this->astgdrmsys_render_general_settings_form();
	}

	/**
	 * Renders the general settings form.
	 *
	 * This function outputs the HTML for the general settings form in the plugin's settings page.
	 *
	 * @return void
	 */
	private function astgdrmsys_render_general_settings_form(): void {
		// Check if the form is submitted and save the URL
		if ( isset( $_POST['submit_result_url'] ) ) {
			// Verify the nonce for security
			check_admin_referer( 'save_result_url_nonce' );

			// Get the submitted URL
			$new_url = isset( $_POST['result_url'] ) ? esc_url_raw( wp_unslash( $_POST['result_url'] ) ) : '';

			// Save the URL using update_option
			update_option( 'astgdrmsys_student_result_url', $new_url );

			// Display a success message
			echo '<div class="updated"><p>' . esc_html__( 'Result URL updated successfully!', 'result-management-system-for-institutions' ) . '</p></div>';
		}

		// Retrieve the saved URL from the database
		$saved_url = get_option( 'astgdrmsys_student_result_url', home_url( '/result/' ) );

		?>
		<div class="wrap">
			<form method="post">
				<?php wp_nonce_field( 'astgdrmsys_general_settings_action', 'astgdrmsys_general_settings_nonce' ); ?>
				<!-- Form Table  -->
				<table class="form-table">
					<!-- Update Result URL  -->
					<tr>
						<!-- Form to save the URL -->
						<div class="container result-url-div">
							<p>Enter the URL where the results are published.</p>
							<form method="post">
								<?php wp_nonce_field( 'save_result_url_nonce' ); ?>
								<label for="result-url">Enter Result URL:</label>
								<input type="url" id="result-url" name="result_url" class="regular-text" value="" placeholder="http://example/result">
								<button type="submit" name="submit_result_url" class="button button-primary">Save URL</button>
							</form>
							<p>
								<strong>Current URL:</strong>
								<span id="saved-url"><?php echo esc_url( $saved_url ); ?></span>
								<button type="button" id="copy-button" class="button button-primary">Copy</button>
							</p>
						</div>
					</tr>
				</table>

				<!-- Submit Button  -->
				<p class="submit">
					<input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes">
				</p>
			</form>
		</div>
		<?php
	}
}

/**
 * Initializes the ASTGDRMSYS_Settings class and renders the settings page.
 *
 * This code creates an instance of the ASTGDRMSYS_Settings class and calls the
 * astgdrmsys_render_settings_page() method to display the settings page for the plugin.
 *
 * @package ResultManagementSystem
 */
$settings = new ASTGDRMSYS_Settings();
$settings->astgdrmsys_render_settings_page();
?>