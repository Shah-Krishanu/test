<?php

/**
 * Result Management System for Institutions
 *
 * Copyright (C) 2025 ASTGD
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

/**
 * Prevent direct access to the file.
 *
 * This code checks if the constant 'ABSPATH' is defined. If it is not defined,
 * it means the file is being accessed directly, and the script will exit.
 *
 * 'ABSPATH' is a constant defined by WordPress, which represents the absolute
 * path to the WordPress directory. By checking for this constant, we ensure
 * that the file is being accessed within the context of a WordPress installation.
 */
if (! defined('ABSPATH')) {
	exit;
}

/**
 * Class ASTGDRMSYS_StudentRecordManager
 *
 * This class is responsible for managing student records within the Mystical Playground WordPress plugin.
 * It provides functionalities to add, update, delete, and retrieve student records.
 *
 * @package ResultManagementSystem
 * @since 1.0.0
 */
class ASTGDRMSYS_StudentRecordManager
{

	private $wpdb;
	private $prefix;

	/**
	 * Constructor for the class.
	 *
	 * This method is called when an instance of the class is created.
	 */
	public function __construct()
	{
		global $wpdb;
		$this->wpdb   = $wpdb;
		$this->prefix = $wpdb->prefix;

		// Handle form submissions
		if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
			// Check if the nonce is set and valid
			if (isset($_POST['add_student_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['add_student_nonce'])), 'add_student_action')) {
				// Check which form was submitted
				if (isset($_POST['submit'])) {
					$this->handleAddRecord();
				} elseif (isset($_POST['submitcsv'])) {
					$this->handleCSVUpload();
				}
			}
		}
	}

	/**
	 * Displays the student record addition form or interface.
	 *
	 * This method is responsible for rendering the necessary HTML and other
	 * elements to allow users to add a new student record.
	 *
	 * @return void
	 */
	public function astgdrmsys_display()
	{
		$this->displaySuccessMessage();
		echo '<div class="container">';
		$this->renderAddRecordForm();
		$this->renderCSVUploadForm();
		echo '</div>';
	}

	/**
	 * Displays a success message to the user.
	 *
	 * This function is responsible for rendering a success message
	 * when a student record is successfully added.
	 *
	 * @return void
	 */
	private function displaySuccessMessage()
	{
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if (isset($_GET['redirect']) && $_GET['redirect'] === 'success') {
			echo "
            <div id='message_div' class='alert alert-success'> 
                <center>Student Record Added Successfully</center>
                <button class='close-message' onclick='this.parentElement.style.display=\"none\";'>&times;</button>
            </div>";
		}
	}

	/**
	 * Renders the form for adding a new student record.
	 *
	 * This function generates and displays the HTML form that allows users to input
	 * and submit new student records into the system.
	 *
	 * @return void
	 */
	private function renderAddRecordForm()
	{ ?>
		<div id="adddiv">
			<h1>Add Student Result</h1>
			<form action="" method="POST">
				<?php wp_nonce_field('add_student_action', 'add_student_nonce'); ?>
				<table class="table submit-table">
					<tr>
						<td><label for="sno"><strong>Roll Number :</strong></label></td>
						<td><input type="text" placeholder="Enter Serial Number" name="sno" id="sno" required></td>
						<td><label for="regno"><strong>Registration No :</strong></label></td>
						<td><input type="text" placeholder="Enter Registration Number" name="regno" id="regno" required></td>
					</tr>
					<tr>
						<td><label for="name"><strong>Name :</strong></label></td>
						<td><input type="text" placeholder="Enter Student Name" required name="name" id="name"></td>
						<td><strong>Gender :</strong></td>
						<td>
							<div class='gender'>
								<input type="radio" id="male" name="gender" value="MALE" required>
								<label for="male">Male</label>
								<input type="radio" id="female" name="gender" value="FEMALE" required>
								<label for="female">Female</label>
								<input type="radio" id="other" name="gender" value="OTHERS" required>
								<label for="other">Others</label>
							</div>
						</td>
					</tr>
					<tr>
						<td><label for="fname"><strong>Father's Name :</strong></label></td>
						<td><input type="text" placeholder="Enter Father's Name" name="fname" id="fname"></td>
						<td><label for="mname"><strong>Mother's Name :</strong></label></td>
						<td><input type="text" placeholder="Enter Mother's Name" name="mname" id="mname"></td>
					</tr>
					<tr>
						<td><strong>Class :</strong></td>
						<td>
							<select name="class" class="selectClass" id="selectClass" required>
								<option value="">Select Class</option>
								<?php $this->renderClassOptions(); ?>
							</select>
						</td>
						<td><strong>Department :</strong></td>
						<td>
							<select name="department" class="selectDepartment" id="selectDepartment" required>
								<option value="">Select Class First</option>
							</select>
						</td>
					</tr>
					<tr>
						<td><strong>Section :</strong></td>
						<td>
							<select name="section" id="selectSection" required>
								<option value="">Select Dept First</option>
							</select>
						</td>
						<td><strong>Select Exam:</strong></td>
						<td>
							<select name="exam_name" id="selectExam" required>
								<option value="">Select Class First</option>
							</select>
						</td>
					</tr>
					<tr>
						<td colspan="2"></td>
						<td><input class="btn btn-primary" type="submit" name='submit' value="Submit"></td>
					</tr>
				</table>
			</form>
		</div> <?php
	}

	/**
	 * Renders the options for the class selection dropdown.
	 *
	 * This function generates and outputs the HTML for the class options
	 * in a dropdown menu. It is used in the student record addition form
	 * to allow users to select a class for the student.
	 *
	 * @return void
	 */
	private function renderClassOptions()
	{
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$classes = $this->wpdb->get_results("SELECT * FROM `{$this->prefix}astgdrmsys_class`", ARRAY_A);
		foreach ($classes as $class) {
			// Convert $class to array if it's an object
			if (is_object($class)) {
				$class = (array) $class;
			}
			echo "<option value='" . esc_html($class['id']) . "'>" . esc_html($class['class']) . '</option>';
		}
	}

	/**
	 * Renders the CSV upload form for adding student records.
	 *
	 * This function generates the HTML form that allows users to upload a CSV file
	 * containing student records. The uploaded file will be processed and the
	 * student records will be added to the system.
	 *
	 * @return void
	 */
	private function renderCSVUploadForm()
	{	?>
		<div align="center" id="div">
			<h1 id="csvheading">Add Records Using CSV</h1>
			<form method="post" action="" enctype="multipart/form-data" class="add-record-form">
				<?php wp_nonce_field('add_student_action', 'add_student_nonce'); ?>
				<table class='table'>
					<tr>
						<td><strong>
								<h5>Choose CSV file</h5>
							</strong></td>
						<td>
							<div class="file-field">
								<input type="file" name="file" id="CSV_file" required>
							</div>
						</td>
					</tr>
					<tr>
						<td></td>
						<td><input class="btn btn-primary" type="submit" name="submitcsv" value="Import" id="import"></td>
					</tr>
				</table>
				<span class="text-danger">* Download this CSV for a better understanding about the format!</span><br>
				<button class="btn btn-success">
					<a href="<?php echo esc_url(ASTGDRMSYS_PLUGIN_URL . 'files/add-student-record.xlsx'); ?>" download>Download CSV Format</a>
				</button>
			</form>
			<h5>Note: <a id="read" href="<?php echo esc_url(admin_url('admin.php?page=astgdrmsys-help#import')); ?>">Read this</a> before uploading csv file</h5>
		</div> <?php
	}
	
	/**
	 * Handles the addition of a new student record.
	 *
	 * This function processes the input data for adding a new student record
	 * and performs necessary validation and database operations.
	 *
	 * @return void
	*/
	private function handleAddRecord()
	{
		$data = $this->sanitizeInputData();
		
		$added = $this->wpdb->insert(
		$this->prefix . 'astgdrmsys_student_result',
				$data,
				array_fill(0, count($data), '%s')
			);

		if ($added) {
			wp_safe_redirect(admin_url('admin.php?page=astgdrmsys-add-record&redirect=success'));
			exit;
		}
	}
	
	/**
	 * Sanitize input data from the POST request.
	 *
	 * This function sanitizes various fields from the POST request to ensure that
	 * the data is safe to use. It splits the 'exam_name' field to extract the
	 * 'exam_year' and returns an associative array with sanitized values.
	 *
	 * @return array An associative array containing sanitized input data:
	 *               - 'sno' (string): The sanitized serial number.
	 *               - 'regno' (string): The sanitized registration number.
	 *               - 'name' (string): The sanitized name.
	 *               - 'username' (string): The sanitized username.
	 *               - 'gender' (string): The sanitized gender.
	 *               - 'fname' (string): The sanitized father's name.
	 *               - 'mname' (string): The sanitized mother's name.
	 *               - 'class' (string): The sanitized class.
	 *               - 'department' (string): The sanitized department.
	 *               - 'section' (string): The sanitized section.
	 *               - 'exam_name' (string): The sanitized exam name.
	 *               - 'exam_year' (string): The sanitized exam year.
	 */
	private function sanitizeInputData()
	{
		// Verify nonce before processing POST data
		if (
			! isset($_POST['add_student_nonce']) ||
			! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['add_student_nonce'])), 'add_student_action')
		) {
			return new WP_Error('invalid_nonce', 'Security check failed.');
		}

		$exam_name_raw = isset($_POST['exam_name']) ? sanitize_text_field(wp_unslash($_POST['exam_name'])) : '';
		$array         = explode(',', $exam_name_raw); // Splitting exam_year from exam_name
		$exam_name     = $array[0] ?? '';
		$exam_year     = $array[1] ?? '';

		return array(
			'sno'        => isset($_POST['sno']) ? sanitize_text_field(wp_unslash($_POST['sno'])) : '',
			'regno'      => isset($_POST['regno']) ? sanitize_text_field(wp_unslash($_POST['regno'])) : '',
			'name'       => isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '',
			'gender'     => isset($_POST['gender']) ? sanitize_text_field(wp_unslash($_POST['gender'])) : '',
			'fname'      => isset($_POST['fname']) ? sanitize_text_field(wp_unslash($_POST['fname'])) : '',
			'mname'      => isset($_POST['mname']) ? sanitize_text_field(wp_unslash($_POST['mname'])) : '',
			'class'      => isset($_POST['class']) ? sanitize_text_field(wp_unslash($_POST['class'])) : '',
			'department' => isset($_POST['department']) ? sanitize_text_field(wp_unslash($_POST['department'])) : '',
			'section'    => isset($_POST['section']) ? sanitize_text_field(wp_unslash($_POST['section'])) : '',
			'exam_name'  => $exam_name,
			'exam_year'  => $exam_year,
		);
	}
	
	/**
	 * Handles the CSV file upload process.
	 *
	 * This function processes the uploaded CSV file, validates its contents,
	 * and performs necessary actions to store or update student records.
	 *
	 * @return void
	*/
	private function handleCSVUpload()
	{
		global $wpdb;
		// Verify nonce before accessing file
		if (
			! isset($_POST['add_student_nonce']) ||
			! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['add_student_nonce'])), 'add_student_action')
		) {
			wp_die(esc_html__('Security check failed.', 'result-management-system-for-institutions'));
		}

		if (! empty($_FILES['file']['name'])) {
			if (
				isset($_FILES['file']) &&
				isset($_FILES['file']['tmp_name']) &&
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				is_uploaded_file($_FILES['file']['tmp_name'])
			) {
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.WP.AlternativeFunctions.file_system_operations_fopen
				$imported_file = fopen($_FILES['file']['tmp_name'], 'r');
			}

			$subject_table = esc_sql($this->prefix . 'astgdrmsys_subject');
			// get all subject subcodes from the database
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
			$subject_subcodes = $wpdb->get_col(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT CONCAT(subcode, ',', class, ',', department) FROM $subject_table"
			);
			$row_count = 0;

			// while loop to read each row of the CSV file
			while ($data = fgetcsv($imported_file)) {
				++$row_count;
				if ($row_count == 1) {
					continue; // Skip header row
				}

				$this->processCSVRow($data, $subject_subcodes);
			}

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			fclose($imported_file);

			// Redirect to the student record page with a success message
			wp_safe_redirect(admin_url('admin.php?page=astgdrmsys-all-students&csv=imported'));
			exit;
		}
	}
	
	/**
	 * Processes a single row of CSV data.
	 *
	 * @param array $data The CSV row data to be processed.
	 *
	 * @return void
	*/
	private function processCSVRow($data)
	{
		global $wpdb;
	
		// Extract and sanitize basic student information
		$snocsv   = sanitize_text_field($data[0]);
		$regnocsv = sanitize_text_field($data[1]);
		$namecsv  = sanitize_text_field($data[2]);
		// $usernamecsv = sanitize_text_field($data[3]);
	
		if (empty($namecsv)) {
			return; // Skip if the student's name or username is missing
		}
	
		// Extract and sanitize additional student information
		$gendercsv     = sanitize_text_field($data[3]);
		$fnamecsv      = sanitize_text_field($data[4]);
		$mnamecsv      = sanitize_text_field($data[5]);
		$remarkcsv     = sanitize_text_field($data[6]);
		$classid       = sanitize_text_field($data[7]);
		$department_id = sanitize_text_field($data[8]);
		$section_id    = sanitize_text_field($data[9]);
		$exam_name_id  = sanitize_text_field($data[10]);
		$exam_year_id  = sanitize_text_field($data[11]);
		$fourth_subject_code = sanitize_text_field($data[12]);
	
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$exam_table = esc_sql($this->prefix . 'astgdrmsys_exam_name');
		$exam_type = $wpdb->get_var(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->prepare("SELECT exam_type FROM $exam_table WHERE id = %d", $exam_name_id)
		);
	
		$marks_array = [];
	
		// Process marks based on exam type
		if ($exam_type === 'composite') {
			for ($i = 13; $i + 2 < count($data); $i += 3) {
				$subject_id  = sanitize_text_field($data[$i]);
				$class_mark  = intval($data[$i + 1]);
				$final_mark  = intval($data[$i + 2]);
				if (empty($subject_id)) {
					continue;
				}
				$marks_array[$subject_id] = [
					'class' => $class_mark,
					'final' => $final_mark,
					'total' => $class_mark + $final_mark,
				];
			}
		} else {
			for ($i = 13; $i + 1 < count($data); $i += 2) {
				$subject_id = sanitize_text_field($data[$i]);
				$mark       = sanitize_text_field($data[$i + 1]);
				if (empty($subject_id)) {
					continue;
				}
				$marks_array[$subject_id] = $mark;
			}
		}

		if (!empty($fourth_subject_code)) {
			$marks_array['fourth_subject'] = $fourth_subject_code;
		}
	
		// Insert valid student and mark data into the database
		if (! empty($marks_array)) {
	
			// Insert student data into the database
			$this->wpdb->insert(
				$this->prefix . 'astgdrmsys_student_result',
				array(
					'sid'        => null,
					'sno'        => $snocsv,
					'regno'      => $regnocsv,
					'name'       => $namecsv,
					'fname'      => $fnamecsv,
					'mname'      => $mnamecsv,
					'gender'     => $gendercsv,
					'remark'     => $remarkcsv,
					'class'      => $classid,
					'department' => $department_id,
					'section'    => $section_id,
					'exam_name'  => $exam_name_id,
					'exam_year'  => $exam_year_id,
				)
			);
	
			// Retrieve the last inserted student ID
			$tobesid = $this->wpdb->insert_id;
	
			// Insert marks data into the database
			$this->wpdb->insert(
				$this->prefix . 'astgdrmsys_mark',
				array(
					'sid'   => $tobesid,
					'marks' => serialize($marks_array),
				)
			);
		}
	}
}
/**
 * This script initializes the ASTGDRMSYS_StudentRecordManager and calls its display method.
 *
 * @package ResultManagementSystem
 *
 * @var ASTGDRMSYS_StudentRecordManager $ASTGDRMSYS_StudentRecordManager An instance of the ASTGDRMSYS_StudentRecordManager class.
 *
 * @method void astgdrmsys_display() Displays the student record management interface.
 */
$ASTGDRMSYS_StudentRecordManager = new ASTGDRMSYS_StudentRecordManager();
$ASTGDRMSYS_StudentRecordManager->astgdrmsys_display();

?>
