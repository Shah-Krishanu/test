<?php

/**
 * Result Management System for Institutions
 *
 * Copyright (C) 2025 ASTGD
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

/**
 * This file is part of the Result Management System for Institutions plugin.
 *
 * It ensures that the file is not accessed directly by checking if the
 * ABSPATH constant is defined. If ABSPATH is not defined, the script exits.
 *
 * @package ResultManagementSystem
 * @subpackage Menu_Files/Show_Result
 * @since 1.0.0
 */
if (! defined('ABSPATH')) {
	exit;
}

require_once ASTGDRMSYS_PLUGIN_DIR . 'includes/traits/class-astgdrmsys-grade-helper.php';

/**
 * Class ASTGDRMSYS_Show_Result
 *
 * This class is responsible for managing the results in the RMS (Result Management System) plugin.
 * It is part of the "Result Management System" plugin and is located in the "show-result" menu files.
 *
 * @package ResultManagementSystem
 * @subpackage Menu_Files/Show_Result
 * @since 1.0.0
 */

class ASTGDRMSYS_Show_Result
{
	use ASTGDRMSYS_Grade_Helper;

	private $wpdb;
	private $prefix;
	private $general_settings = array();
	private $view_settings    = array();

	/**
	 * Constructor for the class.
	 *
	 * This method initializes the class and sets up any necessary properties or methods.
	 */
	public function __construct()
	{
		global $wpdb;
		$this->wpdb   = $wpdb;
		$this->prefix = $wpdb->prefix;
		// View Settings
		$this->load_view_settings($wpdb);
		// General Settings
		$this->load_general_settings($wpdb);
	}

	/**
	 * Loads the view settings for the result management plugin.
	 *
	 * This function is responsible for loading and configuring the settings
	 * required to display the results in the plugin's interface.
	 *
	 * @return void
	 */
	private function load_view_settings($wpdb)
	{
		$cache_key           = 'view_settings';
		$this->view_settings = wp_cache_get($cache_key);

		if ($this->view_settings === false) {
			$sql = "SELECT * FROM `{$this->prefix}astgdrmsys_view_settings`";

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery
			$this->view_settings = $wpdb->get_results($sql, ARRAY_A);

			wp_cache_set($cache_key, $this->view_settings);
		}
	}

	/**
	 * Loads the general settings for the result management plugin.
	 *
	 * This function is responsible for retrieving and initializing the general settings
	 * required for the plugin to function correctly.
	 *
	 * @return void
	 */
	private function load_general_settings($wpdb)
	{
		$cache_key              = 'general_settings';
		$this->general_settings = wp_cache_get($cache_key);

		if ($this->general_settings === false) {
			$sql = "SELECT * FROM `{$this->prefix}astgdrmsys_general_settings`";

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery
			$this->general_settings = $wpdb->get_results($sql, ARRAY_A);

			wp_cache_set($cache_key, $this->general_settings);
		}
	}

	/**
	 * Renders the result management interface.
	 *
	 * This function is responsible for generating and displaying the result
	 * management interface within the plugin. It handles the necessary logic
	 * to retrieve and present the results to the user.
	 *
	 * @return void
	 */
	public function astgdrmsys_showresult_render()
	{
		$this->astgdrmsys_render_search_form();
		$this->process_result_request();
	}

	/**
	 * Renders the search form for the result management.
	 *
	 * This function generates and displays the search form used to search for results.
	 *
	 * @return void
	 */
	private function astgdrmsys_render_search_form()
	{
		$restrict_user = $this->fetch_restrict_user();

		if ($restrict_user != 0) {
			if (! is_user_logged_in()) {
				// Redirect to the WordPress login page
				wp_safe_redirect(wp_login_url());
				exit; // prevent further execution
			}
		}
		$classes       = $this->get_classes();
		$search_method = $this->get_search_method();
?>
		<center>
			<form action="<?php echo esc_url(add_query_arg(array(), isset($_SERVER['REQUEST_URI']) ? sanitize_url(wp_unslash($_SERVER['REQUEST_URI'])) : '') . '#print'); ?>" method="post">
				<?php wp_nonce_field('student_result_form', 'student_result_nonce'); ?>
				<?php wp_nonce_field('astgdrmsys_exam_search'); ?>
				<table class='table searchtable' id='table'>
					<!-- Class Dropdown -->
					<tr>
						<td><strong>Select Class</strong></td>
						<td>
							<center>
								<select name="sclass" class="selectClass" required>
									<option value="" selected disabled>Select Class</option>
									<?php foreach ($classes as $class) : ?>
										<option value="<?php echo esc_html($class['id']); ?>">
											<?php echo esc_html($class['class']); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</center>
						</td>
					</tr>
					<input type="text" name="username" value="<?php echo esc_html(wp_get_current_user()->user_login); ?>" hidden>

					<!-- Department Dropdown -->
					<tr>
						<td><strong>
								Select Department
							</strong></td>
						<td>
							<center>
								<select name="sdepartment" class="selectDepartment" required>
									<option value="" selected disabled>Select Class First</option>
								</select>
							</center>
						</td>
					</tr>

					<!-- Section Dropdown -->
					<tr>
						<td><strong>
								Select Section
							</strong></td>
						<td>
							<center>
								<select name="ssection" id="selectSection" required>
									<option value="" selected disabled>Select Department First</option>
								</select>
							</center>
						</td>
					</tr>

					<!-- Exam Name Dropdown -->
					<tr>
						<td><strong>
								Select Exam Name
							</strong>
						</td>
						<td>
							<center>
								<select name="s_exam_name" id="selectExam" required>
									<option value="" selected disabled>Select Class First</option>
								</select>
							</center>
						</td>
					</tr>

					<!-- Identifier Input (Roll/Registration Number) -->
					<tr>
						<td>
							<label for="sno">
								<strong><?php echo esc_html($search_method['label']); ?></strong>
							</label>
						</td>
						<td>
							<input type="text"
								name="sno"
								placeholder="Type Your <?php echo esc_html($search_method['label']); ?>"
								required>
						</td>
					</tr>
					<!-- Submit Button -->
					<tr>
						<td></td>
						<td>
							<center>
								<input type="submit" class="btn btn-primary" name="submit" value="Submit">
							</center>
						</td>
					</tr>
				</table>
			</form>
		</center>
	<?php
	}

	/**
	 * Retrieves the list of classes.
	 *
	 * This function fetches and returns an array of classes.
	 *
	 * @return array The list of classes.
	 */
	private function get_classes()
	{
		$sql = "SELECT * FROM `{$this->prefix}astgdrmsys_class`";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $this->wpdb->get_results($sql, ARRAY_A);
	}

	/**
	 * Retrieves the search method.
	 *
	 * This function is responsible for determining and returning the search method
	 * used in the result management system.
	 *
	 * @return string The search method.
	 */
	private function get_search_method()
	{
		$method = $this->view_settings[0]['methodfield'];
		return array(
			'method' => $method,
			'label'  => $method === 'Roll Number'
				? $this->view_settings[0]['rollfield']
				: $this->view_settings[0]['regnofield'],
		);
	}

	/**
	 * Processes the result request.
	 *
	 * This function handles the logic for processing the result request.
	 * It is a private method and should not be accessed directly.
	 *
	 * @return void
	 */
	private function process_result_request()
	{
		// Ensure the form is submitted
		if (! isset($_POST['submit'])) {
			return;
		}

		// Verify the nonce
		$nonce = isset($_POST['student_result_nonce']) ? sanitize_text_field(wp_unslash($_POST['student_result_nonce'])) : '';
		try {
			if (wp_verify_nonce($nonce, 'student_result_form')) {
				// Regenerate a new nonce and URL
				// $new_nonce = wp_create_nonce('my_plugin_nonce');
				// $new_url = add_query_arg('nonce', $new_nonce, 'https://example.com/my-plugin-url');
				// Update the user's session or database with the new nonce and URL
			} else {
				wp_safe_redirect(add_query_arg(array(), get_permalink()));
				exit;
			}
		} catch (\Throwable $th) {
			// throw $th;
			wp_safe_redirect(add_query_arg(array(), get_permalink()));
			exit;
		}

		// Fetch user restriction
		$user_restriction = $this->fetch_restrict_user();

		// Check user restrictions
		if ($user_restriction == 1 && ! is_user_logged_in()) {
			echo '<center><h2>Access Denied</h2></center>';
			return;
		}

		// fetch check user result
		$check_user_result = $this->check_user_result();

		// Fetch result data
		$result_data = $this->fetch_result_data($check_user_result);

		// Check if results exist
		if (! isset($result_data) || ! is_array($result_data) || empty($result_data)) {
			// Check if the user is logged in
			if ($check_user_result == 1 && ! is_user_logged_in()) {
				echo '<center><h3>You do not have access to view this result.</h3></center>';
				return;
			}
			// Check if the user is allowed to view the result
			if ($check_user_result == 1) {
				echo '<center><h2>You are not allowed to view this result</h2></center>';
				return;
			}
			// Check if the result is published
			if (! isset($result_data['exam_names'][0]['result_publish_status']) || $result_data['exam_names'][0]['result_publish_status'] == 0) {
				echo '<center><h2>Result not published yet</h2></center>';
				return;
			}
			// Show when result is not found
			echo '<center><h2>No Result Found</h2></center>';
			return;
		}

		// Render the result marksheet and download buttons
		$this->astgdrmsys_render_result_marksheet($result_data);
		$this->astgdrmsys_render_download_buttons();
	}

	/**
	 * Fetches the result data based on the provided user result check.
	 *
	 * @param mixed $check_user_result The user result check parameter used to fetch the result data.
	 * @return mixed The fetched result data.
	 */
	private function fetch_result_data($check_user_result)
	{
		global $wpdb;
		// Handle exam name and year
		$s_exam_name = 0;
		$s_exam_year = 0;

		if (
			isset($_POST['s_exam_name'], $_POST['_wpnonce']) &&
			wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), 'astgdrmsys_exam_search')
		) {
			$array       = explode(',', sanitize_text_field(wp_unslash($_POST['s_exam_name'])));
			$s_exam_name = $array[0] ?? 0;
			$s_exam_year = $array[1] ?? 0;
		}

		$cache_key       = 'exam_publish_status_' . $s_exam_name;
		$resultPublished = wp_cache_get($cache_key);

		if ($resultPublished === false) {
			$query = $wpdb->prepare(
				"SELECT result_publish_status FROM `{$wpdb->prefix}astgdrmsys_exam_name` WHERE id = %d",
				$s_exam_name
			);

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery
			$resultPublished = $wpdb->get_var($query);

			wp_cache_set($cache_key, $resultPublished);
		}

		// Check if it is published
		if (! $resultPublished == 1) {
			return;
		}

		// Sanitize and validate input parameters
		$id          = isset($_POST['sno']) ? sanitize_text_field(wp_unslash($_POST['sno'])) : 0;
		$sclass      = isset($_POST['sclass']) ? absint(wp_unslash($_POST['sclass'])) : 0;
		$sdepartment = isset($_POST['sdepartment']) ? absint(wp_unslash($_POST['sdepartment'])) : 0;
		$ssection    = isset($_POST['ssection']) ? absint(wp_unslash($_POST['ssection'])) : 0;
		$username    = isset($_POST['username']) ? sanitize_text_field(wp_unslash($_POST['username'])) : 0;

		// Determine search key based on view settings
		$search_method = $this->view_settings[0];
		// $searchsqlkey = $search_method['methodfield'] == 'Roll Number' ? 'sno' : 'regno';
		$searchsqlkey = in_array($search_method['methodfield'], array('Roll Number', 'Reg Number')) ? 'sno' : 'regno'; // Validate column name

		// Prepare additional SQL conditions
		$andsql              = '';
		$additional_settings = $this->view_settings[1] ?? array();
		if ($additional_settings['methodfield'] == 'true') {
			if ($check_user_result == 1) {
				$andsql = $this->wpdb->prepare(
					'AND `class` = %d AND `username` = %s AND `section` = %d AND `department` = %d AND `exam_name` = %d AND `exam_year` = %d',
					$sclass,
					$username,
					$ssection,
					$sdepartment,
					$s_exam_name,
					$s_exam_year
				);
			} else {
				$andsql = $this->wpdb->prepare(
					'AND `class` = %d AND `section` = %d AND `department` = %d AND `exam_name` = %d AND `exam_year` = %d',
					$sclass,
					$ssection,
					$sdepartment,
					$s_exam_name,
					$s_exam_year
				);
			}
		}

		// Fetch result data
		$result_data = array(
			'school_info'      => $this->fetch_school_info(),
			'view_settings'    => $this->view_settings,
			'general_settings' => $this->fetch_general_settings(),
			'classes'          => $this->get_classes(),
			'exam_names'       => $this->get_exam_names(),
			'exam_years'       => $this->get_exam_years(),
		);

		// Fetch student result
		$cache_key                     = 'student_result_' . md5($searchsqlkey . $id . $andsql);
		$result_data['student_result'] = wp_cache_get($cache_key);

		if ($result_data['student_result'] === false) {
			// sanitize table
			$result_table = esc_sql($this->prefix . 'astgdrmsys_student_result');
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$result_data['student_result'] = $wpdb->get_row(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					"SELECT * FROM $result_table WHERE `{$searchsqlkey}` = %s {$andsql}",
					$id
				),
				ARRAY_A
			);

			wp_cache_set($cache_key, $result_data['student_result']);
		}

		if (empty($result_data['student_result'])) {
			return null;
		}

		// Fetch additional data
		// $result_data['student_result']['class_details'] = $this->astgdrmsys_fetch_class_details($result_data['student_result']['class']);
		// $result_data['student_result']['subjects']      = $this->fetch_student_subjects($result_data['student_result']);
		

		// return $result_data;
		$result_data['student_result']['class_details'] = $this->astgdrmsys_fetch_class_details($result_data['student_result']['class']);
                $subject_info                                  = $this->fetch_student_subjects($result_data['student_result']);
                $result_data['student_result']['subjects']     = $subject_info['subjects'];
                $result_data['student_result']['fourth_subject_code'] = $subject_info['fourth_subject_code'];
                return $result_data;
	}

	/**
	 * Fetches information about the school.
	 *
	 * This function retrieves various details about the school, such as its name,
	 * address, contact information, and other relevant data.
	 *
	 * @return array An associative array containing school information.
	 */
	private function fetch_school_info()
	{
		$sql = "SELECT * FROM `{$this->prefix}astgdrmsys_school_info`";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$results = $this->wpdb->get_results($sql, ARRAY_A);
		return ! empty($results) ? $results[0] : array();
	}

	/**
	 * Fetches the general settings for the plugin.
	 *
	 * This function retrieves the general settings configured for the plugin.
	 * These settings may include various options and preferences that affect
	 * the behavior and functionality of the plugin.
	 *
	 * @return array An associative array containing the general settings.
	 */
	private function fetch_general_settings()
	{
		$sql = "SELECT * FROM `{$this->prefix}astgdrmsys_general_settings`";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$results_raw = $this->wpdb->get_results($sql, ARRAY_A);
		foreach ($results_raw as $setting) {
			$results[$setting['setting_key']] = $setting['setting_value'];
		}
		return ! empty($results) ? $results : array();
	}

	/**
	 * Checks the result for the current user.
	 *
	 * This function verifies and retrieves the result data for the user.
	 *
	 * @return void
	 */
	private function check_user_result()
	{
		$sql = "SELECT * FROM `{$this->prefix}astgdrmsys_general_settings` WHERE `setting_key` = 'check_user_result'";

		// Execute the query
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$settings_raw = $this->wpdb->get_results($sql, ARRAY_A);

		// Check for database errors
		if ($this->wpdb->last_error) {
			do_action('astgdrmsys_log_error', 'Database error: ' . $this->wpdb->last_error);
			return null; // or handle error appropriately
		}

		// Check if the result is empty
		if (! empty($settings_raw) && isset($settings_raw[0]['setting_value'])) {
			return $settings_raw[0]['setting_value'] == 1;
		}
	}

	/**
	 * Fetches and restricts user access based on certain criteria.
	 *
	 * This function is responsible for retrieving user information and applying
	 * restrictions to ensure that only authorized users can access certain features
	 * or data.
	 *
	 * @return void
	 */
	private function fetch_restrict_user()
	{
		$sql = "SELECT * FROM `{$this->prefix}astgdrmsys_general_settings` WHERE `setting_key` = 'restrict_user'";

		// Execute the query
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$results_raw = $this->wpdb->get_results($sql, ARRAY_A);

		// Check for database errors
		if ($this->wpdb->last_error) {
			do_action('astgdrmsys_log_error', 'Database error: ' . $this->wpdb->last_error);
			return null; // or handle error appropriately
		}

		// Check if the result is empty
		if (empty($results_raw) || ! isset($results_raw[0]['setting_value'])) {
			do_action('astgdrmsys_log_error', "No 'restrict_user' setting found in astgdrmsys_general_settings table.");
			return null; // or a default value
		}
		// Return the desired value
		return $results_raw[0]['setting_value'];
	}

	/**
	 * Retrieves all exam names from the database.
	 *
	 * This function executes a SQL query to select all records from the
	 * `astgdrmsys_exam_name` table and returns the results as an associative array.
	 *
	 * @return array An associative array of exam names.
	 */
	private function get_exam_names()
	{
		global $wpdb;
		// sanitize table name
		$exam_table = esc_sql($this->prefix . 'astgdrmsys_exam_name');
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
		return $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT * FROM $exam_table"
			),
			ARRAY_A
		);
	}

	/**
	 * Retrieves the list of exam years.
	 *
	 * This function fetches and returns an array of years for which exams have been conducted.
	 *
	 * @return array An array of exam years.
	 */
	private function get_exam_years()
	{
		global $wpdb;
		// sanitize table name
		$examyear_table = esc_sql($this->prefix . 'astgdrmsys_exam_year');
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
		return $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT * FROM $examyear_table"
			),
			ARRAY_A
		);
	}

	/**
	 * Fetches the details of a class based on the provided class ID.
	 *
	 * @param int $class_id The ID of the class to fetch details for.
	 * @return array An associative array containing the class details.
	 */
	private function astgdrmsys_fetch_class_details($class_id)
	{
		global $wpdb;
		// sanitize table name
		$class_table = esc_sql($this->prefix . 'astgdrmsys_class');

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
		$results = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared    
				"SELECT * FROM $class_table WHERE `id` = %d",
				$class_id
			),
			ARRAY_A
		);

		// Check for database errors
		return ! empty($results) ? $results[0] : array();
	}

	/**
	 * Fetches the subjects for a given student's result.
	 *
	 * @param array $student_result An associative array containing the student's result data.
	 * @return array An array of subjects associated with the student's result.
	 */
	protected function fetch_student_subjects($student_result)
	{
		global $wpdb;
		// sanitize table name
		$marks_table = esc_sql($this->prefix . 'astgdrmsys_mark');
		// Fetch marks
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
		$marks_result = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT * FROM $marks_table WHERE `sid` = %d",
				$student_result['sid']
			),
			ARRAY_A
		);

		$marks_data = ! empty($marks_result) ? unserialize($marks_result[0]['marks']) : array();
		$subjects   = array();
		$fourth_subject_code = null;
		
		if (is_array($marks_data)) {
			$fourth_subject_code = isset($marks_data['fourth_subject']) ? trim((string) $marks_data['fourth_subject']) : (isset($marks_data[0]['fourth_subject']) ? trim((string) $marks_data[0]['fourth_subject']) : null);
			$marks               = isset($marks_data[0]) ? $marks_data[0] : $marks_data;
			unset($marks['fourth_subject']);
			
			foreach ($marks as $subcode => $mark) {
				if ($subcode == 'insub') {
					continue;
				}
				
				$subject_table = esc_sql($this->prefix . 'astgdrmsys_subject');
				$subject = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT * FROM $subject_table WHERE `subcode` = %s AND `class` = %d",
						$subcode,
						$student_result['class']
					),
					ARRAY_A
				);
				
				if ($subject) {
					if (is_array($mark) && !isset($mark['total'])) {
						$mark['total'] = 0;
						foreach (['practical', 'class', 'final'] as $part) {
							if (isset($mark[$part])) {
								$mark['total'] += floatval($mark[$part]);
							}
						}
					}
					
					$is_fourth   = (trim((string) $subcode) === $fourth_subject_code);
					$subject_row = array(
						'subject'     => $subject,
						'mark'        => $mark,
						'remark'      => $this->calculate_subject_remark($subject, $mark),
						'grade_point' => $this->calculate_grade_point($subject, $mark),
						'is_fourth'   => $is_fourth,
					);
					
					if (! $is_fourth) {
						$subject_row['gpa_without_4'] = $this->calculate_gpa_without_4($subject, $mark);
					}
					
					$subjects[] = $subject_row;
				}
			}
		}

		return array(
			'subjects'            => $subjects,
			'fourth_subject_code' => $fourth_subject_code,
		);
	}

	/**
	 * Renders the result marksheet.
	 *
	 * @param array $result_data An associative array containing the result data to be displayed in the marksheet.
	 */
	private function astgdrmsys_render_result_marksheet($result_data)
	{
		global $wpdb;
		// Extract data to update result marksheet
		$result_text = $result_data['exam_names'][0];

		// Extract data for easier access
		$school_info   = $result_data['school_info'];
		$student       = $result_data['student_result'];
		$view_settings = $result_data['view_settings'];

		$subjects = $student['subjects'];
		$fourth_subject_code = $student['fourth_subject_code'] ?? null;

		$exam_table = $this->prefix . 'astgdrmsys_exam_name';
		$exam_name = $student['exam_name']; // Ensure this is exam_name ID

		$exam_type = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT exam_type FROM $exam_table WHERE id = %d",
				$exam_name
			)
		);

		$upload_dir = wp_upload_dir();
		$logo_path  = $school_info['logo']; // Full system path or relative upload path

		// Case 1: If logo is a file system path, convert to relative
		if (strpos($logo_path, $upload_dir['basedir']) !== false) {
			$relative_path = str_replace($upload_dir['basedir'], '', $logo_path);
		} else {
			// Assume it's already a relative path or filename
			$relative_path = '/' . ltrim($logo_path, '/\\');
		}

		$logo_url = esc_url($upload_dir['baseurl'] . $relative_path);

		// Calculate totals and percentages
		$totals = $this->calculate_result_totals($subjects);
	?>
		<div class='print' id='print' name='print'>
			<!-- Institute Logo -->
			<?php
			// If logo is in media library, use wp_get_attachment_image
			$attachment_id = attachment_url_to_postid($logo_url);
			if ($attachment_id) {
				// Output the logo using wp_get_attachment_image if attachment ID is found
				echo wp_get_attachment_image(
					$attachment_id,
					'medium',
					false,
					array(
						'class'     => 'watermark',
						'alt'       => esc_attr__('School Logo', 'result-management-system-for-institutions'),
						'draggable' => 'false',
					)
				);
			} else {
				// Fallback to using img tag if attachment is not found (PHPCS:ignore warning)
				// phpcs:ignore PluginCheck.CodeAnalysis.ImageFunctions.NonEnqueuedImage
				echo '<img class="watermark" draggable="false" src="' . esc_url($logo_url) . '" alt="' . esc_attr__('School Logo', 'result-management-system-for-institutions') . '">';
			}
			?>
			<div class="result-container">
				<div class="result-header">
					<!-- Institute Header -->
					<center>
						<?php
						// If logo is in media library, use wp_get_attachment_image
						if ($attachment_id) {
							echo wp_get_attachment_image(
								$attachment_id,
								'medium',
								false,
								array(
									'class' => 'logo-img',
									'alt'   => esc_attr__('School Logo', 'result-management-system-for-institutions'),
								)
							);
						} else {
							// Fallback to using img tag if attachment is not found (PHPCS:ignore warning)
							// phpcs:ignore PluginCheck.CodeAnalysis.ImageFunctions.NonEnqueuedImage
							echo '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr__('School Logo', 'result-management-system-for-institutions') . '" class="logo-img">';
						}
						?>
						<h1><?php echo esc_html($school_info['sc_name']); ?></h1>
						<div id="address">
							<?php echo esc_html($school_info['vill'] . ', ' . $school_info['ps'] . ', ' . $school_info['dist'] . ' (' . $school_info['state'] . ')'); ?>
						</div>
						<div id="result-title">
							<?php echo esc_html($result_text['result_title']); ?>
						</div>
						<div id="result-subtitle">
							<?php echo esc_html($result_text['result_subtitle']); ?>
						</div>
					</center>
				</div>
				<?php
				// Define view settings and checks
				$rowcheck = array(
					'namefield'   => $view_settings['namefield'] ?? 'false',
					'genderfield' => $view_settings['genderfield'] ?? 'false',
					'fnamefield'  => $view_settings['fnamefield'] ?? 'false',
					'mnamefield'  => $view_settings['mnamefield'] ?? 'false',
					'classfield'  => $view_settings['classfield'] ?? 'false',
					'rollfield'   => $view_settings['rollfield'] ?? 'false',
					'regnofield'  => $view_settings['regnofield'] ?? 'false',
				);

				$rowview = array(
					'namefield'   => 'Student Name',
					'genderfield' => 'Gender',
					'fnamefield'  => 'Father\'s Name',
					'mnamefield'  => 'Mother\'s Name',
					'classfield'  => 'Class',
					'rollfield'   => 'Roll No',
					'regnofield'  => 'Registration No',
				);
				?>

				<!-- Student Details Table -->
				<table border='1' class="table-style">
					<?php
					// Name and Gender Row
					if ($rowcheck['namefield'] == 'false' || $rowcheck['genderfield'] == 'false') :
					?>
						<tr>
							<?php if ($rowcheck['namefield'] == 'false') : ?>
								<td <?php echo $rowcheck['genderfield'] != 'false' ? 'colspan="2"' : ''; ?>>
									<strong><?php echo esc_html($rowview['namefield']); ?></strong>
								</td>
								<td <?php echo $rowcheck['genderfield'] != 'false' ? 'colspan="2"' : ''; ?>>
									<?php echo esc_html($student['name']); ?>
								</td>
							<?php endif; ?>

							<?php if ($rowcheck['genderfield'] == 'false') : ?>
								<td <?php echo $rowcheck['namefield'] != 'false' ? 'colspan="2"' : ''; ?>>
									<strong><?php echo esc_html($rowview['genderfield']); ?></strong>
								</td>
								<td <?php echo $rowcheck['namefield'] != 'false' ? 'colspan="2"' : ''; ?>>
									<?php echo esc_html($student['gender']); ?>
								</td>
							<?php endif; ?>
						</tr>
					<?php endif; ?>

					<?php
					// Father's Name and Mother's Name Row
					if ($rowcheck['fnamefield'] == 'false' || $rowcheck['mnamefield'] == 'false') :
					?>
						<tr>
							<?php if ($rowcheck['fnamefield'] == 'false') : ?>
								<td <?php echo $rowcheck['mnamefield'] != 'false' ? 'colspan="2"' : ''; ?>>
									<strong><?php echo esc_html($rowview['fnamefield']); ?></strong>
								</td>
								<td <?php $rowcheck['mnamefield'] != 'false' ? 'colspan="2"' : ''; ?>>
									<?php echo esc_html($student['fname']); ?>
								</td>
							<?php endif; ?>

							<?php if ($rowcheck['mnamefield'] == 'false') : ?>
								<td <?php $rowcheck['fnamefield'] != 'false' ? 'colspan="2"' : ''; ?>>
									<strong><?php echo esc_html($rowview['mnamefield']); ?></strong>
								</td>
								<td <?php echo $rowcheck['fnamefield'] != 'false' ? 'colspan="2"' : ''; ?>>
									<?php echo esc_html($student['mname']); ?>
								</td>
							<?php endif; ?>
						</tr>
					<?php
					endif;
					// Class and Roll No Row
					if ($rowcheck['classfield'] == 'false' || $rowcheck['rollfield'] == 'false') :
					?>
						<tr>
							<?php if ($rowcheck['classfield'] == 'false') : ?>
								<td <?php echo $rowcheck['rollfield'] != 'false' ? 'colspan="2"' : ''; ?>>
									<strong><?php echo esc_html($rowview['classfield']); ?></strong>
								</td>
								<td
									<?php
									$rowcheck['rollfield'] != 'false' ? 'colspan="2"' : '';
									$colStdClass = $this->astgdrmsys_fetch_class_details($student['class']); // fetching class column
									?>>
									<?php echo esc_html($colStdClass['class'] ?? ''); ?>
								</td>
							<?php
							endif;
							if ($rowcheck['rollfield'] == 'false') :
							?>
								<td <?php echo $rowcheck['rollfield'] != 'false' ? 'colspan="2"' : ''; ?>>
									<strong><?php echo esc_html($rowview['rollfield']); ?></strong>
								</td>
								<td <?php echo $rowcheck['classfield'] != 'false' ? 'colspan="2"' : ''; ?>>
									<?php echo esc_html($student['sno'] ?? ''); ?>
								</td>
							<?php endif; ?>
						</tr>
					<?php
					endif;
					// Registration Number Row
					if ($rowcheck['regnofield'] == 'false') :
					?>
						<tr>
							<th colspan="2">
								<?php echo esc_html($rowview['regnofield']); ?>
							</th>
							<td colspan="2">
								<?php echo esc_html($student['regno'] ?? ''); ?>
							</td>
						</tr>
					<?php endif; ?>
				</table>
				<!-- Subjects Marks Table -->
				<table border='1' class="table-style">
					<thead>
						<tr>
							<?php if ($exam_type === 'composite') : ?>
								<th>Subject</th>
								<th>Class Mark</th>
								<th>Final Mark</th>
								<th>Total Mark</th>
								<th>Letter Grade</th>
								<th>Grade Point</th>
								<th>Final GPA</th>
							<?php else : ?>
								<th>Subject</th>
								<th>Mark</th>
								<th>Grade</th>
								<th>Grade Point</th>
								<th>GPA</th>
							<?php endif; ?>
						</tr>
					</thead>
					<tbody>
						<?php
						// Separate subjects for easier processing
						$main_subjects  = array();
						$fourth_subject = null;
						foreach ($subjects as $subject_item) {
							$subcode   = $subject_item['subject']['subcode'] ?? null;
							$is_fourth = !empty($subject_item['is_fourth']) || ($fourth_subject_code !== null && $subcode === $fourth_subject_code);
							
							if ($is_fourth) {
								$fourth_subject = $subject_item;
							} else {
								$main_subjects[] = $subject_item;
							}
						}

						// Calculate GPA and other metrics
						$total_gpa        = 0;
						$fourthsubjectgpa = 0;
						$subject_count    = count($main_subjects); // Count only main subjects

						foreach ($main_subjects as $subject_item) {
							$total_gpa += $subject_item['gpa_without_4'] ?? 0;
						}

						if ($fourth_subject && isset($fourth_subject['grade_point'])) {
							if ($fourth_subject['grade_point'] > 2) {
								$fourthsubjectgpa = $fourth_subject['grade_point'] - 2;
							}
						}

						// Calculate final GPAs
						$average_gpa   = $subject_count > 0 ? round($total_gpa / $subject_count, 2) : 0;
						$finaltotalgpa = $subject_count > 0 ? min(5, round(($total_gpa + $fourthsubjectgpa) / $subject_count, 2)) : 0;
						$gpaboxtaken   = false;

						// Render Main Subjects
						foreach ($main_subjects as $subject) :
						?>
							<tr>
								<td><?php echo esc_html($subject['subject']['subname'] . ' - ' . $subject['subject']['subcode']); ?></td>
								<?php if ($exam_type === 'composite') : ?>
									<td><?php echo esc_html($subject['mark']['class'] ?? '-'); ?></td>
									<td><?php echo esc_html($subject['mark']['final'] ?? '-'); ?></td>
									<td><?php echo esc_html($subject['mark']['class'] + $subject['mark']['final']) ?? '-' ; ?></td>
								<?php else : ?>
									<td>
										<?php
										if (is_array($subject['mark']) && isset($subject['mark']['final'])) {
											echo esc_html(is_array($subject['mark']['final']) 
											? implode(', ', $subject['mark']['final']) 
											: $subject['mark']['final']);
										} else {
											echo esc_html($subject['mark'] ?? '-');
										}
										?>
									</td>
								<?php endif; ?>
								<td><?php echo esc_html($subject['remark']); ?></td>
								<td><?php echo esc_html($subject['grade_point']); ?></td>
								<?php
								    if (! $gpaboxtaken && $subject_count > 0) {
										$colspan = ($exam_type === 'composite') ? 3 : 2;
										echo '<td colspan="' . esc_attr($colspan) . '" rowspan="' . esc_attr($subject_count) . '"><span class="finalgpa">' . esc_html($finaltotalgpa) . '</span></td>';
										$gpaboxtaken = true;
									}
								?>
							</tr>
						<?php
						endforeach;

						// Render Average GPA row (after main subjects)
						?>
						<tr>
							<td colspan="<?php echo ($exam_type === 'composite') ? '4' : '3'; ?>" class="text-right"><strong>Average GPA (Excl. Optional):</strong></td>
							<td class="average-gpa" colspan="<?php echo ($exam_type === 'composite') ? '4' : '3'; ?>"><?php echo esc_html($average_gpa); ?></td>
						</tr>
						<?php

						// Render the Fourth (Optional) Subject, if it exists
						if ($fourth_subject) :
						?>
							<tr>
								<td colspan="<?php echo ($exam_type === 'composite') ? '7' : '5'; ?>">
									<p class="additional-subject-label">Additional Subject:</p>
								</td>
							</tr>
							<tr>
								<td colspan="<?php echo ($exam_type === 'composite') ? '7' : '5'; ?>" class="added_gpa"><em>Added to GPA</em></td>
							</tr>
							<tr class="fourth-sub-row">
								<td><?php echo esc_html($fourth_subject['subject']['subname'] . ' - ' . $fourth_subject['subject']['subcode']); ?></td>
								<?php if ($exam_type === 'composite') : ?>
									<td><?php echo esc_html($fourth_subject['mark']['class'] ?? '-'); ?></td>
									<td><?php echo esc_html($fourth_subject['mark']['final'] ?? '-'); ?></td>
									<td><strong><?php echo esc_html($fourth_subject['mark']['total'] ?? '-'); ?></strong></td>
									<?php else : // single ?>
									<td><?php echo esc_html($fourth_subject['mark']['final'] ?? ($fourth_subject['mark'] ?? '-')); ?></td>
									<?php endif; ?>
									<td><?php echo esc_html($fourth_subject['remark']); ?></td>
									<td><?php echo esc_html($fourth_subject['grade_point']); ?></td>
									<td><?php echo esc_html(max(0, $fourth_subject['grade_point'] - 2)); ?></td>
							</tr>
						<?php
						endif;
						// Render the final Total row
						?>
						<tr>
							<th>Total</th>
							<th colspan="<?php echo ($exam_type === 'composite') ? '3' : '2'; ?>"><?php echo esc_html($totals['obtained_marks']); ?></th>
							<th colspan="3"><?php echo esc_html($totals['total_remark']); ?></th>
						</tr>
						<?php
						?>
					</tbody>
				</table>
				<!-- Result Summary -->
				<table class="table-style">
					<tr>
						<th>Percentage</th>
						<td class="result-td"><?php echo number_format($totals['percentage'], 2); ?>%</td>
						<th>Result</th>
						<td class="result-td"><?php echo esc_html($totals['final_result']); ?></td>
					</tr>
				</table>
			</div>
			<div id="result-footer">
				<?php echo esc_html($result_text['result_footer_text']); ?>
			</div>
		</div>
	<?php
	}

	/**
	 * Calculate the total results for the given subjects.
	 *
	 * @param array $subjects An array of subjects to calculate the totals for.
	 * @return array The calculated totals for each subject.
	 */
	private function calculate_result_totals($subjects, $fourth_subject_code = null)
	{
		// Initialize variables
		$main_subjects_obtained = 0;
		$main_subjects_total    = 0;
		$total_min_marks        = 0;
		
		foreach ($subjects as $subject) {
			// get the 'total' obtained mark for a subject
			$obtained_mark = 0;
			if (isset($subject['mark'])) {
				$obtained_mark = is_array($subject['mark']) ? floatval($subject['mark']['total'] ?? 0) : floatval($subject['mark']);
			}
			
			$subcode    = $subject['subject']['subcode'] ?? null;
			$is_optional = !empty($subject['is_fourth']) || ($fourth_subject_code !== null && $subcode === $fourth_subject_code);
			
			// Only include the subject if it's NOT a fourth/optional subject.
			if (! $is_optional) {
				$main_subjects_obtained += $obtained_mark;
				$main_subjects_total    += floatval($subject['subject']['total']);
				$total_min_marks        += floatval($subject['subject']['minmark']);
			}
		}
	
		// calculate the percentage using ONLY the main subject totals.
		$percentage = $main_subjects_total > 0 ? ($main_subjects_obtained * 100 / $main_subjects_total) : 0;
	
		// Determine total remark and final result based on the correct percentage
		$total_remark = $this->get_total_remark($percentage);
		$final_result = $this->get_final_result($percentage);
	
		return array(
			'obtained_marks'  => $main_subjects_obtained, // Total for main subjects only
			'total_marks'     => $main_subjects_total,
			'total_min_marks' => $total_min_marks,
			'percentage'      => $percentage,
			'total_remark'    => $total_remark,
			'final_result'    => $final_result,
		);
	}


	/**
	 * Calculate the total remark based on the given percentage.
	 *
	 * @param float $percentage The percentage to evaluate for the remark.
	 * @return string The total remark corresponding to the given percentage.
	 */
	private function get_total_remark($percentage)
	{
		if ($percentage >= 95) {
			return 'Outstanding';
		}
		if ($percentage > 80) {
			return 'Exceptional';
		}
		if ($percentage > 70) {
			return 'Excellent';
		}
		if ($percentage > 55) {
			return 'Good';
		}
		if ($percentage > 40) {
			return 'Satisfactory';
		}
		if ($percentage > 30) {
			return 'Partially Acceptable';
		}
		if ($percentage > 25) {
			return 'Barely Acceptable';
		}
		return 'Unacceptable';
	}

	/**
	 * Retrieves the final result based on the given percentage.
	 *
	 * @param float $percentage The percentage to calculate the final result.
	 * @return mixed The final result based on the percentage.
	 */
	private function get_final_result($percentage)
	{
		if ($percentage > (100 - 40)) {
			return 'First Division';
		}
		if ($percentage > (100 - 60)) {
			return 'Second Division';
		}
		return 'Third Division';
	}


	/**
	 * Renders the download buttons for the result management interface.
	 *
	 * This function generates and displays the buttons that allow users to download
	 * results in various formats.
	 *
	 * @return void
	 */
	private function astgdrmsys_render_download_buttons()
	{
	?>
		<center>
			<input type="button"
				id="printResult"
				class="btn btn-info"
				value="Print Marksheet">
			<input type="button"
				id="downloadResult"
				class="btn btn-info"
				value="Download Marksheet">
		</center>
<?php
	}
}

/**
 *
 * This script initializes and renders the ASTGDRMSYS_Show_Result.
 *
 * @package ResultManagementSystemResultManagement
 * @subpackage ASTGDRMSYS_Show_Result
 *
 * @class ASTGDRMSYS_Show_Result
 * @method render() Renders the result manager interface.
 */
$result_manager = new ASTGDRMSYS_Show_Result();
$result_manager->astgdrmsys_showresult_render();
