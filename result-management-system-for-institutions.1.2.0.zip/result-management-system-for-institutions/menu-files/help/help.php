<?php

/**
 * Result Management System for Institutions
 *
 * Copyright (C) 2025 ASTGD
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

/**
 * Help Menu File for Result Management System for Institutions Plugin
 *
 * This file is part of the Result Management System for Institutions plugin and is responsible for
 * displaying the help menu content.
 *
 * @package ResultManagementSystem
 * @subpackage Menu_Files_Help
 * @since 1.0.0
 */

if (! defined('ABSPATH')) {
	exit;
}
/**
 * This file is part of the Result Management System for Institutions plugin.
 *
 * It contains the HTML structure for the help section of the plugin.
 *
 * @package ASTGD_Result_Management
 *
 * @section astgdrmsys-help-section
 * This section contains individual help sections within the main container.
 */

?>
<div class="astgdrmsys-help-container">
	<div class="astgdrmsys-help-section">
		<form id="astgdrmsys-help-nonce-form" method="post">
			<?php wp_nonce_field('astgdrmsys_help_nonce', 'astgdrmsys_help_nonce'); ?>
		</form>
		<h2 class="astgdrmsys-help-title">Help & Guide</h2>
		<div class="astgdrmsys-guide-section">
			<h3>All in One Result Management System</h3>
			<p>To Create a Marksheet, follow these steps:</p>

			<ol class="astgdrmsys-step-list">
				<li>Add Class</li>
				<li>Add Department to a selected Class</li>
				<li>Add Section(s) to a department</li>
				<li>Add Exam Year(s)</li>
				<li>Add Exam Name(s)</li>
				<li>Add Student Records</li>
				<li>Copy plugin Shortcode: <code>[astgdrmsys_show_result]</code></li>
				<li>Paste Shortcode in the Post or Page so students can search their results</li>
			</ol>
		</div>

		<div class="astgdrmsys-grade-settings">
			<h3>How to change Grade Settings</h3>
			<p>To set up the grading system:</p>
			<ol>
				<li>Go to <strong>Settings</strong> in the plugin menu</li>
				<li>Select <strong>Grade System</strong> tab</li>
				<li>Predefined grading scales can be edited and updated to reflect standardized mark ranges (e.g., A: 90–100%, B: 80–89%, etc.), ensuring clarity and consistency in assessment criteria.</li>
				<li>Add new grade with proper credentials by clicking "<strong>Add New Grade Range</strong>"</li>
				<li>Save your settings</li>
			</ol>
			<p>This will allow you to assign grades to students based on their marks.</p>
		</div>

		<div class="astgdrmsys-support-section">
			<h3>Support</h3>
			<p>In case you need support:</p>
			<ul>
				<li>* Email us at <strong><a href="mailto:info@astgd.com">info@astgd.com</a></strong></li>
				<li>* <strong>Contact us for additioal features or assistance</strong></li>
			</ul>
		</div>

		<div class="astgdrmsys-import-section">
			<h3 id="import">How to import bulk records from CSV File</h3>
			<p>Currently the free version can upload only Single Assessment exam type. For more complex system please contact us.</p>

			<ol class="astgdrmsys-import-steps">
				<li>Download the CSV Format from Add Result Page</li>
				<li>After adding Classes, Departments, Sections, Exam Years, Exam Names, and Subjects, go to Subject Information area on Dashboard Page</li>
				<li>Note down the following IDs:
					<ul>
						<li><strong>Class Id</strong></li>
						<li><strong>Department Id</strong></li>
						<li><strong>Section Id</strong></li>
						<li><strong>Exam Name Id</strong></li>
						<li><strong>Exam Year Id</strong></li>
						<li><strong>Subject Code</strong></li>
					</ul>
				</li>
				<li>
					<div class="astgdrmsys-help-image help-info-image" aria-label="Help Info" role="img"></div>
				</li>
				<li>In the CSV file, you'll find a column named Class Id and multiple Subject & Mark columns</li>
				<li>
					<strong>Example:</strong> If a class has ID 2 and two subjects with IDs 3 & 4,
					these subject IDs (3 & 4) will be under Class ID (2)
				</li>
				<li>
					<div class="astgdrmsys-help-image help-csv-image" aria-label="CSV Import Example" role="img"></div>
				</li>
			</ol>

			<div class="astgdrmsys-import-notes">
				<h4>Important Notes:</h4>
				<ul>
					<li>The Gender field can only be capital 'MALE', 'FEMALE', or 'OTHERS'</li>
					<li>You can add up to 10 Subjects per Student/Class</li>
				</ul>
			</div>
		</div>
	</div>
</div>