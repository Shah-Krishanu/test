<?php

/**
 * Trait: ASTGDRMSYS_Grade_Helper
 * Contains grading logic shared across result and marksheet classes.
 */

trait ASTGDRMSYS_Grade_Helper
{
	/**
	 * Fetches the subjects and corresponding marks for a given student result.
	 *
	 * This method retrieves the student's marks from the database, unserializes them,
	 * and then fetches subject details for each subject code. It constructs an array
	 * of subjects with their marks, remarks, grade points, and optionally GPA (excluding fourth subjects).
	 *
	 * @param array $student_result The associative array containing student result data, including 'sid' (student ID) and 'class'.
	 * @return array An array of subjects with their details, marks, remarks, grade points, and GPA (if applicable).
	 */
	protected function fetch_student_subjects($student_result)
	{
		global $wpdb;

		$marks_table = esc_sql($this->prefix . 'astgdrmsys_mark');
		$marks_result = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $marks_table WHERE `sid` = %d",
				$student_result['sid']
			),
			ARRAY_A
		);

		$marks = ! empty($marks_result) ? unserialize($marks_result[0]['marks']) : array();
		$subjects = [];

		if (is_array($marks)) {
			$marks = isset($marks[0]) ? $marks[0] : $marks;

			foreach ($marks as $subcode => $mark) {
				if ($subcode === 'insub') {
					continue;
				}

				$subject_table = esc_sql($this->prefix . 'astgdrmsys_subject');
				$subject = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT * FROM $subject_table WHERE `subcode` = %s AND `class` = %d",
						$subcode,
						$student_result['class']
					),
					ARRAY_A
				);

				if ($subject) {
					if ($subject['isFourthSubject'] == 0) {
						$subjects[] = [
							'subject'       => $subject,
							'mark'          => $mark,
							'remark'        => $this->calculate_subject_remark($subject, $mark),
							'grade_point'   => $this->calculate_grade_point($subject, $mark),
							'gpa_without_4' => $this->calculate_gpa_without_4($subject, $mark),
						];
					} else {
						$subjects[] = [
							'subject'     => $subject,
							'mark'        => $mark,
							'remark'      => $this->calculate_subject_remark($subject, $mark),
							'grade_point' => $this->calculate_grade_point($subject, $mark),
						];
					}
				}
			}
		}

		return $subjects;
	}

	/**
	 * Calculates the remark (grade) for a given subject based on the obtained mark.
	 *
	 * This method determines the grade by comparing the obtained mark against the grading system
	 * stored in the database. If the total mark is zero or the obtained mark is invalid, it returns 'F'.
	 *
	 * @param array $subject The subject information, including the total possible mark.
	 * @param mixed $mark The obtained mark, either as a float/int or an array with a 'total' key.
	 * @return string The grade remark (e.g., 'A', 'B', 'C', 'F').
	 */
	protected function calculate_subject_remark($subject, $mark)
	{
		$obtained_mark = is_array($mark) ? floatval($mark['total'] ?? -1) : floatval($mark);
		$total_mark    = isset($subject['total']) ? floatval($subject['total']) : 0;

		if ($total_mark == 0 || $obtained_mark < 0) {
			return 'F';
		}

		global $wpdb;
		$grade_table = esc_sql($this->prefix . 'astgdrmsys_grade_system');

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
		$grade = $wpdb->get_row(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT * FROM $grade_table WHERE min_mark <= %f AND max_mark >= %f LIMIT 1",
				$obtained_mark,
				$obtained_mark
			),
			ARRAY_A
		);

		return $grade['grade'] ?? 'F';
	}

	/**
	 * Calculates the grade point for a given subject and obtained mark.
	 *
	 * This method determines the grade point by comparing the obtained mark against
	 * the grade boundaries defined in the database table. If the total mark is zero
	 * or the obtained mark is invalid, it returns 0.
	 *
	 * @param array $subject The subject details, including the total possible mark.
	 * @param mixed $mark The obtained mark, either as a float/int or an array with a 'total' key.
	 * @return float The calculated grade point, or 0 if not applicable.
	 */
	protected function calculate_grade_point($subject, $mark)
	{
		$obtained_mark = is_array($mark) ? floatval($mark['total'] ?? -1) : floatval($mark);
		$total_mark    = isset($subject['total']) ? floatval($subject['total']) : 0;

		if ($total_mark == 0 || $obtained_mark < 0) {
			return 0;
		}

		global $wpdb;
		$grade_table = esc_sql($this->prefix . 'astgdrmsys_grade_system');

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
		$grade = $wpdb->get_row(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT * FROM $grade_table WHERE min_mark <= %f AND max_mark >= %f LIMIT 1",
				$obtained_mark,
				$obtained_mark
			),
			ARRAY_A
		);

		return isset($grade['grade_point']) ? floatval($grade['grade_point']) : 0;
	}

	/**
	 * Calculates the GPA (Grade Point Average) for a subject without using a 4-point scale.
	 *
	 * This method determines the grade point based on the obtained marks for a subject,
	 * referencing the grade system table in the database. It handles both array and scalar
	 * mark inputs, validates the marks, and retrieves the corresponding grade point.
	 *
	 * @param array $subject The subject information, including the total possible marks.
	 * @param mixed $mark The obtained mark(s) for the subject. Can be an array with a 'total' key or a numeric value.
	 * @return float The calculated grade point for the obtained mark, or 0 if invalid.
	 */
	protected function calculate_gpa_without_4($subject, $mark)
	{
		$obtained_mark = is_array($mark) ? floatval($mark['total'] ?? -1) : floatval($mark);
		$total_mark    = isset($subject['total']) ? floatval($subject['total']) : 0;

		if ($total_mark == 0 || $obtained_mark < 0) {
			return 0;
		}

		global $wpdb;
		$grade_table = esc_sql($this->prefix . 'astgdrmsys_grade_system');

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
		$grade = $wpdb->get_row(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT * FROM $grade_table WHERE min_mark <= %f AND max_mark >= %f LIMIT 1",
				$obtained_mark,
				$obtained_mark
			),
			ARRAY_A
		);

		return isset($grade['grade_point']) ? floatval($grade['grade_point']) : 0;
	}

	/**
	 * Retrieves subjects associated with a specific class ID.
	 *
	 * Queries the database for all subjects linked to the provided class ID
	 * and returns them as an associative array, indexed by subject code.
	 *
	 * @param int $class_id The ID of the class to retrieve subjects for.
	 * @return array Associative array of subjects, keyed by subject code.
	 */
	public function get_subjects_by_class($class_id)
	{
		global $wpdb;
		$table = $wpdb->prefix . 'astgdrmsys_subject';

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$results = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT * FROM $table WHERE class = %d",
				$class_id
			),
			ARRAY_A
		);

		$subjects = [];
		foreach ($results as $row) {
			$subjects[$row['subcode']] = $row;
		}
		return $subjects;
	}

	/**
	 * Retrieves the marks for a student by their student ID (sid).
	 *
	 * This function queries the database for the serialized marks data associated with the given student ID,
	 * unserializes the data, and returns the first element of the marks array if available.
	 *
	 * @param int $sid The student ID whose marks are to be retrieved.
	 * @return array The marks data for the student, or an empty array if not found or invalid.
	 */
	public function get_student_marks($sid)
	{
		global $wpdb;
		$table = $wpdb->prefix . 'astgdrmsys_mark';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
		$result = $wpdb->get_row(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT marks FROM $table WHERE sid = %d",
				 $sid
				),
			ARRAY_A
		);

		if (! $result || empty($result['marks'])) {
			return [];
		}

		$data = maybe_unserialize($result['marks']);
		return is_array($data) && isset($data[0]) ? $data[0] : [];
	}
}
