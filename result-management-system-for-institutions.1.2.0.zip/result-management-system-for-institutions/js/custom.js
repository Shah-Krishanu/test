jQuery(document).ready(function ($) {
  // Handle class change
  $(".selectClass").on("change", function () {
    var class_id = $(this).val();

    // Clear the departments dropdown
    $(".selectDepartment").html('<option value="">Loading...</option>');

    // Make the AJAX request to fetch departments
    $.ajax({
      url: astgdrmsys_ajax_object.ajaxurl,
      type: "POST",
      dataType: "json",
      data: {
        action: "astgdrmsys_get_departments_by_class",
        class: class_id,
        nonce: astgdrmsys_ajax_object.nonce,
      },
      success: function (response) {
        if (response.success) {
          var departments = response.data; // Access the data directly
          var departmentOptions =
            '<option value="" selected disabled>Select Department</option>';
          departments.forEach(function (department) {
            departmentOptions +=
              '<option value="' +
              department.id +
              '">' +
              department.department +
              "</option>";
          });
          $(".selectDepartment").html(departmentOptions);
        } else {
          console.error("Error:", response.data);
          $(".selectDepartment").html(
            '<option value="">Error loading departments</option>'
          );
        }
      },
      error: function (xhr, status, error) {
        console.error("AJAX error:", xhr, status, error);
        $(".selectDepartment").html(
          '<option value="">Failed to load departments</option>'
        );
      },
    });

    // Clear the exams dropdown
    $("#selectExam").html('<option value="">Loading...</option>');

    // Make the AJAX request to fetch exam names and exam years
    $.ajax({
      url: astgdrmsys_ajax_object.ajaxurl,
      type: "POST",
      dataType: "json",
      data: {
        action: "astgdrmsys_get_exam_names_by_class",
        class: class_id,
        nonce: astgdrmsys_ajax_object.nonce,
      },
      success: function (response) {
        if (response.success) {
          var exams = response.data; // Access the data directly
          var examOptions =
            '<option value="" selected disabled>Select Exam</option>';
          exams.forEach(function (exam) {
            examOptions +=
              '<option value="' +
              exam.id +
              "," +
              exam.exam_year_id +
              '">' +
              exam.exam_name +
              " - " +
              exam.exam_year +
              "</option>";
          });
          $("#selectExam").html(examOptions);
        } else {
          console.error("Error:", response.data);
          $("#selectExam").html(
            '<option value="">Error loading exams</option>'
          );
        }
      },
      error: function (xhr, status, error) {
        console.error("AJAX error:", xhr, status, error);
        $("#selectExam").html('<option value="">Failed to load exams</option>');
      },
    });
  });

  // Handle department change
  $(".selectDepartment").on("change", function () {
    var department_id = $(this).val();

    // Clear the sections dropdown
    $("#selectSection").html('<option value="">Loading...</option>');

    // Make the AJAX request to fetch sections
    $.ajax({
      url: astgdrmsys_ajax_object.ajaxurl,
      type: "POST",
      dataType: "json",
      data: {
        action: "astgdrmsys_get_sections_by_department",
        department: department_id,
        nonce: astgdrmsys_ajax_object.nonce,
      },
      success: function (response) {
        if (response.success) {
          var sections = response.data; // Access the data directly
          var sectionOptions =
            '<option value="" selected disabled>Select Section</option>';
          sections.forEach(function (section) {
            sectionOptions +=
              '<option value="' +
              section.id +
              '">' +
              section.section +
              "</option>";
          });
          $("#selectSection").html(sectionOptions);
        } else {
          console.error("Error:", response.data);
          $("#selectSection").html(
            '<option value="">Error loading sections</option>'
          );
        }
      },
      error: function (_xhr, status, error) {
        console.error("AJAX error:", status, error);
        $("#selectSection").html(
          '<option value="">Failed to load sections</option>'
        );
      },
    });
  });

  // To get class name from the selected option in add-section.php ln:488
  $("#departmentadd").on("change", function () {
    const option = this.options[this.selectedIndex];
    $("#hiddenclassname").val(option.dataset.class);
  });

  // To hide the modal when clicked outside in add-class.php ln: 369
  if (window.location.href.includes("admin.php?page=astgdrmsys-class")) {
    $(".close-class-modal, .cancel-button").on("click", function () {
      $("#addmodal").hide();
    });
  }

  // To hide the modal when clicked outside in add-department.php ln: 406
  if (window.location.href.includes("admin.php?page=astgdrmsys-department")) {
    $(window).on("click", function (event) {
      if ($(event.target).is("#add-dept-modal")) {
        $("#add-dept-modal").hide();
      }
    });
  }

  // To get class name from the selected option in add-department.php ln: 373
  if (window.location.href.includes("admin.php?page=astgdrmsys-section")) {
    function updateDepartmentClass() {
      let selectedOption = $("#updatedepartment option:selected");
      $("#updateHiddenClassname").val(selectedOption.data("class"));
    }

    // Trigger function on select change
    $("#updatedepartment").on("change", updateDepartmentClass);

    // Initialize on page load
    updateDepartmentClass();
  }

  // To check if the file uploaded is a CSV file in add-record.php ln:220
  if (window.location.href.includes("admin.php?page=astgdrmsys-add-record")) {
    $(".add-record-form").on("submit", function (event) {
      var fileInput = $("#CSV_file");
      var filePath = fileInput.val();

      if (filePath === "") {
        alert("Please select a CSV file before submitting.");
        event.preventDefault(); // Prevent form submission
        return;
      }

      var allowedExtension = /\.csv$/i;
      if (!allowedExtension.test(filePath)) {
        alert("Please upload a valid CSV file for.");
        fileInput.val(""); // Clear the input field
        event.preventDefault(); // Prevent form submission
        return;
      }
    });
  }

  // To copy the URL to clipboard in astgdrmsys-settings.php ln: 753
  if (window.location.href.includes("admin.php?page=astgdrmsys-settings")) {
    // Copy the URL to clipboard
    $(document).on("click", "#copy-button", function () {
      var button = $(this);
      var text = $("#saved-url").text().trim();

      if (!text) {
        alert("No URL found!");
        return;
      }

      if (navigator.clipboard && navigator.clipboard.writeText) {
        // Modern way to copy text
        navigator.clipboard
          .writeText(text)
          .then(function () {
            button.text("URL Copied").css("color", "white");
          })
          .catch(function (error) {
            console.error("Clipboard API failed: ", error);
            fallbackCopyText(text, button);
          });
      } else {
        // Fallback for older browsers
        console.warn("Clipboard API not supported, using fallback.");
        fallbackCopyText(text, button);
      }

      setTimeout(function () {
        button.text("Copy").css("color", "");
      }, 3000);
    });

    // Fallback function using execCommand
    function fallbackCopyText(text, button) {
      var tempInput = $("<input>");
      $("body").append(tempInput);
      tempInput.val(text).select();
      document.execCommand("copy");
      tempInput.remove();
      button.text("URL Copied").css("color", "white");
    }
  }

  if (window.location.href.includes("admin.php?page=astgdrmsys-all-students")) {
    // Use CDN for Bootstrap to ensure proper loading
    var styles = `<link rel="stylesheet" href="${astgdrmsys_ajax_object.pluginUrl}css/bootstrap.css" type="text/css">`;
    var done = $("head").append(styles);
    if (done) {
      console.log("Bootstrap CSS loaded successfully!");
    }
  }

  // To hide the modal
  if (window.location.href.includes("admin.php?page=astgdrmsys-exam-name")) {
    // Show modal
    $("#openModalBtn").on("click", function () {
      $("#addmodal").show();
    });

    // Hide modal
    $("#closeModalBtn").on("click", function () {
      $("#addmodal").hide();
    });

    // Update department/class hidden inputs
    $("#selectDepartmentId").on("change", function () {
      var selectedValue = $(this).val();
      var values = selectedValue.split("-");
      var departmentId = values[0];
      var classId = values[1];

      var className = $(this).find("option:selected").text().split(" - ")[1];

      $("#hiddenclassname").val(className);
      $("#hiddenclassid").val(classId);
    });

    // Update hidden exam year ID
    $("#ExamYearId").on("change", function () {
      var selectedValue = $(this).val();
      var values = selectedValue.split("-");
      var examYear = values[0];
      var examYearId = values[1];

      $("#hiddenExamYearId").val(examYearId);
    });
  }

  // To hide the modal for subject
  if (window.location.href.includes("admin.php?page=astgdrmsys-subject")) {
    $(".close-subject-modal, .cancel-button").on("click", function () {
      $("#addmodal").hide();
    });
    // Show modal
    $("#addsub").on("click", function () {
      $("#addmodal").show().css("display", "flex");
    });
  }

  // for add-mark.php
  if (
    window.location.href.includes("admin.php?page=astgdrmsys-add-mark") ||
    window.location.href.includes("admin.php?page=astgdrmsys-exam-name")
  ) {
    $(".close-message").on("click", function () {
      $(this).closest("#message_div").hide();
    });

        function calculateTotal(row) {
        const classMark = parseFloat(row.find('.class-mark').val()) || 0;
        const finalMark = parseFloat(row.find('.final-mark').val()) || 0;
        row.find('.total-mark').val(classMark + finalMark);
    }

    $('.class-mark, .final-mark').on('input', function() {
        const row = $(this).closest('tr');
        calculateTotal(row);
    });
    
  }

  // For settings page
  if (window.location.href.includes("admin.php?page=astgdrmsys-settings")) {
    // Show the new grade row when the button is clicked
    $("#astgdrmsys-show-new-grade").on("click", function () {
      // Show the hidden row
      $("#astgdrmsys-new-grade-row").show();

      // Add required attributes only when visible
      $("#astgdrmsys-new-grade-row")
        .find('input[name^="new_grade"]')
        .attr("required", true);

      // Hide the button itself
      $(this).hide();
    });
  }

});
