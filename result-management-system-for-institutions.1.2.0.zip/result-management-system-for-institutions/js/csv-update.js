jQuery(document).ready(function ($) {
  // Form validation for selecting class and exam name
  $("#csvupdateForm").on("submit", function (e) {
    var csvFile = $("#csvUpdateFile").val();
    var messages = []; // empty array for messages

    if (!csvFile) {
      messages.push("Please select a CSV file before submitting.");
    } else {
      // Check file extension
      var extension = csvFile.split(".").pop().toLowerCase();
      if (extension !== "csv") {
        messages.push("Invalid file format! Please select a valid CSV file.");
      }
    }

    if (messages.length > 0) {
      alert(messages.join("\n")); // Show all messages in one alert
      e.preventDefault(); // Prevent form submission
    }
  });
});