jQuery(document).ready(function ($) {
    // Ensure local PDFObject is used instead of CDN
    if (window.jspdf) {
      window.jspdf.pdfObjectUrl = astgdrmsys_ajax_object.pluginUrl + 'js/pdfobject.min.js';
    }
  
  // Function to print the result
  function astgdrmsys_print_result() {
    var printContent = $("#print").prop("outerHTML");

    // Include only local styles from your plugin
    var styles = `
      <link rel="stylesheet" href="${astgdrmsys_ajax_object.pluginUrl}menu-files/show-result/style.css" type="text/css">
      <link rel="stylesheet" href="${astgdrmsys_ajax_object.pluginUrl}css/bootstrap.css" type="text/css">
    `;

    var printWindow = window.open("", "", "width=800,height=600");

    var docContent = `
      <html>
        <head>
          <title>Print Student Marksheet</title>
          ${styles}
        </head>
        <body>
          <div class="container">
            ${printContent}
          </div>
          <script>
            window.onload = function() {
              window.print();
              window.onafterprint = function() {
                window.close();
              };
            };
          <\/script>
        </body>
      </html>
    `;

    var doc = new Blob([docContent], { type: "text/html" });
    var url = URL.createObjectURL(doc);
    printWindow.location.href = url;
    printWindow.document.close();
  }

  $("#printResult").on("click", astgdrmsys_print_result);

  // Function to download as PDF
  function astgdrmsys_download_pdf() {
    var elementHTML = $("#print")[0];

    html2canvas(elementHTML, {
      scale: 2,
      useCORS: true,
      logging: false,
      allowTaint: true,
    })
      .then(function (canvas) {
        var { jsPDF } = window.jspdf;
        var doc = new jsPDF({
          orientation: "p",
          unit: "mm",
          format: "a4",
        });

        const pageWidth = 210;
        const pageHeight = 297;

        var imgData = canvas.toDataURL("image/png");
        var imgWidth = pageWidth;
        var imgHeight = (canvas.height * imgWidth) / canvas.width;

        if (imgHeight > pageHeight) {
          const scaleFactor = pageHeight / imgHeight;
          imgWidth *= scaleFactor;
          imgHeight *= scaleFactor;
        }

        const verticalPosition =
          imgHeight < pageHeight ? (pageHeight - imgHeight) / 2 : 0;

        doc.addImage(
          imgData,
          "PNG",
          (pageWidth - imgWidth) / 2,
          verticalPosition,
          imgWidth,
          imgHeight,
          "",
          "FAST"
        );

        doc.save("student_marksheet.pdf");
      })
      .catch(function (error) {
        console.error("Error converting to PDF:", error);
      });
  }

  $("#downloadResult").on("click", astgdrmsys_download_pdf);
});