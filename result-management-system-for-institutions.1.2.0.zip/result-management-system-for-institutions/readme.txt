=== Result Management System for Institutions ===
Contributors: ASTGD
Tags: student management, education system, grading system, online result, student marksheet
License: GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.2.0

Manage student results with customizable marksheets, CSV import/export, PDF output, and flexible grading.

== Description ==

📘Result Management System for Institutions is designed to simplify result management for educational institutions. This plugin enables you to display detailed marksheets, import student data via CSV, and customize the marksheet layout to suit your needs.

🎬 **Watch the Demo:**  
See how it works in this video –

[youtube https://youtu.be/v1zlHftco4w?si=ntaDsUue2A5CDl-t]

### Key Features:

🔌 Seamless WordPress integration.

🧭 Intuitive dashboard for easy navigation.

📚 Manage unlimited classes, departments, sections, subjects, exams & fields.

🗂️ Subject mapping to specific classes/departments.

🧮 Add marks individually or in bulk.

📊 Auto-calculated result metrics.

🛠️ Centralized dashboard & settings.

🖨️ One-click PDF printing or saving.

✏️ Fully customizable marksheets.

🔄 Quick result editing & management.

📥 CSV-based import/export.

🔐 Robust data security & encryption.

### How to Use:

🏫 Set Up Institute Profile: Enter institutional details.

📘 Configure Academic Structure:

Add Classes (e.g., HSC 1st Year)

Add Departments (e.g., Science)

Add Sections (e.g., A, B)

📚 Assign Subjects to Classes.

📝 Set Up Exams:

Add Exam Years & Names

👨‍🎓 Add Student Records manually or via CSV.

⚙️ Configure Settings for the public portal.

🔍 Use shortcode [astgdrmsys_show_result] on pages/posts to allow result search.

== Installation ==

🔧 Simple Steps:

Go to WP Admin → Plugins → Add New.

Search for Result Management System for Institutions.

Click Install Now, then Activate.

Or:

Upload result-management-system-for-institutions.zip to /wp-content/plugins/.

Extract it.

Activate via WP Admin.

📂 After installation, you'll see the plugin menu in the dashboard.

== Screenshots ==
1. **Dashboard**: Plugin dashboard showing management options.
2. **Add Class**: Interface for adding classes.
3. **Add Subject**: Interface for adding subjects to classes.
4. **Add Student**: Interface for adding student records.
5. **Add Marks**: Interface for entering student marks.
6. **All Students**: Interface for all students.

== Frequently Asked Questions ==

**Q: What is Result Management System for Institutions?**
**A:** It is a WordPress plugin for managing and displaying student results, designed to streamline the process for educational institutions.
       This plugin is a comprehensive solution designed to streamline the process of managing academic results. It allows users, such as educators and administrators, to easily edit, delete, and publish results. This system simplifies the workflow by providing an intuitive interface that enables efficient tracking and reporting of student performance, ensuring that all stakeholders have access to accurate and timely information.


**Q: Is the plugin compatible with the latest WordPress version?**  
**A:** Yes, the Plugin is fully compatible with the latest stable version of WordPress. We ensure that our plugin is regularly updated to meet the latest WordPress standards and to provide users with a seamless experience.

**Q: Can I import/export results?**  
**A:** Yes, you can easily import and export results using the Plugin. The plugin supports CSV and Excel formats, allowing for straightforward data management. This feature enables you to efficiently transfer results between systems, making it easier to handle large datasets and maintain accurate records.

**Q: Does the plugin allow PDF export?**  
**A:** Yes, results can be saved as PDFs with a single click.

**Q: How can I get support for the Result Management System?**
**A:** We offer dedicated support for users of the plugin through multiple channels. You can reach out to our support team by emailing info@astgd.com, where our representatives will assist you with any inquiries or issues you may encounter. Additionally, we provide a live chat option on our website for immediate assistance during business hours, ensuring that you receive prompt help when needed.

== Upgrade to Result Management System for Institutions ==  

✨ **Unlock premium features for complete control and automation.**

🎓 **Admin Capabilities:**

* 🛠 Access all modules and settings
* 🧑‍🎓 Manage students, teachers, results
* 🔄 Edit/delete academic structures
* 🧮 Custom grading logic
* 📥 Import unlimited data via CSV
* 🔎 Filter & analyze student data
* 📝 Extend student data fields

👨‍🏫 **Teacher Features:**

* ➕ Add/update marks by subject
* 📊 Bulk mark import via CSV
* 🔒 Role-based limited access

👨‍👩‍👧‍👦 **Student/Parent Access:**

* 🔍 Search results using roll/registration number
* 🖨 Print/save detailed marksheets (PDF)

🚀 [Upgrade to Result Management System for Institutions Premium](https://astgd.com/result-management-system) today and unlock the full potential!


== Libraries Used ==

This plugin includes these third-party libraries. All minified files are accompanied by original source files where applicable:

📦 PDFObject

Version: 2.3.1

License: MIT

URL: https://github.com/pipwerks/PDFObject

Files: pdfobject.min.js, pdfobject.js

📦 jsPDF

Version: 3.0.1 (2025-03-17)

License: MIT

URL: https://github.com/parallax/jsPDF

Files: jspdf.umd.min.js

📦 html2canvas

Version: 1.4.1

License: MIT

URL: https://github.com/niklasvh/html2canvas

Files: html2canvas.min.js

📦 Bootstrap (CSS only)

Version: 4.5.3

License: MIT

URL: https://github.com/twbs/bootstrap

Files: bootstrap.min.css

- **Note**: Only the CSS file is used; no Bootstrap JavaScript components are included.
  
== Changelog ==

### Version 1.2.0 
🧮 Updated grade system support

📥 Enhanced CSV Import:

➕ Added support for fourth subject per student

📤 Improved bulk mark updates via CSV

🗂️ Updated demo CSV files for clearer usage

✨ UI improvements: Showing alert messages for classwise student deletion

### Version 1.1.0 
🧮 Added grade system support

📥 Enhanced CSV import:
  - 🔍 Auto-detects 'single' or 'composite' exam types
  - 📊 Supports subject-wise marks with subcodes
  - 🆔 Maps student roll numbers (`sno`) to internal IDs (`sid`) for updates

🧹 Improved unserialized data handling during mark updates

✨ UI improvements: Fixed dismissable alert messages for success/warning

### Version 1.0.0
- Initial release with core features:

🎓 Student, class, subject, and result management

🧾 Customizable marksheet layout

📤 CSV import/export

🔗 [astgdrmsys_show_result] shortcode for frontend search

== Upgrade Notice ==

📢 Stay tuned! Future updates will include:

📈 Advanced reports

🎨 More customization options

✨ UI improvements