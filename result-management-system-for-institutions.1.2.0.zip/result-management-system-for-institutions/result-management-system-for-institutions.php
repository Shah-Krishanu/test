<?php

declare(strict_types=1);
/**
 * Result Management System for Institutions
 *
 * @package           ResultManagementSystem
 * @author            ASTGD
 * @copyright         2025 ASTGD
 * @license           GPL v2 or later
 *
 * @wordpress-plugin
 * Plugin Name:       Result Management System for Institutions
 * Description:       A complete result management system designed for schools and educational institutions. Easily organize student records, generate marksheets, and streamline result publication with a user-friendly interface.
 * Version:           1.2.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            ASTGD
 * Author URI:        https://astgd.com/
 * Text Domain:       result-management-system-for-institutions
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

namespace ASTGDRMSYS\ResultManagement;

ob_start();

// Exit if accessed directly
if (! defined('ABSPATH')) {
	exit;
}

// Plugin constants
define('ASTGDRMSYS_VERSION', '1.2.0');
define('ASTGDRMSYS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ASTGDRMSYS_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Checks if all necessary dependencies are met.
 *
 * This function verifies whether all required dependencies for the plugin
 * are available and properly configured.
 *
 * @return bool Returns true if all dependencies are met, false otherwise.
 */
function astgdrmsys_check_dependencies(): bool
{
	$requirements_met = true;

	// Check PHP version
	if (version_compare(PHP_VERSION, '7.4', '<')) {
		add_action(
			'admin_notices',
			function () {
				echo '<div class="error"><p>' .
					esc_html(
						sprintf(
							// Translators: %s represents the current PHP version.
							__('Result Management System for Institutions requires PHP 7.4 or higher. Current version is %s', 'result-management-system-for-institutions'),
							PHP_VERSION
						)
					) .

					'</p></div>';
			}
		);
		$requirements_met = false;
	}

	// Check WordPress version
	if (version_compare($GLOBALS['wp_version'], '5.8', '<')) {
		add_action(
			'admin_notices',
			function () {
				echo '<div class="error"><p>' .
					esc_html(
						__('Result Management System for Institutions requires WordPress 5.8 or higher.', 'result-management-system-for-institutions') .
							'</p></div>'
					);
			}
		);
		$requirements_met = false;
	}

	// Check if required PHP extensions are loaded
	$required_extensions = array('mysqli', 'mbstring');
	$missing_extensions  = array_filter(
		$required_extensions,
		function ($ext) {
			return ! extension_loaded($ext);
		}
	);

	if (! empty($missing_extensions)) {
		add_action(
			'admin_notices',
			function () use ($missing_extensions) {
				echo '<div class="error"><p>' .
					esc_html(
						sprintf(
							// Translators: %s is a list of required PHP extensions.
							__('Result Management System for Institutions requires the following PHP extensions: %s', 'result-management-system-for-institutions'),
							implode(', ', $missing_extensions)
						)
					) .
					'</p></div>';
			}
		);
		$requirements_met = false;
	}

	// Check write permissions for upload directory
	$upload_dir = wp_upload_dir();
	if (! wp_is_writable($upload_dir['basedir'])) {
		add_action(
			'admin_notices',
			function () {
				echo '<div class="error"><p>' .
					esc_html(
						__('Result Management System for Institutions requires write permissions for the uploads directory.', 'result-management-system-for-institutions') .
							'</p></div>'
					);
			}
		);
		$requirements_met = false;
	}

	return $requirements_met;
}

// Checking for dependencies
if (! astgdrmsys_check_dependencies()) {
	return;
}

/**
 * Adds plugin's menu and submenus to the WordPress admin menu.
 *
 * This function is responsible for adding a new item to the WordPress admin menu.
 * It should be hooked to the appropriate WordPress action to ensure it is executed
 * at the right time.
 *
 * @return void
 */
function astgdrmsys_admin_menu(): void
{
	add_menu_page(
		__('Student Result Management', 'result-management-system-for-institutions'),
		__('Student Result Management', 'result-management-system-for-institutions'),
		'manage_options',
		'astgdrmsys-student-result',
		'ASTGDRMSYS\ResultManagement\astgdrmsys_plugin_page',
		'dashicons-welcome-learn-more',
		25
	);

	$submenu_pages = array(
		array('astgdrmsys-student-result', __('Dashboard', 'result-management-system-for-institutions'), __('Dashboard', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-student-result', 'ASTGDRMSYS\ResultManagement\astgdrmsys_plugin_page'),
		array('astgdrmsys-student-result', __('Class Management', 'result-management-system-for-institutions'), __('All Classes', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-class', 'ASTGDRMSYS\ResultManagement\astgdrmsys_add_class'),
		array('astgdrmsys-student-result', __('Department Management', 'result-management-system-for-institutions'), __('All Departments', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-department', 'ASTGDRMSYS\ResultManagement\astgdrmsys_add_department'),
		array('astgdrmsys-student-result', __('Section Management', 'result-management-system-for-institutions'), __('All Sections', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-section', 'ASTGDRMSYS\ResultManagement\astgdrmsys_add_section'),
		array('astgdrmsys-student-result', __('Subject Management', 'result-management-system-for-institutions'), __('View Subject', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-subject', 'ASTGDRMSYS\ResultManagement\astgdrmsys_add_subject'),
		array('astgdrmsys-student-result', __('Exam Year Management', 'result-management-system-for-institutions'), __('Exam Years', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-exam-year', 'ASTGDRMSYS\ResultManagement\astgdrmsys_add_exam_year'),
		array('astgdrmsys-student-result', __('Exam Name Management', 'result-management-system-for-institutions'), __('Exam Names', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-exam-name', 'ASTGDRMSYS\ResultManagement\astgdrmsys_add_exam_name'),
		array('astgdrmsys-student-result', __('Add Student Result', 'result-management-system-for-institutions'), __('Add Result', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-add-record', 'ASTGDRMSYS\ResultManagement\astgdrmsys_add_record'),
		array('astgdrmsys-student-result', __('View Mark', 'result-management-system-for-institutions'), __('Add / Update Mark', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-add-mark', 'ASTGDRMSYS\ResultManagement\astgdrmsys_add_mark'),
		array('astgdrmsys-student-result', __('Update Student Marks from CSV', 'result-management-system-for-institutions'), __('CSV Update', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-update-marks-csv', 'ASTGDRMSYS\ResultManagement\astgdrmsys_update_marks_csv'),
		array('astgdrmsys-student-result', __('All Students Directory', 'result-management-system-for-institutions'), __('All Students', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-all-students', 'ASTGDRMSYS\ResultManagement\astgdrmsys_all_students'),
		array('astgdrmsys-student-result', __('Configure & Settings', 'result-management-system-for-institutions'), __('Settings', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-settings', 'ASTGDRMSYS\ResultManagement\astgdrmsys_settings'),
		array('astgdrmsys-student-result', __('Help & Guide', 'result-management-system-for-institutions'), __('Help & Guide', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-help', 'ASTGDRMSYS\ResultManagement\astgdrmsys_help'),
		array('v', __('View', 'result-management-system-for-institutions'), __('View', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-viewrec', 'ASTGDRMSYS\ResultManagement\astgdrmsys_viewrec'),
		array('d', __('Delete', 'result-management-system-for-institutions'), __('Delete', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-delrec', 'ASTGDRMSYS\ResultManagement\astgdrmsys_delrec'),
		array('f', __('Edit Record', 'result-management-system-for-institutions'), __('Edit Record', 'result-management-system-for-institutions'), 'manage_options', 'astgdrmsys-edit-record', 'ASTGDRMSYS\ResultManagement\astgdrmsys_edit_record'),
	);

	foreach ($submenu_pages as $page) {
		add_submenu_page(...$page);
	}
}
add_action('admin_menu', 'ASTGDRMSYS\ResultManagement\astgdrmsys_admin_menu');

/**
 * Adds a new record to the rms (Result Management System for Institutions) system.
 *
 * This function is responsible for adding a new record to the database or
 * performing any necessary operations to store the record within the rms system.
 *
 * @return void
 */
function astgdrmsys_add_record(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}

	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/student-record/add-record.php';
}

/**
 * Adds a mark to the system.
 *
 * This function is responsible for adding a mark to the system.
 * It does not take any parameters and does not return any value.
 *
 * @return void
 */
function astgdrmsys_add_mark(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}

	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/mark/add-mark.php';
}

/**
 * Updates marks from a CSV file.
 *
 * This function reads a CSV file and updates the marks accordingly.
 *
 * @return void
 */
function astgdrmsys_update_marks_csv(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}

	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/update-marks-csv/csv-update.php';
}

/**
 * Displays the rms plugin page.
 *
 * This function is responsible for rendering the main Dashboard page of the rms plugin.
 *
 * @return void
 */
function astgdrmsys_plugin_page(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}

	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/dashboard.php';
}

/**
 * Retrieves all students.
 *
 * This function fetches and returns a list of all students.
 *
 * @return void
 */
function astgdrmsys_all_students(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}
	
	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/all-students/all-students.php';
}

/**
 * Adds a class to the rms (Result Management System for Institutions) plugin.
 *
 * This function is responsible for adding a specific class to the rms plugin.
 *
 * @return void
 */
function astgdrmsys_add_class(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}
	// Include the class file
	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/class/add-class.php';
}

/**
 * Adds a new department to the system.
 *
 * This function is responsible for adding a new department to the system.
 * It performs necessary validations and inserts the department data into the database.
 *
 * @return void
 */
function astgdrmsys_add_department(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}
	// Include the department file
	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/department/add-department.php';
}

/**
 * Adds a new section to the result management plugin.
 *
 * This function is responsible for adding a new section to the Result Management System for Institutions plugin.
 *
 * @return void
 */
function astgdrmsys_add_section(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}
	// Include the section file
	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/section/add-section.php';
}

/**
 * Adds a new exam name to the system.
 *
 * This function is responsible for adding a new exam name to the result management system.
 *
 * @return void
 */
function astgdrmsys_add_exam_name(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}

	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/exam-name/add-exam-name.php';
}

/**
 * Adds a new exam year to the system.
 *
 * This function is responsible for adding a new exam year to the result management system.
 *
 * @return void
 */
function astgdrmsys_add_exam_year(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}

	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/exam-year/add-exam-year.php';
}

/**
 * Adds a subject to the system.
 *
 * This function is responsible for adding a new subject to the system.
 *
 * @return void
 */
function astgdrmsys_add_subject(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}
	// Include the subject file
	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/subject/add-subject.php';
}

/**
 * Provides help or information related to the rms (Result Management System for Institutions) plugin.
 *
 * This function is intended to assist users by providing necessary help or information
 * about the functionalities and usage of the rms plugin.
 *
 * @return void
 */
function astgdrmsys_help(): void
{
	$nonce_action = 'astgdrmsys_help_nonce';

	$nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';

	if (! wp_verify_nonce($nonce, $nonce_action)) {
		// First-time load: generate and redirect with nonce
		$url = add_query_arg('_wpnonce', wp_create_nonce($nonce_action), isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '');
		wp_safe_redirect($url);
		exit;
	}

	// Nonce is valid now — render help page
	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/help/help.php';
}
/**
 * Displays the rms view record.
 *
 * This function is responsible for rendering the view record in the rms plugin.
 *
 * @return void
 */
function astgdrmsys_viewrec(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}

	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/view/view.php';
}

/**
 * Edits a record in the Result Management System for Institutions plugin.
 *
 * This function is responsible for handling the editing of records within the
 * Result Management System for Institutions plugin. It performs necessary operations to update
 * the record based on the provided data.
 *
 * @return void
 */
function astgdrmsys_edit_record(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}

	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/edit-record/edit-record.php';
}

/**
 * Deletes a record in the rms (Result Management System for Institutions) system.
 *
 * This function is responsible for deleting a specific record from the database
 * or any other storage mechanism used by the rms plugin.
 *
 * @return void
 */
function astgdrmsys_delrec(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}

	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/delete.php';
}

/**
 * Initializes the settings for the rms (Result Management System for Institutions) plugin.
 *
 * This function sets up the necessary configurations and options for the plugin.
 *
 * @return void
 */
function astgdrmsys_settings(): void
{
	// Check if the user has the required capability to manage options
	if (! current_user_can('manage_options')) {
		wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'result-management-system-for-institutions'));
	}
	// Include the settings file
	include ASTGDRMSYS_PLUGIN_DIR . 'menu-files/settings/settings.php';
}

function astgdrmsys_admin_styles(): void
{
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if (! isset($_GET['page'])) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';

	$common_pages = array(
		'astgdrmsys-student-result',
		'astgdrmsys-subject',
		'astgdrmsys-department',
		'astgdrmsys-section',
		'astgdrmsys-exam-name',
		'astgdrmsys-exam-year',
		'astgdrmsys-class',
		'astgdrmsys-add-record',
		'astgdrmsys-add-mark',
		'astgdrmsys-all-students',
		'astgdrmsys-settings',
		'astgdrmsys-help',
		'astgdrmsys-viewrec',
		'astgdrmsys-update-marks-csv',
	);

	if (in_array($page, $common_pages, true)) {
		wp_enqueue_style(
			'astgdrmsys-bootstrap',
			ASTGDRMSYS_PLUGIN_URL . 'css/bootstrap.css',
			array(),
			ASTGDRMSYS_VERSION
		);

		wp_enqueue_style(
			'astgdrmsys-w3schools',
			ASTGDRMSYS_PLUGIN_URL . 'css/w3.css',
			array(),
			ASTGDRMSYS_VERSION
		);

		wp_enqueue_style(
			'astgdrmsys-admin-common',
			ASTGDRMSYS_PLUGIN_URL . 'css/admin-style.css',
			array(),
			ASTGDRMSYS_VERSION
		);
	}

	$page_styles = array(
		'astgdrmsys-student-result'   => 'css/dashboard.css',
		'astgdrmsys-subject'          => 'menu-files/subject/subject-style.css',
		'astgdrmsys-department'       => 'menu-files/class/style.css',
		'astgdrmsys-section'          => 'menu-files/class/style.css',
		'astgdrmsys-exam-name'        => 'menu-files/exam-name/exam-name-style.css',
		'astgdrmsys-exam-year'        => 'menu-files/class/style.css',
		'astgdrmsys-class'            => 'menu-files/class/style.css',
		'astgdrmsys-add-record'       => 'menu-files/student-record/record-style.css',
		'astgdrmsys-add-mark'         => 'menu-files/mark/mark-style.css',
		'astgdrmsys-all-students'     => 'menu-files/all-students/all-student-style.css',
		'astgdrmsys-settings'         => 'menu-files/settings/style.css',
		'astgdrmsys-viewrec'          => 'menu-files/show-result/style.css',
		'astgdrmsys-edit-record'      => 'menu-files/edit-record/editrec-style.css',
		'astgdrmsys-update-marks-csv' => 'menu-files/update-marks-csv/update-marks-style.css',
		'astgdrmsys-help'             => 'menu-files/help/style.css',
	);

	if (isset($page_styles[$page])) {
		wp_enqueue_style(
			"astgdrmsys-{$page}-style",
			ASTGDRMSYS_PLUGIN_URL . $page_styles[$page],
			array(),
			ASTGDRMSYS_VERSION
		);
	}
}
add_action('admin_enqueue_scripts', 'ASTGDRMSYS\ResultManagement\astgdrmsys_admin_styles');

/**
 * Adds custom styles for the help page in the admin area.
 *
 * This function adds custom CSS styles to the admin area of the WordPress site,
 * specifically for the help page of the Result Management System for Institutions plugin.
 *
 * @return void
 */

/**
 * Enqueues the frontend styles for the plugin.
 *
 * This function is responsible for adding the necessary CSS stylesheets
 * to the frontend of the WordPress site when the plugin is active.
 *
 * @return void
 */
function astgdrmsys_frontend_styles(): void
{
	wp_enqueue_style(
		'astgdrmsys-show-result-css',
		ASTGDRMSYS_PLUGIN_URL . 'menu-files/show-result/style.css',
		array(),
		ASTGDRMSYS_VERSION
	);

	wp_enqueue_style(
		'astgdrmsys-show-result-bootstrap',
		ASTGDRMSYS_PLUGIN_URL . 'css/bootstrap.css',
		array(),
		ASTGDRMSYS_VERSION
	);
}
add_action('wp_enqueue_scripts', 'ASTGDRMSYS\ResultManagement\astgdrmsys_frontend_styles');

/**
 * Removes the footer from the WordPress admin dashboard.
 *
 * @return string The modified footer text.
 */
function astgdrmsys_remove_admin_footer(): string
{
	return '';
}
add_filter('admin_footer_text', 'ASTGDRMSYS\ResultManagement\astgdrmsys_remove_admin_footer');
add_filter('update_footer', 'ASTGDRMSYS\ResultManagement\astgdrmsys_remove_admin_footer', 9999);

/**
 * Enqueues custom scripts for the plugin.
 *
 * This function is responsible for adding the necessary JavaScript files
 * to the WordPress admin area and frontend when the plugin is active.
 *
 * @return void
 */
function astgdrmsys_custom_scripts(): void
{
	// Libraries
	wp_enqueue_script(
		'astgdrmsys-html2canvas',
		ASTGDRMSYS_PLUGIN_URL . 'js/html2canvas.min.js',
		array(),
		'1.4.1',
		true
	);

	wp_enqueue_script(
		'astgdrmsys-pdfobject',
		ASTGDRMSYS_PLUGIN_URL . 'js/pdfobject.min.js',
		array(),
		'2.1.1',
		true
	);

	wp_enqueue_script(
		'astgdrmsys-jspdf',
		ASTGDRMSYS_PLUGIN_URL . 'js/jspdf.umd.min.js',
		array('astgdrmsys-pdfobject'),
		'3.0.1',
		true
	);

	wp_enqueue_script(
		'astgdrmsys-csv-update',
		ASTGDRMSYS_PLUGIN_URL . 'js/csv-update.js',
		array('jquery'),
		ASTGDRMSYS_VERSION,
		true
	);

	wp_enqueue_script(
		'astgdrmsys-show-result',
		ASTGDRMSYS_PLUGIN_URL . 'js/show-result.js',
		array('jquery'),
		ASTGDRMSYS_VERSION,
		true
	);

	wp_enqueue_script(
		'astgdrmsys-custom-js',
		ASTGDRMSYS_PLUGIN_URL . 'js/custom.js',
		array('jquery', 'astgdrmsys-jspdf', 'astgdrmsys-html2canvas'),
		ASTGDRMSYS_VERSION,
		true
	);

	// Create nonce and pass it to JavaScript
	wp_localize_script(
		'astgdrmsys-custom-js',
		'astgdrmsys_ajax_object',
		array(
			'ajaxurl'   => admin_url('admin-ajax.php'),
			'nonce'     => wp_create_nonce('astgdrmsys_ajax_nonce'),
			'pluginUrl' => ASTGDRMSYS_PLUGIN_URL, // plugin URL
		)
	);
}
add_action('wp_enqueue_scripts', 'ASTGDRMSYS\ResultManagement\astgdrmsys_custom_scripts');
add_action('admin_enqueue_scripts', 'ASTGDRMSYS\ResultManagement\astgdrmsys_custom_scripts');


/**
 * Handles AJAX requests for the plugin.
 *
 * This function is responsible for handling AJAX requests made to the plugin.
 * It verifies the security token and processes the request accordingly.
 *
 * @return void
 */
function astgdrmsys_verify_ajax_request(): bool
{
	// Check if the request is an AJAX request
	if (! check_ajax_referer('astgdrmsys_ajax_nonce', 'nonce', false)) {
		wp_send_json_error('Invalid security token');
		return false;
	}
	return true;
}

/**
 * Retrieves departments by class.
 *
 * This function fetches and returns a list of departments based on the provided class ID.
 *
 * @return void
 */
function get_departments_by_class(): void
{
	// Verify the AJAX request
	if (! astgdrmsys_verify_ajax_request()) {
		return;
	}
	check_ajax_referer('astgdrmsys_ajax_nonce', 'nonce');

	$class_id = filter_input(INPUT_POST, 'class', FILTER_VALIDATE_INT);
	if (! $class_id) {
		wp_send_json_error('Invalid class ID');
	}

	global $wpdb;
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$departments = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT id, department FROM {$wpdb->prefix}astgdrmsys_department WHERE class = %d",
			$class_id
		)
	);

	wp_send_json_success($departments ?: array());
}
add_action('wp_ajax_astgdrmsys_get_departments_by_class', 'ASTGDRMSYS\ResultManagement\get_departments_by_class');
add_action('wp_ajax_nopriv_astgdrmsys_get_departments_by_class', 'ASTGDRMSYS\ResultManagement\get_departments_by_class');

/**
 * Retrieves sections by department.
 *
 * This function fetches and returns a list of sections based on the provided department ID.
 *
 * @return void
 */
function get_sections_by_department(): void
{
	if (! astgdrmsys_verify_ajax_request()) {
		return;
	}
	check_ajax_referer('astgdrmsys_ajax_nonce', 'nonce');

	$department_id = filter_input(INPUT_POST, 'department', FILTER_VALIDATE_INT);
	if (! $department_id) {
		wp_send_json_error('Invalid department ID');
	}

	global $wpdb;
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$sections = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT id, section FROM {$wpdb->prefix}astgdrmsys_section WHERE department = %d",
			$department_id
		)
	);

	wp_send_json_success($sections ?: array());
}
add_action('wp_ajax_astgdrmsys_get_sections_by_department', 'ASTGDRMSYS\ResultManagement\get_sections_by_department');
add_action('wp_ajax_nopriv_astgdrmsys_get_sections_by_department', 'ASTGDRMSYS\ResultManagement\get_sections_by_department');

/**
 * Retrieves subjects by class.
 *
 * This function fetches and returns a list of subjects based on the provided class ID.
 *
 * @return void
 */
function get_exam_names_by_class(): void
{
	if (! astgdrmsys_verify_ajax_request()) {
		return;
	}
	check_ajax_referer('astgdrmsys_ajax_nonce', 'nonce');

	$class_id = filter_input(INPUT_POST, 'class', FILTER_VALIDATE_INT);
	if (! $class_id) {
		wp_send_json_error('Invalid class ID');
	}

	global $wpdb;
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$exams = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT id, exam_name, exam_year, exam_year_id FROM {$wpdb->prefix}astgdrmsys_exam_name WHERE class_id = %d",
			$class_id
		)
	);

	wp_send_json_success($exams ?: array());
}
add_action('wp_ajax_astgdrmsys_get_exam_names_by_class', 'ASTGDRMSYS\ResultManagement\get_exam_names_by_class');
add_action('wp_ajax_nopriv_astgdrmsys_get_exam_names_by_class', 'ASTGDRMSYS\ResultManagement\get_exam_names_by_class');

/**
 * Function to handle the activation of the plugin.
 *
 * This function is called when the plugin is activated. It performs necessary
 * setup tasks such as creating database tables, setting default options, etc.
 *
 * @return void
 */
function astgdrmsys_activate_plugin(): void
{
	require_once ASTGDRMSYS_PLUGIN_DIR . 'installation.php';

	// run the installation routine to create database tables and set default options
	\ASTGDRMSYS\ResultManagement\astgdrmsys_run_installation_routine();

	// Create upload directory for results
	$upload_dir = wp_upload_dir();
	$result_dir = $upload_dir['basedir'] . '/astgdrmsys-results';

	if (! file_exists($result_dir)) {
		wp_mkdir_p($result_dir);
	}
}
register_activation_hook(__FILE__, 'ASTGDRMSYS\ResultManagement\astgdrmsys_activate_plugin');

/**
 * Function to handle the deactivation of the plugin.
 *
 * This function is called when the plugin is deactivated. It performs necessary
 * cleanup tasks such as removing database tables, deleting options, etc.
 *
 * @return void
 */
function astgdrmsys_uninstall_plugin(): void
{
	global $wpdb;

	$tables = array(
		'astgdrmsys_student_result',
		'astgdrmsys_school_info',
		'astgdrmsys_general_settings',
		'astgdrmsys_view_settings',
		'astgdrmsys_mark',
		'astgdrmsys_subject',
		'astgdrmsys_class',
		'astgdrmsys_department',
		'astgdrmsys_section',
		'astgdrmsys_exam_name',
		'astgdrmsys_exam_year',
		'astgdrmsys_grade_system',
	);

	foreach ($tables as $table) {
		// Sanitize the table name
		$safe_table = $wpdb->prefix . sanitize_key($table);
		// Drop the table
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query("DROP TABLE IF EXISTS `$safe_table`");
	}

	// Clean up upload directory
	$upload_dir = wp_upload_dir();
	$result_dir = $upload_dir['basedir'] . '/astgdrmsys-results';

	// Load WP_Filesystem
	global $wp_filesystem;
	// Check if WP_Filesystem is already loaded
	if (empty($wp_filesystem)) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		WP_Filesystem();
	}

	// Check if the result directory exists
	if ($wp_filesystem->is_dir($result_dir)) {
		$files = glob($result_dir . '/*');

		// Delete all files in the directory
		foreach ($files as $file) {
			if ($wp_filesystem->is_file($file)) {
				$wp_filesystem->delete($file);
			}
		}

		// Remove the directory
		$wp_filesystem->rmdir($result_dir);
	}
}
register_uninstall_hook(__FILE__, 'ASTGDRMSYS\ResultManagement\astgdrmsys_uninstall_plugin');

/**
 * Handles logging for both 'astgdrmsys_debug_log' and 'astgdrmsys_log_error' custom actions.
 *
 * This function writes log messages to a dedicated log file inside the uploads directory
 * (`wp-content/uploads/astgdrmsys-logs/rms.log`) if both WP_DEBUG and WP_DEBUG_LOG are enabled.
 *
 * Benefits:
 * - Safe location (won’t be deleted on plugin updates)
 * - Multisite and security friendly
 *
 * @param string $message The debug/error message to be logged.
 */
function astgdrmsys_handle_debug_log($message)
{
	if (! WP_DEBUG || ! WP_DEBUG_LOG) {
		return;
	}

	$upload_dir = wp_upload_dir();
	$log_dir    = trailingslashit($upload_dir['basedir']) . 'astgdrmsys-logs';
	$log_file   = trailingslashit($log_dir) . 'rms.log';

	// Recursively create directory if it doesn't exist
	if (! file_exists($log_dir)) {
		wp_mkdir_p($log_dir);
	}

	$log_entry = current_time('mysql') . ' - ' . $message . PHP_EOL;

	file_put_contents($log_file, $log_entry, FILE_APPEND);
}

// Register both logging hooks to the same handler
add_action('astgdrmsys_debug_log', 'ASTGDRMSYS\ResultManagement\astgdrmsys_handle_debug_log');
add_action('astgdrmsys_log_error', 'ASTGDRMSYS\ResultManagement\astgdrmsys_handle_debug_log');

/**
 * Shortcode handler function to display results.
 *
 * @param array $atts Shortcode attributes.
 * @return string The result output to be displayed.
 */
function astgdrmsys_show_shortcode($atts): string
{
	ob_start();
	require ASTGDRMSYS_PLUGIN_DIR . 'menu-files/show-result/show-result.php';
	return ob_get_clean();
}
add_shortcode('astgdrmsys_show_result', 'ASTGDRMSYS\ResultManagement\astgdrmsys_show_shortcode');
